"""Extract a narrow, explicitly labeled Word template into preview records."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import re
import sys
import tempfile
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any


PARSER_VERSION = "1.0.0"
SCHEMA_VERSION = "work-instruction-preview/1"

MAX_INPUT_BYTES = 8 * 1024 * 1024
MAX_MEMBER_BYTES = 4 * 1024 * 1024
MAX_TOTAL_UNCOMPRESSED_BYTES = 16 * 1024 * 1024
MAX_MEMBER_COUNT = 256
MAX_COMPRESSION_RATIO = 250
MAX_CONTENT_TYPES_BYTES = 256 * 1024
MAX_ROOT_RELS_BYTES = 128 * 1024

WORD_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CONTENT_TYPES_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
MAIN_DOCUMENT_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"
)

W = f"{{{WORD_NS}}}"


class WorkInstructionError(Exception):
    """A stable, user-readable parser or output error."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def _xml_root(part_name: str, data: bytes, expected_root: str) -> ET.Element:
    if data.startswith((b"\xff\xfe", b"\xfe\xff", b"\x00\x00\xfe\xff", b"\xff\xfe\x00\x00")):
        raise WorkInstructionError(
            "XML_UNSUPPORTED_ENCODING",
            f"{part_name} must use UTF-8 XML for this preview.",
        )
    try:
        decoded = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise WorkInstructionError(
            "XML_UNSUPPORTED_ENCODING",
            f"{part_name} is not valid UTF-8 XML.",
        ) from exc
    if re.search(r"<!\s*(?:DOCTYPE|ENTITY)\b", decoded, re.IGNORECASE):
        raise WorkInstructionError(
            "XML_UNSAFE_DECLARATION",
            f"{part_name} contains a DTD or entity declaration.",
        )
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        raise WorkInstructionError(
            "XML_MALFORMED",
            f"{part_name} is not well-formed XML.",
        ) from exc
    if root.tag != expected_root:
        raise WorkInstructionError(
            "DOCX_PART_ROOT",
            f"{part_name} has an unexpected root element.",
        )
    return root


def _read_zip_part(
    archive: zipfile.ZipFile,
    parts: dict[str, zipfile.ZipInfo],
    name: str,
    limit: int,
) -> bytes:
    info = parts.get(name)
    if info is None:
        raise WorkInstructionError("DOCX_MISSING_PART", f"Required DOCX part is missing: {name}.")
    if info.file_size > limit:
        raise WorkInstructionError("ZIP_MEMBER_LIMIT", f"DOCX part exceeds its size limit: {name}.")
    try:
        with archive.open(info, "r") as stream:
            data = stream.read(limit + 1)
    except (OSError, RuntimeError, zipfile.BadZipFile, EOFError) as exc:
        raise WorkInstructionError("ZIP_MEMBER_READ_FAILED", f"Could not read DOCX part: {name}.") from exc
    if len(data) > limit:
        raise WorkInstructionError("ZIP_MEMBER_LIMIT", f"DOCX part exceeds its size limit: {name}.")
    if len(data) != info.file_size:
        raise WorkInstructionError("ZIP_SIZE_MISMATCH", f"DOCX part has an inconsistent size: {name}.")
    return data


def _validate_archive(archive: zipfile.ZipFile) -> dict[str, zipfile.ZipInfo]:
    infos = archive.infolist()
    if len(infos) > MAX_MEMBER_COUNT:
        raise WorkInstructionError("ZIP_MEMBER_COUNT_LIMIT", "DOCX archive has too many members.")

    parts: dict[str, zipfile.ZipInfo] = {}
    total_size = 0
    for info in infos:
        name = info.filename
        if name in parts:
            raise WorkInstructionError("ZIP_DUPLICATE_MEMBER", f"DOCX archive repeats a member: {name}.")
        clean_name = name.rstrip("/")
        path_parts = clean_name.split("/")
        if (
            not clean_name
            or name.startswith("/")
            or "\\" in name
            or ":" in name
            or any(piece in {"", ".", ".."} for piece in path_parts)
        ):
            raise WorkInstructionError("ZIP_UNSAFE_MEMBER", "DOCX archive contains an unsafe member name.")
        if info.flag_bits & 0x1:
            raise WorkInstructionError("ZIP_ENCRYPTED_MEMBER", f"DOCX archive has an encrypted member: {name}.")
        if info.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}:
            raise WorkInstructionError("ZIP_UNSUPPORTED_COMPRESSION", f"DOCX archive uses unsupported compression: {name}.")
        if info.file_size > MAX_MEMBER_BYTES:
            raise WorkInstructionError("ZIP_MEMBER_LIMIT", f"DOCX archive member exceeds the size limit: {name}.")
        total_size += info.file_size
        if total_size > MAX_TOTAL_UNCOMPRESSED_BYTES:
            raise WorkInstructionError("ZIP_TOTAL_SIZE_LIMIT", "DOCX archive exceeds the total uncompressed size limit.")
        if info.file_size:
            if not info.compress_size:
                raise WorkInstructionError("ZIP_COMPRESSION_RATIO_LIMIT", f"DOCX archive member has an unsafe compression ratio: {name}.")
            if info.file_size / info.compress_size > MAX_COMPRESSION_RATIO:
                raise WorkInstructionError("ZIP_COMPRESSION_RATIO_LIMIT", f"DOCX archive member has an unsafe compression ratio: {name}.")
        if not info.is_dir():
            parts[name] = info
    return parts


def _extract_paragraph_text(paragraph: ET.Element) -> str:
    pieces: list[str] = []

    def visit(element: ET.Element) -> None:
        if element.tag == W + "pPr" or element.tag == W + "rPr":
            return
        if element.tag == W + "t":
            pieces.append(element.text or "")
            return
        if element.tag == W + "tab":
            pieces.append("\t")
            return
        if element.tag in {W + "br", W + "cr"}:
            break_type = element.attrib.get(W + "type", "textWrapping")
            if break_type != "textWrapping":
                raise WorkInstructionError(
                    "UNSUPPORTED_BREAK_TYPE",
                    "Only ordinary line breaks are supported inside a paragraph.",
                )
            pieces.append("\n")
            return
        for child in element:
            visit(child)

    visit(paragraph)
    return "".join(pieces).replace("\r\n", "\n").replace("\r", "\n").strip()


def _check_unsupported_content(document: ET.Element, parts: dict[str, zipfile.ZipInfo]) -> None:
    if any(element.tag == W + "tbl" for element in document.iter()):
        raise WorkInstructionError("UNSUPPORTED_TABLE", "Tables are not supported by this preview.")
    image_tags = {W + "drawing", W + "pict", W + "object", W + "txbxContent"}
    if any(element.tag in image_tags for element in document.iter()) or any(
        name.startswith("word/media/") for name in parts
    ):
        raise WorkInstructionError("UNSUPPORTED_IMAGE", "Images and drawing content are not supported by this preview.")
    if any(element.tag == W + "numPr" for element in document.iter()) or "word/numbering.xml" in parts:
        raise WorkInstructionError("UNSUPPORTED_NUMBERING", "Word numbering and list formatting are not supported by this preview.")

    unsupported_tags = {
        W + "hyperlink",
        W + "altChunk",
        W + "fldSimple",
        W + "fldChar",
        W + "instrText",
        W + "footnoteReference",
        W + "endnoteReference",
        W + "commentReference",
        W + "commentRangeStart",
        W + "commentRangeEnd",
        W + "del",
        W + "ins",
        W + "moveFrom",
        W + "moveTo",
        W + "sdt",
        W + "customXml",
        W + "sym",
    }
    if any(element.tag in unsupported_tags for element in document.iter()):
        raise WorkInstructionError(
            "UNSUPPORTED_WORD_CONTENT",
            "Fields, tracked changes, comments, links, symbols, and content controls are not supported.",
        )
    if any(element.tag == W + "vanish" for element in document.iter()):
        raise WorkInstructionError("UNSUPPORTED_HIDDEN_TEXT", "Hidden text is not supported by this preview.")


def _check_unsupported_package_parts(parts: dict[str, zipfile.ZipInfo]) -> None:
    for name in parts:
        lowered = name.lower()
        components = lowered.split("/")
        if (
            lowered.startswith("word/embeddings/")
            or lowered.startswith("word/activex/")
            or "vbaproject" in components[-1]
            or components[-1] == "vbadata.xml"
            or lowered.startswith("customui/")
        ):
            raise WorkInstructionError(
                "UNSUPPORTED_PACKAGE_CONTENT",
                "Macro, ActiveX, and embedded package content are not supported.",
            )


def parse_docx(input_path: str | os.PathLike[str]) -> dict[str, Any]:
    """Read a DOCX main body and validate its explicit manual heading template."""
    path = Path(input_path)
    try:
        with path.open("rb") as stream:
            source_bytes = stream.read(MAX_INPUT_BYTES + 1)
    except OSError as exc:
        raise WorkInstructionError("INPUT_READ_FAILED", "Could not read the source DOCX.") from exc
    if len(source_bytes) > MAX_INPUT_BYTES:
        raise WorkInstructionError("INPUT_SIZE_LIMIT", "Source DOCX exceeds the 8 MiB input limit.")

    source_hash = hashlib.sha256(source_bytes).hexdigest()
    try:
        archive = zipfile.ZipFile(io.BytesIO(source_bytes), "r")
    except (OSError, zipfile.BadZipFile, zipfile.LargeZipFile) as exc:
        raise WorkInstructionError("ZIP_INVALID", "Source file is not a valid DOCX ZIP archive.") from exc

    with archive:
        parts = _validate_archive(archive)
        _check_unsupported_package_parts(parts)
        content_types_bytes = _read_zip_part(archive, parts, "[Content_Types].xml", MAX_CONTENT_TYPES_BYTES)
        root_rels_bytes = _read_zip_part(archive, parts, "_rels/.rels", MAX_ROOT_RELS_BYTES)
        document_bytes = _read_zip_part(archive, parts, "word/document.xml", MAX_MEMBER_BYTES)

        content_types = _xml_root(
            "[Content_Types].xml",
            content_types_bytes,
            f"{{{CONTENT_TYPES_NS}}}Types",
        )
        overrides = [
            element
            for element in content_types.findall(f"{{{CONTENT_TYPES_NS}}}Override")
            if element.attrib.get("PartName") == "/word/document.xml"
        ]
        package_content_types = [element.attrib.get("ContentType", "").lower() for element in content_types]
        if any("macroenabled" in item or "vbaproject" in item for item in package_content_types):
            raise WorkInstructionError(
                "UNSUPPORTED_PACKAGE_CONTENT",
                "Macro-enabled documents are not supported by this preview.",
            )
        if not any(item.attrib.get("ContentType") == MAIN_DOCUMENT_CONTENT_TYPE for item in overrides):
            raise WorkInstructionError("DOCX_CONTENT_TYPE", "DOCX does not declare a Word main document part.")

        relationships = _xml_root(
            "_rels/.rels",
            root_rels_bytes,
            f"{{{REL_NS}}}Relationships",
        )
        office_document_relationships = [
            element
            for element in relationships.findall(f"{{{REL_NS}}}Relationship")
            if element.attrib.get("Type", "").endswith("/officeDocument")
        ]
        if len(office_document_relationships) != 1:
            raise WorkInstructionError("DOCX_ROOT_RELATIONSHIP", "DOCX must contain one main document relationship.")
        main_relationship = office_document_relationships[0]
        target = main_relationship.attrib.get("Target", "").lstrip("/")
        if main_relationship.attrib.get("TargetMode") == "External" or target != "word/document.xml":
            raise WorkInstructionError("DOCX_ROOT_RELATIONSHIP", "DOCX main document relationship has an unsupported target.")

        document = _xml_root("word/document.xml", document_bytes, W + "document")

    _check_unsupported_content(document, parts)
    body = document.find(W + "body")
    if body is None:
        raise WorkInstructionError("DOCX_BODY_MISSING", "DOCX main document has no body element.")
    for element in body:
        if element.tag not in {W + "p", W + "sectPr"}:
            raise WorkInstructionError(
                "UNSUPPORTED_BODY_CONTENT",
                "Only main body paragraphs are supported by this preview.",
            )

    paragraphs: list[tuple[int, str]] = []
    paragraph_index = 0
    for element in body:
        if element.tag == W + "p":
            paragraph_index += 1
            paragraphs.append((paragraph_index, _extract_paragraph_text(element)))

    title: dict[str, Any] | None = None
    safety_notes: dict[str, Any] | None = None
    steps: list[dict[str, Any]] = []
    seen_numbers: set[int] = set()
    steps_started = False

    for index, text in paragraphs:
        if not text:
            continue

        if text.startswith("Work Instruction:"):
            if title is not None:
                raise WorkInstructionError("TEMPLATE_DUPLICATE_LABEL", "Template repeats the Work Instruction title label.")
            if safety_notes is not None or steps_started:
                raise WorkInstructionError("TEMPLATE_AMBIGUOUS_CONTENT", "Work Instruction title must be the first labeled paragraph.")
            value = text[len("Work Instruction:") :].strip()
            if not value:
                raise WorkInstructionError("TEMPLATE_EMPTY_TITLE", "Work Instruction title is empty.")
            if "\n" in value:
                raise WorkInstructionError("TEMPLATE_MULTILINE_TITLE", "Work Instruction title must fit on one line.")
            title = {"text": value, "source_paragraph_index": index}
            continue

        if title is None:
            raise WorkInstructionError(
                "TEMPLATE_MISSING_TITLE",
                "First non-empty paragraph must start with Work Instruction:.",
            )

        if text.startswith("Safety Notes:"):
            if safety_notes is not None:
                raise WorkInstructionError("TEMPLATE_DUPLICATE_LABEL", "Template repeats the Safety Notes label.")
            if steps_started:
                raise WorkInstructionError("TEMPLATE_AMBIGUOUS_CONTENT", "Safety Notes must appear before the first step.")
            value = text[len("Safety Notes:") :].strip()
            if not value:
                raise WorkInstructionError("TEMPLATE_EMPTY_SAFETY_NOTES", "Safety Notes label has no text.")
            safety_notes = {"text": value, "source_paragraph_index": index}
            continue

        step_match = re.match(r"^Step\s+([0-9]+):", text)
        if step_match is not None:
            steps_started = True
            digits = step_match.group(1)
            if len(digits) > 9:
                raise WorkInstructionError(
                    "TEMPLATE_STEP_NUMBER_LIMIT",
                    "Step number labels may contain at most nine digits.",
                )
            number = int(digits)
            if number in seen_numbers:
                raise WorkInstructionError("TEMPLATE_DUPLICATE_LABEL", f"Template repeats Step {number}.")
            if number < 1:
                raise WorkInstructionError("TEMPLATE_STEP_SEQUENCE", "Step numbers must start at 1.")
            value = text[step_match.end() :].strip()
            if not value:
                raise WorkInstructionError("TEMPLATE_EMPTY_STEP", f"Step {number} has no instruction text.")
            if not any(line.strip() for line in value.split("\n")):
                raise WorkInstructionError("TEMPLATE_EMPTY_STEP", f"Step {number} has no instruction text.")
            seen_numbers.add(number)
            steps.append(
                {
                    "step_number": number,
                    "text": value,
                    "source_paragraph_index": index,
                }
            )
            continue

        raise WorkInstructionError(
            "TEMPLATE_AMBIGUOUS_CONTENT",
            f"Paragraph {index} is not a supported title, safety note, or Step N: heading.",
        )

    if title is None:
        raise WorkInstructionError("TEMPLATE_MISSING_TITLE", "Template has no Work Instruction title heading.")
    if not steps:
        raise WorkInstructionError("TEMPLATE_NO_STEPS", "Template has no Step N: instruction headings.")
    for expected, step in enumerate(steps, start=1):
        if step["step_number"] != expected:
            raise WorkInstructionError(
                "TEMPLATE_STEP_SEQUENCE",
                f"Expected Step {expected}, found Step {step['step_number']}.",
            )

    return {
        "parser_version": PARSER_VERSION,
        "source_sha256": source_hash,
        "source_size_bytes": len(source_bytes),
        "title": title,
        "safety_notes": safety_notes,
        "steps": steps,
    }


def serialize_outputs(parsed: dict[str, Any], source_name: str) -> tuple[bytes, bytes]:
    """Return deterministic UTF-8 JSON and CSV bytes for a parsed document."""
    source = {
        "filename": Path(source_name).name,
        "size_bytes": parsed["source_size_bytes"],
        "sha256": parsed["source_sha256"],
        "paragraph_indexing": "One-based paragraphs in the main document body, including blank paragraphs.",
    }
    preview = {
        "schema_version": SCHEMA_VERSION,
        "parser_version": parsed["parser_version"],
        "source": source,
        "title": parsed["title"],
        "safety_notes": parsed["safety_notes"],
        "steps": parsed["steps"],
    }
    json_bytes = (json.dumps(preview, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")

    output = io.StringIO(newline="")
    writer = csv.writer(output, lineterminator="\n", quoting=csv.QUOTE_MINIMAL)
    writer.writerow(["record_type", "step_number", "text", "source_paragraph_index", "source_sha256"])
    writer.writerow(["title", "", _csv_safe_text(parsed["title"]["text"]), parsed["title"]["source_paragraph_index"], parsed["source_sha256"]])
    if parsed["safety_notes"] is not None:
        writer.writerow(
            [
                "safety_notes",
                "",
                _csv_safe_text(parsed["safety_notes"]["text"]),
                parsed["safety_notes"]["source_paragraph_index"],
                parsed["source_sha256"],
            ]
        )
    for step in parsed["steps"]:
        writer.writerow(
            [
                "step",
                step["step_number"],
                _csv_safe_text(step["text"]),
                step["source_paragraph_index"],
                parsed["source_sha256"],
            ]
        )
    return json_bytes, output.getvalue().encode("utf-8")


def _csv_safe_text(value: str) -> str:
    """Keep formula-like source text literal when a CSV is opened as a spreadsheet."""
    significant = value.lstrip()
    if significant.startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def _stage_file(directory: Path, name: str, data: bytes) -> Path:
    descriptor, staged_name = tempfile.mkstemp(prefix=f".{name}.", suffix=".tmp", dir=directory)
    staged_path = Path(staged_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
    except OSError:
        try:
            staged_path.unlink()
        except OSError:
            pass
        raise
    return staged_path


def write_outputs(parsed: dict[str, Any], source_name: str, output_dir: str | os.PathLike[str]) -> tuple[Path, Path]:
    """Publish both preview files atomically per file and without overwriting."""
    directory = Path(output_dir)
    try:
        directory.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise WorkInstructionError("OUTPUT_DIR_UNAVAILABLE", "Could not create the output directory.") from exc
    if not directory.is_dir():
        raise WorkInstructionError("OUTPUT_DIR_UNAVAILABLE", "Output path is not a directory.")

    names = ("work_instruction_preview.json", "work_instruction_preview.csv")
    destinations = tuple(directory / name for name in names)
    existing = [path.name for path in destinations if os.path.lexists(path)]
    if existing:
        raise WorkInstructionError(
            "OUTPUT_EXISTS",
            "Refusing to overwrite existing output: " + ", ".join(existing) + ".",
        )

    payloads = serialize_outputs(parsed, source_name)
    staged: list[Path] = []
    created: list[Path] = []
    try:
        for name, payload in zip(names, payloads):
            staged.append(_stage_file(directory, name, payload))
        for temporary, destination in zip(staged, destinations):
            os.link(temporary, destination)
            created.append(destination)
        return destinations[0], destinations[1]
    except FileExistsError as exc:
        for path in reversed(created):
            try:
                path.unlink()
            except OSError:
                pass
        raise WorkInstructionError("OUTPUT_EXISTS", "An output appeared during writing. No outputs were retained.") from exc
    except OSError as exc:
        for path in reversed(created):
            try:
                path.unlink()
            except OSError:
                pass
        raise WorkInstructionError("OUTPUT_WRITE_FAILED", "Could not publish the JSON and CSV previews.") from exc
    finally:
        for path in staged:
            try:
                path.unlink()
            except OSError:
                pass


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Preview a Word work instruction using the explicit manual heading template."
    )
    parser.add_argument("source_docx", help="Path to one DOCX that follows the supported template")
    parser.add_argument("--output-dir", required=True, help="Directory for the JSON and CSV preview files")
    arguments = parser.parse_args(argv)

    try:
        parsed = parse_docx(arguments.source_docx)
        json_path, csv_path = write_outputs(parsed, arguments.source_docx, arguments.output_dir)
    except WorkInstructionError as exc:
        print(f"ERROR[{exc.code}]: {exc.message}", file=sys.stderr)
        return 2

    print(
        f"Created JSON and CSV previews for {len(parsed['steps'])} steps. "
        f"Source SHA-256: {parsed['source_sha256']}"
    )
    print(f"JSON: {json_path}")
    print(f"CSV: {csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
