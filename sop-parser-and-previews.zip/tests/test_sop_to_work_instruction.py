from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import sop_to_work_instruction as subject
from tests.fixture_factory import make_docx, paragraph, sample_docx_bytes


def write_source(data: bytes, directory: Path, name: str = "sample.docx") -> Path:
    path = directory / name
    path.write_bytes(data)
    return path


def valid_items() -> list[str]:
    return [
        paragraph("Work Instruction: Review a sample record"),
        paragraph("Safety Notes: Synthetic example only."),
        paragraph("Step 1: Open the sample record."),
        paragraph("Step 2: Mark the sample record Complete."),
    ]


class ParseTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def parse_items(self, items: list[str]) -> dict:
        path = write_source(make_docx(items), self.directory)
        return subject.parse_docx(path)

    def assert_error(self, items: list[str], code: str) -> None:
        path = write_source(make_docx(items), self.directory)
        with self.assertRaises(subject.WorkInstructionError) as raised:
            subject.parse_docx(path)
        self.assertEqual(raised.exception.code, code)

    def test_valid_steps_include_source_hash_and_paragraph_indices(self) -> None:
        path = write_source(make_docx(valid_items()), self.directory)
        parsed = subject.parse_docx(path)
        self.assertEqual(parsed["title"], {"text": "Review a sample record", "source_paragraph_index": 1})
        self.assertEqual(parsed["safety_notes"]["source_paragraph_index"], 2)
        self.assertEqual([item["source_paragraph_index"] for item in parsed["steps"]], [3, 4])
        self.assertEqual(parsed["source_sha256"], hashlib.sha256(path.read_bytes()).hexdigest())

    def test_multiline_text_and_unicode_are_preserved(self) -> None:
        parsed = self.parse_items(
            [
                paragraph("Work Instruction: Check résumé records"),
                paragraph("", lines=["Step 1: Review the résumé.", "保存 Unicode text: 東京, café." ]),
            ]
        )
        self.assertEqual(parsed["steps"][0]["text"], "Review the résumé.\n保存 Unicode text: 東京, café.")

    def test_blank_paragraphs_count_in_provenance(self) -> None:
        parsed = self.parse_items(
            [paragraph("Work Instruction: Blank index check"), paragraph(""), paragraph("Step 1: Continue.")]
        )
        self.assertEqual(parsed["steps"][0]["source_paragraph_index"], 3)

    def test_empty_step_is_rejected(self) -> None:
        self.assert_error([paragraph("Work Instruction: Empty step"), paragraph("Step 1:")], "TEMPLATE_EMPTY_STEP")

    def test_missing_title_heading_is_rejected(self) -> None:
        self.assert_error([paragraph("A title without the required label"), paragraph("Step 1: Continue.")], "TEMPLATE_MISSING_TITLE")

    def test_missing_steps_are_rejected(self) -> None:
        self.assert_error([paragraph("Work Instruction: No steps")], "TEMPLATE_NO_STEPS")

    def test_empty_title_is_rejected(self) -> None:
        self.assert_error([paragraph("Work Instruction:"), paragraph("Step 1: Continue.")], "TEMPLATE_EMPTY_TITLE")

    def test_duplicate_title_label_is_rejected(self) -> None:
        self.assert_error(
            [paragraph("Work Instruction: First"), paragraph("Work Instruction: Second"), paragraph("Step 1: Continue.")],
            "TEMPLATE_DUPLICATE_LABEL",
        )

    def test_duplicate_safety_label_is_rejected(self) -> None:
        self.assert_error(
            [paragraph("Work Instruction: Duplicate note"), paragraph("Safety Notes: First"), paragraph("Safety Notes: Second"), paragraph("Step 1: Continue.")],
            "TEMPLATE_DUPLICATE_LABEL",
        )

    def test_duplicate_step_label_is_rejected(self) -> None:
        self.assert_error(
            [paragraph("Work Instruction: Duplicate step"), paragraph("Step 1: First."), paragraph("Step 1: Second.")],
            "TEMPLATE_DUPLICATE_LABEL",
        )

    def test_step_sequence_must_be_contiguous_from_one(self) -> None:
        self.assert_error(
            [paragraph("Work Instruction: Sequence"), paragraph("Step 2: First." )],
            "TEMPLATE_STEP_SEQUENCE",
        )

    def test_step_number_label_is_bounded_before_integer_conversion(self) -> None:
        huge_label = "9" * 5000
        self.assert_error(
            [paragraph("Work Instruction: Large step label"), paragraph(f"Step {huge_label}: Continue.")],
            "TEMPLATE_STEP_NUMBER_LIMIT",
        )

    def test_unlabeled_paragraph_is_ambiguous(self) -> None:
        self.assert_error(
            [paragraph("Work Instruction: Ambiguous"), paragraph("Extra note without a label"), paragraph("Step 1: Continue.")],
            "TEMPLATE_AMBIGUOUS_CONTENT",
        )

    def test_table_is_rejected(self) -> None:
        body = valid_items() + ["<w:tbl><w:tr><w:tc><w:p><w:r><w:t>Hidden table text</w:t></w:r></w:p></w:tc></w:tr></w:tbl>"]
        path = write_source(make_docx(body), self.directory)
        with self.assertRaises(subject.WorkInstructionError) as raised:
            subject.parse_docx(path)
        self.assertEqual(raised.exception.code, "UNSUPPORTED_TABLE")

    def test_image_or_drawing_is_rejected(self) -> None:
        body = valid_items() + ["<w:p><w:r><w:drawing/></w:r></w:p>"]
        path = write_source(make_docx(body), self.directory)
        with self.assertRaises(subject.WorkInstructionError) as raised:
            subject.parse_docx(path)
        self.assertEqual(raised.exception.code, "UNSUPPORTED_IMAGE")

    def test_numbering_is_rejected(self) -> None:
        body = valid_items() + [
            '<w:p><w:pPr><w:numPr><w:ilvl w:val="0"/></w:numPr></w:pPr><w:r><w:t>1. Hidden list</w:t></w:r></w:p>'
        ]
        path = write_source(make_docx(body), self.directory)
        with self.assertRaises(subject.WorkInstructionError) as raised:
            subject.parse_docx(path)
        self.assertEqual(raised.exception.code, "UNSUPPORTED_NUMBERING")

    def test_numbering_part_is_rejected_even_without_direct_paragraph_numbering(self) -> None:
        path = write_source(
            make_docx(valid_items(), extra_parts=[("word/numbering.xml", b"<numbering/>")]),
            self.directory,
        )
        with self.assertRaises(subject.WorkInstructionError) as raised:
            subject.parse_docx(path)
        self.assertEqual(raised.exception.code, "UNSUPPORTED_NUMBERING")

    def test_embedded_and_macro_package_parts_are_rejected(self) -> None:
        for part_name in ("word/embeddings/oleObject1.bin", "word/vbaProject.bin", "word/activeX/activeX1.bin"):
            with self.subTest(part_name=part_name):
                path = write_source(make_docx(valid_items(), extra_parts=[(part_name, b"synthetic")]), self.directory)
                with self.assertRaises(subject.WorkInstructionError) as raised:
                    subject.parse_docx(path)
                self.assertEqual(raised.exception.code, "UNSUPPORTED_PACKAGE_CONTENT")

    def test_malformed_zip_is_rejected(self) -> None:
        path = write_source(b"not a ZIP file", self.directory)
        with self.assertRaises(subject.WorkInstructionError) as raised:
            subject.parse_docx(path)
        self.assertEqual(raised.exception.code, "ZIP_INVALID")

    def test_oversized_input_is_rejected(self) -> None:
        path = self.directory / "large.docx"
        with path.open("wb") as stream:
            stream.truncate(subject.MAX_INPUT_BYTES + 1)
        with self.assertRaises(subject.WorkInstructionError) as raised:
            subject.parse_docx(path)
        self.assertEqual(raised.exception.code, "INPUT_SIZE_LIMIT")

    def test_oversized_zip_member_is_rejected(self) -> None:
        large_text = bytes(
            32 + value % 95
            for value in hashlib.shake_256(b"oversize-member").digest(subject.MAX_MEMBER_BYTES + 1)
        ).decode("ascii")
        huge_xml = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            '<w:body><w:p><w:r><w:t>'
            + large_text
            + "</w:t></w:r></w:p></w:body></w:document>"
        ).encode("utf-8")
        path = write_source(make_docx([], document_xml_override=huge_xml), self.directory)
        with self.assertRaises(subject.WorkInstructionError) as raised:
            subject.parse_docx(path)
        self.assertEqual(raised.exception.code, "ZIP_MEMBER_LIMIT")

    def test_unsafe_xml_declaration_is_rejected(self) -> None:
        unsafe = b'<!DOCTYPE w:document [<!ENTITY x "unsafe">]><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body/></w:document>'
        path = write_source(make_docx([], document_xml_override=unsafe), self.directory)
        with self.assertRaises(subject.WorkInstructionError) as raised:
            subject.parse_docx(path)
        self.assertEqual(raised.exception.code, "XML_UNSAFE_DECLARATION")


class OutputTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        self.source = write_source(sample_docx_bytes(), self.directory, "synthetic_sop.docx")
        self.parsed = subject.parse_docx(self.source)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_serialization_is_deterministic_and_unicode_safe(self) -> None:
        first = subject.serialize_outputs(self.parsed, self.source.name)
        second = subject.serialize_outputs(subject.parse_docx(self.source), self.source.name)
        self.assertEqual(first, second)
        preview = json.loads(first[0].decode("utf-8"))
        self.assertEqual(preview["source"]["sha256"], hashlib.sha256(self.source.read_bytes()).hexdigest())
        self.assertEqual(preview["steps"][0]["source_paragraph_index"], 3)
        csv_rows = list(csv.DictReader(io.StringIO(first[1].decode("utf-8"))))
        self.assertEqual([row["record_type"] for row in csv_rows], ["title", "safety_notes", "step", "step"])

    def test_formula_like_source_text_is_guarded_in_csv_and_raw_in_json(self) -> None:
        path = write_source(
            make_docx([paragraph("Work Instruction: Formula preview"), paragraph("Step 1: =1+1")]),
            self.directory,
            "formula.docx",
        )
        parsed = subject.parse_docx(path)
        json_bytes, csv_bytes = subject.serialize_outputs(parsed, path.name)
        preview = json.loads(json_bytes.decode("utf-8"))
        rows = list(csv.DictReader(io.StringIO(csv_bytes.decode("utf-8"))))
        self.assertEqual(preview["steps"][0]["text"], "=1+1")
        self.assertEqual(rows[-1]["text"], "'=1+1")

    def test_output_pair_is_written_without_overwrite(self) -> None:
        output_dir = self.directory / "new-output"
        json_path, csv_path = subject.write_outputs(self.parsed, self.source.name, output_dir)
        self.assertTrue(json_path.is_file())
        self.assertTrue(csv_path.is_file())
        self.assertEqual(json.loads(json_path.read_text(encoding="utf-8"))["source"]["filename"], self.source.name)

    def test_cli_processes_a_synthetic_docx_end_to_end(self) -> None:
        source_path = self.directory / "cli-synthetic.docx"
        source_path.write_bytes(sample_docx_bytes())
        output_dir = self.directory / "cli-output"
        script_path = Path(subject.__file__).resolve()
        completed = subprocess.run(
            [sys.executable, str(script_path), str(source_path), "--output-dir", str(output_dir)],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertIn("Created JSON and CSV previews for 2 steps.", completed.stdout)
        self.assertTrue((output_dir / "work_instruction_preview.json").is_file())
        self.assertTrue((output_dir / "work_instruction_preview.csv").is_file())

    def test_existing_output_is_preserved_and_other_file_is_not_created(self) -> None:
        output_dir = self.directory / "existing-output"
        output_dir.mkdir()
        json_path = output_dir / "work_instruction_preview.json"
        json_path.write_text("owner data", encoding="utf-8")
        with self.assertRaises(subject.WorkInstructionError) as raised:
            subject.write_outputs(self.parsed, self.source.name, output_dir)
        self.assertEqual(raised.exception.code, "OUTPUT_EXISTS")
        self.assertEqual(json_path.read_text(encoding="utf-8"), "owner data")
        self.assertFalse((output_dir / "work_instruction_preview.csv").exists())

    def test_partial_publish_is_rolled_back_if_second_link_fails(self) -> None:
        output_dir = self.directory / "rollback-output"
        original_link = os.link
        call_count = 0

        def fail_second_link(source: str | os.PathLike[str], destination: str | os.PathLike[str]) -> None:
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                raise FileExistsError("simulated race")
            original_link(source, destination)

        with mock.patch.object(subject.os, "link", side_effect=fail_second_link):
            with self.assertRaises(subject.WorkInstructionError) as raised:
                subject.write_outputs(self.parsed, self.source.name, output_dir)
        self.assertEqual(raised.exception.code, "OUTPUT_EXISTS")
        self.assertEqual(list(output_dir.iterdir()), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
