"""Create reproducible JSON and CSV previews from the synthetic test fixture."""

from __future__ import annotations

import argparse
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import sop_to_work_instruction as subject
from tests.fixture_factory import sample_docx_bytes


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate local preview files from the synthetic test fixture.")
    parser.add_argument("--output-dir", required=True, help="New or empty directory for the JSON and CSV previews")
    arguments = parser.parse_args()

    with tempfile.TemporaryDirectory(prefix="synthetic_sop_fixture_") as temp_dir:
        source_path = Path(temp_dir) / "synthetic_sop.docx"
        source_path.write_bytes(sample_docx_bytes())
        try:
            parsed = subject.parse_docx(source_path)
            json_path, csv_path = subject.write_outputs(parsed, source_path.name, arguments.output_dir)
        except subject.WorkInstructionError as exc:
            print(f"ERROR[{exc.code}]: {exc.message}")
            return 2

    print(f"Fixture source SHA-256: {parsed['source_sha256']}")
    print(f"JSON: {json_path}")
    print(f"CSV: {csv_path}")
    print("The synthetic DOCX was created in a temporary directory and was not retained.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
