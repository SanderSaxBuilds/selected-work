"""Build minimal deterministic DOCX bytes for local parser tests."""

from __future__ import annotations

import io
import zipfile
from xml.sax.saxutils import escape


CONTENT_TYPES = b'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>'''

ROOT_RELS = b'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>'''


def paragraph(text: str, *, lines: list[str] | None = None, extra_run_xml: str = "") -> str:
    parts = lines if lines is not None else [text]
    runs = []
    for index, part in enumerate(parts):
        if index:
            runs.append("<w:br/>")
        runs.append(f"<w:r><w:t xml:space=\"preserve\">{escape(part)}</w:t></w:r>")
    return f"<w:p>{extra_run_xml}{''.join(runs)}</w:p>"


def document_xml(body_items: list[str]) -> bytes:
    body = "".join(body_items) + "<w:sectPr/>"
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        f"<w:body>{body}</w:body></w:document>"
    ).encode("utf-8")


def make_docx(
    body_items: list[str],
    *,
    extra_parts: list[tuple[str, bytes]] | None = None,
    document_xml_override: bytes | None = None,
) -> bytes:
    entries = [
        ("[Content_Types].xml", CONTENT_TYPES),
        ("_rels/.rels", ROOT_RELS),
        (
            "word/document.xml",
            document_xml_override if document_xml_override is not None else document_xml(body_items),
        ),
    ]
    entries.extend(extra_parts or [])
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w") as archive:
        for name, data in entries:
            info = zipfile.ZipInfo(name, date_time=(2020, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o600 << 16
            archive.writestr(info, data)
    return output.getvalue()


def sample_docx_bytes() -> bytes:
    return make_docx(
        [
            paragraph("Work Instruction: Review a sample café record"),
            paragraph("", lines=["Safety Notes: Synthetic example only.", "No equipment is involved."]),
            paragraph("", lines=["Step 1: Open the sample record.", "Check that the café record ID is present."]),
            paragraph("Step 2: Mark the sample record Complete."),
        ]
    )
