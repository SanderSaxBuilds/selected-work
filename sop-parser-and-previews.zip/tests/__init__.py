"""Test helpers for the local work instruction preview."""
