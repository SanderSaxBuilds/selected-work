Work-instruction extraction study

Independent portfolio code using fictional data. Python 3.12, standard library only.

This parser accepts one DOCX with an explicit manual paragraph template:
Work Instruction: followed by the title.
An optional Safety Notes: paragraph before steps.
Step 1: followed by the first step, then Step 2: and consecutive labels. Each step occupies one paragraph. Labels are case-sensitive.

Run tests from this folder:
python -m unittest -v tests.test_sop_to_work_instruction

Generate a fictional preview in a new output folder:
python tests/make_sample_preview.py --output-dir sample-output

Parse a supported document:
python sop_to_work_instruction.py input.docx --output-dir preview

JSON preserves source text. CSV prefixes formula-like text with an apostrophe. Both outputs retain source SHA-256 and one-based body paragraph references. Existing output paths are never overwritten.

Tables, automatic numbering, images, hyperlinks, fields, tracked changes, hidden text, macros and embedded objects are rejected. This is not an arbitrary Word parser. Headers, footers and other document parts are outside extraction scope.

ZIP limits: 8 MiB compressed source, 4 MiB per member, 16 MiB expanded. Unsupported input stops before publishing outputs.

No native Word rendering, customer acceptance, production benchmark or ION MES integration is established. A real integration needs an approved source sample, field mapping and test environment.
