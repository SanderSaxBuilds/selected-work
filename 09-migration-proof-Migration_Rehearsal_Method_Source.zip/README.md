# Synthetic migration rehearsal source

Independent method demonstration with deterministic transforms, relational schema, ordered import SQL, reconciliation notes and cutover/rollback documentation. No client project was migrated. No portable-password or verified production RLS claim. This bundle omits synthetic export and test fixtures with email-shaped values. It cannot run end-to-end without a separately reviewed synthetic export and identity map. Included auth map contains synthetic UUIDs, not credentials.
