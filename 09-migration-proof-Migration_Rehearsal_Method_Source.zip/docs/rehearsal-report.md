# Synthetic migration rehearsal report

## Purpose

This report records a repeatable rehearsal against the included synthetic export. It demonstrates the evidence a real migration would produce after the source inventory and target project are approved.

## Source and transform

- Source snapshot: `source/base44-export.sample.json`
- Export timestamp: `2026-09-20T12:00:00.000Z`
- Transform: `scripts/transform-export.mjs`
- Ordering rule: object keys canonicalized, then each entity sorted by `source_id`
- Conflict key: `source_id`
- Import order: users, projects, tasks

## Reconciled output

| Entity | Count | SHA-256 |
|---|---:|---|
| users | 2 | `3f2a60cc9b368c751e7b43b82f2234d6bb50c7407b55af262994c7d9169d4739` |
| projects | 1 | `0ecdbecf81e512c37541ce461553634b60653008550653b4a43533b8033c67a7` |
| tasks | 2 | `76fb6f271793ca51b693ae0650cf97a102637f6003e11e582a41d1255228158b` |

Rejected rows: 0

Overall manifest SHA-256: `83815b07fdc4d9d6af45eed4d780a7b010ecf9c7ed2eee326351378ca69c3688`

## Verified checks

- Reordering source arrays does not change the manifest or import plan.
- Missing owners and projects are rejected before build output is written.
- Duplicate source identifiers and normalized email collisions are rejected.
- Invalid dates and backwards project timestamps are rejected.
- The SQL migration uses source-ID uniqueness, foreign keys, indexes and row-level security policies.
- The schema test confirms transaction boundaries and absence of embedded credentials.

## Acceptance boundary

The rehearsal passes for the supplied synthetic data. A real engagement still requires a client-owned Supabase project, a read-only source inventory, an approved authentication path, a production backup, a maintenance window, authenticated and anonymous policy tests, target-side reconciliation and client approval before cutover.

## Import SQL rehearsal

The generated build/import.sql uses the explicit synthetic auth map, deterministic UUIDs for project and task rows, parent-before-child ordering, source-ID upserts and typed timestamps. It refuses to generate output when an authentication mapping is missing. It is a rehearsal artifact and must be reviewed against a client-owned schema before use.
