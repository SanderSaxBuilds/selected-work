# Schema review evidence

This review records what can be verified from the synthetic migration package before a real Supabase project exists.

## Verified from source

- The migration is wrapped in an explicit transaction.
- Profiles, projects and tasks have primary keys and mapped source identifiers.
- Project ownership and task parentage are enforced with foreign keys and cascade behavior.
- Status values are constrained at the database boundary.
- Foreign-key and status indexes are declared for the expected access paths.
- Updated timestamps are maintained by an invoker-security trigger function.
- Row-level security is enabled on every mapped table.
- Policies scope reads and writes to the authenticated owner, including task access through the parent project.
- No service-role token, JWT or other embedded secret appears in the migration.

## Automated evidence

The dependency-free schema test checks the transaction markers, mapped tables, foreign keys, retry keys, indexes, row-level security statements, ownership policy names, auth checks and absence of embedded secrets. The full migration suite passes with 12 tests and 0 failures.

## Boundary

Static SQL review does not replace applying the migration to a client-owned Supabase project and running authenticated and anonymous policy tests there. Those steps remain part of a commissioned rehearsal with a real project, approved credentials and a maintenance window.

## Additional hardening

Profiles now require a non-empty source identifier and unique email, with explicit owner-scoped insert, update and delete policies. The synthetic database fixture defines an isolated auth contract for optional local runtime tests. The fixture is not Supabase Auth and does not prove production RLS behavior.
 The target runtime must confirm that its supported Postgres version provides `gen_random_uuid()` before applying this migration.
