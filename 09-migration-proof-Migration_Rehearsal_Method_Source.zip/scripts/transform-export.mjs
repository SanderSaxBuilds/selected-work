import fs from "node:fs"
import { createHash } from "node:crypto"
import path from "node:path"
import process from "node:process"
import { fileURLToPath } from "node:url"

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const STATUS = new Map([
  ["active", "active"],
  ["archived", "archived"],
  ["not started", "todo"],
  ["in progress", "in_progress"],
  ["complete", "done"],
  ["completed", "done"]
])

function canonicalize(value) {
  if (Array.isArray(value)) return value.map(canonicalize)
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .map((key) => [key, canonicalize(value[key])])
    )
  }
  return value
}

export function stableStringify(value) {
  return JSON.stringify(canonicalize(value))
}

export function sha256(value) {
  return createHash("sha256").update(value, "utf8").digest("hex")
}

function sortedBySourceId(rows) {
  return [...rows].sort((left, right) => left.source_id.localeCompare(right.source_id))
}

function entityDigest(rows) {
  const canonicalRows = sortedBySourceId(rows)
  return {
    count: canonicalRows.length,
    sha256: sha256(stableStringify(canonicalRows))
  }
}

export function buildManifest(transformed) {
  const entities = {
    users: entityDigest(transformed.users),
    projects: entityDigest(transformed.projects),
    tasks: entityDigest(transformed.tasks)
  }
  const manifestCore = {
    algorithm: "sha256",
    canonicalization: "sorted object keys and source_id ascending within each entity",
    exported_at: transformed.exported_at,
    entities
  }
  return {
    ...manifestCore,
    overall_sha256: sha256(stableStringify(manifestCore))
  }
}

export function createImportPlan(transformed) {
  return {
    mode: "upsert",
    conflict_target: "source_id",
    order: ["users", "projects", "tasks"],
    entities: Object.fromEntries(
      ["users", "projects", "tasks"].map((entity) => [
        entity,
        sortedBySourceId(transformed[entity]).map(({ source_id }) => ({ source_id }))
      ])
    )
  }
}

function requiredString(value, label) {
  if (typeof value !== "string" || value.trim() === "") {
    throw new Error(`${label} must be a non-empty string`)
  }
  return value.trim()
}

function iso(value, label, nullable = false) {
  if (value == null && nullable) return null
  const raw = requiredString(value, label)
  const parsed = new Date(raw)
  if (Number.isNaN(parsed.getTime())) throw new Error(`${label} must be an ISO date`)
  return parsed.toISOString()
}

function status(value, label) {
  const normalized = STATUS.get(requiredString(value, label).toLowerCase())
  if (!normalized) throw new Error(`${label} has an unsupported value`)
  return normalized
}

export function transformExport(source) {
  if (!source || typeof source !== "object") throw new Error("export must be an object")
  for (const key of ["users", "projects", "tasks"]) {
    if (source[key] !== undefined && !Array.isArray(source[key])) {
      throw new Error(`${key} must be an array`)
    }
  }
  const users = Array.isArray(source.users) ? source.users : []
  const projects = Array.isArray(source.projects) ? source.projects : []
  const tasks = Array.isArray(source.tasks) ? source.tasks : []

  const userIds = new Set()
  const userEmails = new Set()
  const mappedUsers = users.map((row, index) => {
    const sourceId = requiredString(row.id, `users[${index}].id`)
    const email = requiredString(row.email, `users[${index}].email`).toLowerCase()
    if (!EMAIL_RE.test(email)) throw new Error(`users[${index}].email is invalid`)
    if (userIds.has(sourceId)) throw new Error(`duplicate user id ${sourceId}`)
    if (userEmails.has(email)) throw new Error(`duplicate user email ${email}`)
    userIds.add(sourceId)
    userEmails.add(email)
    return {
      source_id: sourceId,
      email,
      display_name: requiredString(row.displayName, `users[${index}].displayName`),
      created_at: iso(row.createdAt, `users[${index}].createdAt`)
    }
  })

  const projectIds = new Set()
  const mappedProjects = projects.map((row, index) => {
    const sourceId = requiredString(row.id, `projects[${index}].id`)
    const ownerSourceId = requiredString(row.ownerId, `projects[${index}].ownerId`)
    if (!userIds.has(ownerSourceId)) throw new Error(`projects[${index}] references missing owner ${ownerSourceId}`)
    if (projectIds.has(sourceId)) throw new Error(`duplicate project id ${sourceId}`)
    projectIds.add(sourceId)
    const createdAt = iso(row.createdAt, `projects[${index}].createdAt`)
    const updatedAt = iso(row.updatedAt, `projects[${index}].updatedAt`)
    if (new Date(updatedAt) < new Date(createdAt)) {
      throw new Error(`projects[${index}].updatedAt must not be before createdAt`)
    }
    return {
      source_id: sourceId,
      owner_source_id: ownerSourceId,
      name: requiredString(row.name, `projects[${index}].name`),
      status: status(row.status, `projects[${index}].status`),
      created_at: createdAt,
      updated_at: updatedAt
    }
  })

  const taskIds = new Set()
  const mappedTasks = tasks.map((row, index) => {
    const sourceId = requiredString(row.id, `tasks[${index}].id`)
    const projectSourceId = requiredString(row.projectId, `tasks[${index}].projectId`)
    if (!projectIds.has(projectSourceId)) throw new Error(`tasks[${index}] references missing project ${projectSourceId}`)
    if (taskIds.has(sourceId)) throw new Error(`duplicate task id ${sourceId}`)
    taskIds.add(sourceId)
    return {
      source_id: sourceId,
      project_source_id: projectSourceId,
      title: requiredString(row.title, `tasks[${index}].title`),
      status: status(row.status, `tasks[${index}].status`),
      due_at: iso(row.dueAt, `tasks[${index}].dueAt`, true)
    }
  })

  const transformed = {
    exported_at: iso(source.exportedAt, "exportedAt"),
    users: sortedBySourceId(mappedUsers),
    projects: sortedBySourceId(mappedProjects),
    tasks: sortedBySourceId(mappedTasks),
    reconciliation: {
      users: mappedUsers.length,
      projects: mappedProjects.length,
      tasks: mappedTasks.length,
      rejected: 0
    }
  }
  transformed.manifest = buildManifest(transformed)
  transformed.reconciliation.manifest_sha256 = transformed.manifest.overall_sha256
  return transformed
}

export function writeBuild(transformed, outputDir) {
  fs.mkdirSync(outputDir, { recursive: true })
  for (const key of ["users", "projects", "tasks"]) {
    fs.writeFileSync(path.join(outputDir, `${key}.json`), `${JSON.stringify(transformed[key], null, 2)}\n`)
  }
  fs.writeFileSync(path.join(outputDir, "reconciliation.json"), `${JSON.stringify(transformed.reconciliation, null, 2)}\n`)
  fs.writeFileSync(path.join(outputDir, "manifest.json"), `${JSON.stringify(transformed.manifest, null, 2)}\n`)
  fs.writeFileSync(path.join(outputDir, "import-plan.json"), `${JSON.stringify(createImportPlan(transformed), null, 2)}\n`)
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
if (isMain) {
  const inputPath = path.resolve(process.argv[2] || "source/base44-export.sample.json")
  const outputDir = path.resolve(process.argv[3] || "build")
  const transformed = transformExport(JSON.parse(fs.readFileSync(inputPath, "utf8")))
  writeBuild(transformed, outputDir)
  process.stdout.write(`${JSON.stringify(transformed.reconciliation)}\n`)
}
