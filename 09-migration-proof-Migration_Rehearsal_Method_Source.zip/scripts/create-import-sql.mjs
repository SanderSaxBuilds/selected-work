import fs from "node:fs"
import { createHash } from "node:crypto"
import path from "node:path"
import process from "node:process"
import { fileURLToPath } from "node:url"

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

function sqlString(value) {
  return `'${String(value).replaceAll("'", "''")}'`
}

function sqlNullable(value) {
  return value == null ? "null" : sqlString(value)
}

export function deterministicUuid(namespace, sourceId) {
  const digest = createHash("sha256").update(`${namespace}:${sourceId}`, "utf8").digest()
  const bytes = Buffer.from(digest.subarray(0, 16))
  bytes[6] = (bytes[6] & 0x0f) | 0x50
  bytes[8] = (bytes[8] & 0x3f) | 0x80
  const hex = bytes.toString("hex")
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`
}

function validateAuthMap(transformed, authMap) {
  if (!authMap || typeof authMap !== "object" || Array.isArray(authMap)) {
    throw new Error("authMap must be an object keyed by source user id")
  }
  for (const user of transformed.users) {
    const targetId = authMap[user.source_id]
    if (!UUID_RE.test(String(targetId || ""))) {
      throw new Error(`authMap is missing a valid target UUID for ${user.source_id}`)
    }
  }
}

export function createImportSql(transformed, authMap) {
  validateAuthMap(transformed, authMap)
  const projectIds = new Map(transformed.projects.map((row) => [row.source_id, deterministicUuid("project", row.source_id)]))
  const lines = [
    "begin;",
    "",
    "-- Generated from a validated synthetic transform. Review against the client schema before use.",
    "-- Authentication users must already exist in auth.users and be represented in authMap.",
    ""
  ]
  for (const user of transformed.users) {
    const id = authMap[user.source_id]
    lines.push(`insert into public.profiles (id, source_id, display_name, created_at) values (${sqlString(id)}::uuid, ${sqlString(user.source_id)}, ${sqlString(user.display_name)}, ${sqlString(user.created_at)}::timestamptz) on conflict (source_id) do update set display_name = excluded.display_name, created_at = excluded.created_at;`)
  }
  lines.push("")
  for (const project of transformed.projects) {
    const id = projectIds.get(project.source_id)
    const ownerId = authMap[project.owner_source_id]
    lines.push(`insert into public.projects (id, source_id, owner_id, name, status, created_at, updated_at) values (${sqlString(id)}::uuid, ${sqlString(project.source_id)}, ${sqlString(ownerId)}::uuid, ${sqlString(project.name)}, ${sqlString(project.status)}, ${sqlString(project.created_at)}::timestamptz, ${sqlString(project.updated_at)}::timestamptz) on conflict (source_id) do update set owner_id = excluded.owner_id, name = excluded.name, status = excluded.status, created_at = excluded.created_at, updated_at = excluded.updated_at;`)
  }
  lines.push("")
  for (const task of transformed.tasks) {
    const id = deterministicUuid("task", task.source_id)
    const projectId = projectIds.get(task.project_source_id)
    lines.push(`insert into public.tasks (id, source_id, project_id, title, status, due_at) values (${sqlString(id)}::uuid, ${sqlString(task.source_id)}, ${sqlString(projectId)}::uuid, ${sqlString(task.title)}, ${sqlString(task.status)}, ${sqlNullable(task.due_at)}${task.due_at == null ? "" : "::timestamptz"}) on conflict (source_id) do update set project_id = excluded.project_id, title = excluded.title, status = excluded.status, due_at = excluded.due_at;`)
  }
  lines.push("", "commit;", "")
  return lines.join("\n")
}

export function writeImportSql(transformed, authMap, outputPath) {
  const absolute = path.resolve(outputPath)
  fs.mkdirSync(path.dirname(absolute), { recursive: true })
  fs.writeFileSync(absolute, createImportSql(transformed, authMap), "utf8")
  return absolute
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
if (isMain) {
  const inputPath = path.resolve(process.argv[2] || "source/base44-export.sample.json")
  const authMapPath = path.resolve(process.argv[3] || "source/auth-map.sample.json")
  const outputPath = path.resolve(process.argv[4] || "build/import.sql")
  const { transformExport } = await import("./transform-export.mjs")
  const transformed = transformExport(JSON.parse(fs.readFileSync(inputPath, "utf8")))
  const authMap = JSON.parse(fs.readFileSync(authMapPath, "utf8"))
  writeImportSql(transformed, authMap, outputPath)
  process.stdout.write(`${outputPath}\n`)
}
