"""Write the fictional input CSVs for the expense report sample (six months, four categories)."""
import csv
import sys
from pathlib import Path

out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)

tx = []
def add(date, cat, supplier, desc, amount):
    tx.append((date, cat, supplier, desc, f"{amount:.2f}"))

utilities = [180.20, 196.40, 205.00, 171.35, 158.90, 162.75]
for m in range(1, 7):
    mm = f"2026-{m:02d}"
    add(f"{mm}-05", "Facilities", "Harbour Lane Properties", "Office rent", 1200.00)
    add(f"{mm}-11", "Software", "Ledgerly", "Accounting subscription", 75.00)
    if m >= 2:
        add(f"{mm}-14", "Software", "Canvasworks", "Design tools", 54.00)
    add(f"{mm}-20", "Software", "Stowbox", "Cloud backup", 12.99)
    add(f"{mm}-24", "Facilities", "Northgrid Energy", "Electricity and water", utilities[m - 1])

add("2026-01-21", "Travel", "Railway ticket office", "Client visit, Leeds", 210.50)
add("2026-02-17", "Travel", "Railway ticket office", "Client visit, York", 315.25)
add("2026-02-22", "Travel", "Railway ticket office", "Ticket refund, York", -25.00)
add("2026-03-18", "Travel", "City Cabs", "Client visit, local", 112.75)
add("2026-04-09", "Travel", "Railway ticket office", "Client workshop, Bristol", 286.40)
add("2026-05-06", "Travel", "Railway ticket office", "Client visit, Leeds", 148.60)
add("2026-05-06", "Travel", "City Cabs", "Station transfer", 64.20)
add("2026-06-16", "Travel", "Westway Hotels", "Trade fair, two nights", 402.10)
add("2026-02-03", "Equipment", "Deskline", "27-inch monitor", 289.00)
add("2026-03-12", "Equipment", "Deskline", "Cables and adapters", 46.50)
add("2026-05-19", "Equipment", "Deskline", "Laptop stand", 72.00)
add("2026-05-19", "Equipment", "Deskline", "Keyboard", 118.00)
add("2026-06-02", "Equipment", "Deskline", "Return, keyboard", -118.00)

tx.sort(key=lambda r: (r[0], r[1]))
with open(out / "transactions.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["transaction_id", "date", "category", "supplier", "description", "amount"])
    for i, r in enumerate(tx, 1):
        w.writerow([f"TX-{i:03d}", *r])

budgets = {"Facilities": 1500.00, "Software": 150.00, "Travel": 300.00, "Equipment": 150.00}
with open(out / "budgets.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["month", "category", "budget"])
    for m in range(1, 7):
        for c, b in budgets.items():
            w.writerow([f"2026-{m:02d}", c, f"{b:.2f}"])
print(len(tx), "transactions")
