# Expense report source

Builds a formula-linked Excel expense report from two CSV files: transactions and monthly budgets. The workbook has a summary with monthly and category tables, a native chart, a monthly variance sheet with prior-month comparison, and reconciliation checks. Every total is a live formula over ranges that run to row 1000, so rows added later are picked up without rebuilding.

## Run

```
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt
.venv\Scripts\python report_builder.py examples expense-report.xlsx
```

Open the result in Excel. Formulas calculate when the file opens.

## Inputs

`transactions.csv` has transaction_id, date (YYYY-MM-DD), category, supplier, description and amount in US dollars. Refunds are negative amounts.

`budgets.csv` has month (YYYY-MM), category and budget in US dollars, one row per month and category.

`expected-summary.csv` lists the totals the example inputs should produce, for checking a build.

## Scope

The example company, suppliers and figures are fictional. This is a reporting workbook, not an accounting system, and it does not handle currencies other than US dollars.
