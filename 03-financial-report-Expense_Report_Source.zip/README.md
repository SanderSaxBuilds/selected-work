# Expense report source

CSV and TSV workflow that builds a formula-linked Excel report with monthly and category analysis, exact-cent aggregation, a summary and chart. Example inputs and expected summary are included. Fictional workbook supplied separately. Not a general accounting system.
