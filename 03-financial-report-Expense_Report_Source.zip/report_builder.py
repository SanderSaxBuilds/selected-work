"""Build the expense report workbook from transactions.csv and budgets.csv.

Every total in the workbook is a live formula. Ranges run to row 1000, so rows added
at the bottom of Transactions or Budgets are picked up without rebuilding.

Usage: python report_builder.py <inputs_dir> <output.xlsx>
"""
import csv
import sys
from datetime import date
from decimal import Decimal
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.chart.axis import ChartLines
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.drawing.line import LineProperties
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.table import Table, TableStyleInfo

LAST = 1000
# Linden Studio house style: sober charcoal headers, a dusty plum accent on totals and checks.
INK, MUTED, CHARCOAL, PLUM, PLUM_TINT, GREY, LINE, ERROR = "1F2328", "5F6368", "2E3238", "7D4E6B", "F3ECF1", "BFC3C8", "DCDDE0", "B4412F"
FONT = "Calibri"
TITLE_FONT = "Georgia"
# The _) padding keeps positive figures aligned with bracketed negatives.
MONEY = '#,##0.00_);(#,##0.00);"-"_)'
PCT = '0.0%_);(0.0%);"-"_)'

f_body = Font(name=FONT, size=11, color=INK)
f_input = Font(name=FONT, size=11, color="0000FF")
f_head = Font(name=FONT, size=11, bold=True, color="FFFFFF")
f_bold = Font(name=FONT, size=11, bold=True, color=INK)
f_total = Font(name=FONT, size=11, bold=True, color=PLUM)
f_muted = Font(name=FONT, size=10, color=MUTED)
f_section = Font(name=TITLE_FONT, size=13, color=INK)
fill_head = PatternFill("solid", fgColor=CHARCOAL)
fill_total = PatternFill("solid", fgColor=PLUM_TINT)
thin = Side(style="thin", color=LINE)
rule = Side(style="medium", color=INK)
rule_total = Side(style="medium", color=PLUM)


def read(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def header(ws, row, labels, numeric_from=None):
    for i, label in enumerate(labels, 1):
        c = ws.cell(row=row, column=i, value=label)
        c.font, c.fill = f_head, fill_head
        c.alignment = Alignment(horizontal="right" if numeric_from and i >= numeric_from else "left", vertical="center")
    ws.row_dimensions[row].height = 22


def widths(ws, values):
    for i, w in enumerate(values, 1):
        ws.column_dimensions[get_column_letter(i)].width = w


def setup_print(ws, title_rows=None, landscape=True):
    ws.page_setup.orientation = "landscape" if landscape else "portrait"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth, ws.page_setup.fitToHeight = 1, 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    ws.page_margins.left = ws.page_margins.right = 0.5
    if title_rows:
        ws.print_title_rows = title_rows
    ws.oddFooter.left.text = "&A"
    ws.oddFooter.right.text = "Page &P of &N"


def build(inputs: Path, output: Path):
    tx = read(inputs / "transactions.csv")
    bd = read(inputs / "budgets.csv")
    months = sorted({r["month"] for r in bd})
    cats = list(dict.fromkeys(r["category"] for r in bd))

    wb = Workbook()
    summary = wb.active
    summary.title = "Summary"
    monthly = wb.create_sheet("Monthly")
    trans = wb.create_sheet("Transactions")
    budgets = wb.create_sheet("Budgets")
    lists = wb.create_sheet("Lists")

    # ---------- Lists (category names used by validation) ----------
    lists["A1"] = "Category"
    lists["A1"].font = f_bold
    for i, c in enumerate(cats, 2):
        lists.cell(row=i, column=1, value=c).font = f_input
    lists["C1"] = "Categories used by the drop-downs on Transactions and Budgets. Add a new category here first."
    lists["C1"].font = f_muted
    lists.column_dimensions["A"].width = 18
    lists.sheet_state = "visible"

    # ---------- Transactions ----------
    header(trans, 1, ["Transaction ID", "Date", "Category", "Supplier", "Description", "Amount (USD)"], numeric_from=6)
    for r, t in enumerate(tx, 2):
        y, m, d = map(int, t["date"].split("-"))
        vals = [t["transaction_id"], date(y, m, d), t["category"], t["supplier"], t["description"], float(Decimal(t["amount"]))]
        for c, v in enumerate(vals, 1):
            cell = trans.cell(row=r, column=c, value=v)
            cell.font = f_input
        trans.cell(row=r, column=2).number_format = "yyyy-mm-dd"
        trans.cell(row=r, column=6).number_format = MONEY
    end_tx = len(tx) + 1
    t = Table(displayName="TransactionsTable", ref=f"A1:F{end_tx}")
    t.tableStyleInfo = TableStyleInfo(name="TableStyleLight1", showRowStripes=True)
    trans.add_table(t)
    widths(trans, [15, 13, 15, 26, 30, 15])
    trans.freeze_panes = "A2"
    dv = DataValidation(type="list", formula1=f"=Lists!$A$2:$A$20", allow_blank=True, showErrorMessage=True,
                        errorTitle="Unknown category", error="Pick a category from the list on the Lists sheet.")
    trans.add_data_validation(dv)
    dv.add(f"C2:C{LAST}")
    setup_print(trans, "1:1")

    # ---------- Budgets ----------
    header(budgets, 1, ["Month", "Category", "Budget (USD)"], numeric_from=3)
    for r, b in enumerate(bd, 2):
        y, m = map(int, b["month"].split("-"))
        for c, v in enumerate([date(y, m, 1), b["category"], float(Decimal(b["budget"]))], 1):
            budgets.cell(row=r, column=c, value=v).font = f_input
        budgets.cell(row=r, column=1).number_format = "mmm yyyy"
        budgets.cell(row=r, column=3).number_format = MONEY
    end_bd = len(bd) + 1
    t = Table(displayName="BudgetsTable", ref=f"A1:C{end_bd}")
    t.tableStyleInfo = TableStyleInfo(name="TableStyleLight1", showRowStripes=True)
    budgets.add_table(t)
    dv2 = DataValidation(type="list", formula1=f"=Lists!$A$2:$A$20", allow_blank=True)
    budgets.add_data_validation(dv2)
    dv2.add(f"B2:B{LAST}")
    widths(budgets, [13, 15, 15])
    budgets.freeze_panes = "A2"
    setup_print(budgets, "1:1", landscape=False)

    TX_D, TX_C, TX_A = f"Transactions!$B$2:$B${LAST}", f"Transactions!$C$2:$C${LAST}", f"Transactions!$F$2:$F${LAST}"
    BD_M, BD_C, BD_A = f"Budgets!$A$2:$A${LAST}", f"Budgets!$B$2:$B${LAST}", f"Budgets!$C$2:$C${LAST}"

    # ---------- Monthly: one row per budget line, mirrored from Budgets ----------
    header(monthly, 1, ["Month", "Category", "Actual (USD)", "Budget (USD)", "Under or over", "Budget used",
                        "Prior month actual", "Change on prior month", "Transactions"], numeric_from=3)
    rows = max(len(bd) + 24, 48)
    for r in range(2, rows + 2):
        k = f"Budgets!A{r}"
        f = {
            "A": f'=IF({k}="","",{k})',
            "B": f'=IF({k}="","",Budgets!B{r})',
            "C": f'=IF($A{r}="","",SUMIFS({TX_A},{TX_C},$B{r},{TX_D},">="&$A{r},{TX_D},"<"&EDATE($A{r},1)))',
            "D": f'=IF($A{r}="","",Budgets!C{r})',
            "E": f'=IF($A{r}="","",D{r}-C{r})',
            "F": f'=IF(OR($A{r}="",N(D{r})=0),"",C{r}/D{r})',
            "G": f'=IF($A{r}="","",SUMIFS({TX_A},{TX_C},$B{r},{TX_D},">="&EDATE($A{r},-1),{TX_D},"<"&$A{r}))',
            "H": f'=IF($A{r}="","",C{r}-G{r})',
            "I": f'=IF($A{r}="","",COUNTIFS({TX_C},$B{r},{TX_D},">="&$A{r},{TX_D},"<"&EDATE($A{r},1)))',
        }
        for col, formula in f.items():
            cell = monthly[f"{col}{r}"]
            cell.value, cell.font = formula, f_body
            cell.number_format = {"A": "mmm yyyy", "F": PCT, "I": "0"}.get(col, MONEY)
            cell.border = Border(bottom=thin)
            if col not in "AB":
                cell.alignment = Alignment(horizontal="right")
    monthly.conditional_formatting.add(f"F2:F{rows + 1}", FormulaRule(formula=[f'AND(ISNUMBER(F2),F2>1)'], font=Font(name=FONT, size=11, color=ERROR, bold=True)))
    widths(monthly, [12, 14, 14, 14, 14, 13, 18, 22, 13])
    monthly.freeze_panes = "C2"
    monthly.auto_filter.ref = f"A1:I{rows + 1}"
    monthly["K1"] = "Under or over is budget less actual: positive is under budget, brackets are over. The first month has no prior month in this data."
    monthly["K1"].font = f_muted
    setup_print(monthly, "1:1")

    # ---------- Summary ----------
    ws = summary
    ws.sheet_view.showGridLines = False
    ws["A1"] = "Linden Studio operating expenses"
    ws["A1"].font = Font(name=TITLE_FONT, size=18, color=INK)
    ws["A2"] = "January to June 2026, US dollars. Linden Studio is a fictional company and all figures are illustrative."
    ws["A2"].font = f_muted

    kpis = [
        ("Reporting months", f'=SUMPRODUCT(({BD_M}<>"")/COUNTIF({BD_M},{BD_M}&""))', "0"),
        ("Transactions", f"=COUNT({TX_A})", "0"),
        ("Actual spend", f"=SUM({TX_A})", MONEY),
        ("Budget", f"=SUM({BD_A})", MONEY),
        ("Under or over budget", "=B7-B6", MONEY),
        ("Budget used", '=IF(B7=0,"",B6/B7)', PCT),
        ("Average spend per month", '=IF(B4=0,"",B6/B4)', MONEY),
    ]
    for i, (label, formula, fmt) in enumerate(kpis, 4):
        ws.cell(row=i, column=1, value=label).font = f_body
        c = ws.cell(row=i, column=2, value=formula)
        c.font, c.number_format, c.alignment = f_bold, fmt, Alignment(horizontal="right")
        for col in (1, 2):
            ws.cell(row=i, column=col).border = Border(bottom=thin)
    for col in (1, 2):
        ws.cell(row=4, column=col).border = Border(top=rule, bottom=thin)

    # month table
    top = 13
    ws.cell(row=top - 1, column=1, value="By month").font = f_section
    header_row = top
    labels = ["Month", "Actual (USD)", "Budget (USD)", "Under or over", "Budget used"]
    for i, label in enumerate(labels, 1):
        c = ws.cell(row=header_row, column=i, value=label)
        c.font, c.fill = f_head, fill_head
        c.alignment = Alignment(horizontal="left" if i == 1 else "right", vertical="center")
    ws.row_dimensions[header_row].height = 22
    for j, m in enumerate(months):
        r = header_row + 1 + j
        y, mo = map(int, m.split("-"))
        ws.cell(row=r, column=1, value=date(y, mo, 1) if j == 0 else f"=EDATE(A{r - 1},1)").font = f_input if j == 0 else f_body
        ws.cell(row=r, column=1).number_format = "mmm yyyy"
        ws.cell(row=r, column=1).alignment = Alignment(horizontal="left")
        ws.cell(row=r, column=2, value=f'=SUMIFS({TX_A},{TX_D},">="&A{r},{TX_D},"<"&EDATE(A{r},1))')
        ws.cell(row=r, column=3, value=f"=SUMIFS({BD_A},{BD_M},A{r})")
        ws.cell(row=r, column=4, value=f"=C{r}-B{r}")
        ws.cell(row=r, column=5, value=f'=IF(C{r}=0,"",B{r}/C{r})')
        for col in range(1, 6):
            c = ws.cell(row=r, column=col)
            if col > 1:
                c.font, c.number_format, c.alignment = f_body, PCT if col == 5 else MONEY, Alignment(horizontal="right")
            c.border = Border(bottom=thin)
    tr = header_row + len(months) + 1
    first, last = header_row + 1, tr - 1
    ws.cell(row=tr, column=1, value="Total")
    ws.cell(row=tr, column=2, value=f"=SUM(B{first}:B{last})")
    ws.cell(row=tr, column=3, value=f"=SUM(C{first}:C{last})")
    ws.cell(row=tr, column=4, value=f"=C{tr}-B{tr}")
    ws.cell(row=tr, column=5, value=f'=IF(C{tr}=0,"",B{tr}/C{tr})')
    for col in range(1, 6):
        c = ws.cell(row=tr, column=col)
        c.font, c.fill, c.border = f_total, fill_total, Border(top=rule_total, bottom=rule_total)
        if col > 1:
            c.number_format, c.alignment = PCT if col == 5 else MONEY, Alignment(horizontal="right")
    ws.conditional_formatting.add(f"E{first}:E{tr}", FormulaRule(formula=[f"AND(ISNUMBER(E{first}),E{first}>1)"], font=Font(name=FONT, size=11, color=ERROR, bold=True)))

    # category table
    ct = tr + 3
    ws.cell(row=ct - 1, column=1, value="By category").font = f_section
    for i, label in enumerate(["Category", "Actual (USD)", "Budget (USD)", "Under or over", "Budget used"], 1):
        c = ws.cell(row=ct, column=i, value=label)
        c.font, c.fill = f_head, fill_head
        c.alignment = Alignment(horizontal="left" if i == 1 else "right", vertical="center")
    ws.row_dimensions[ct].height = 22
    for j, cat in enumerate(cats):
        r = ct + 1 + j
        ws.cell(row=r, column=1, value=f"=Lists!A{2 + j}").font = f_body
        ws.cell(row=r, column=2, value=f"=SUMIFS({TX_A},{TX_C},A{r})")
        ws.cell(row=r, column=3, value=f"=SUMIFS({BD_A},{BD_C},A{r})")
        ws.cell(row=r, column=4, value=f"=C{r}-B{r}")
        ws.cell(row=r, column=5, value=f'=IF(C{r}=0,"",B{r}/C{r})')
        for col in range(1, 6):
            c = ws.cell(row=r, column=col)
            if col > 1:
                c.font, c.number_format, c.alignment = f_body, PCT if col == 5 else MONEY, Alignment(horizontal="right")
            c.border = Border(bottom=thin)
    ctr = ct + len(cats) + 1
    ws.cell(row=ctr, column=1, value="Total")
    ws.cell(row=ctr, column=2, value=f"=SUM(B{ct + 1}:B{ctr - 1})")
    ws.cell(row=ctr, column=3, value=f"=SUM(C{ct + 1}:C{ctr - 1})")
    ws.cell(row=ctr, column=4, value=f"=C{ctr}-B{ctr}")
    ws.cell(row=ctr, column=5, value=f'=IF(C{ctr}=0,"",B{ctr}/C{ctr})')
    for col in range(1, 6):
        c = ws.cell(row=ctr, column=col)
        c.font, c.fill, c.border = f_total, fill_total, Border(top=rule_total, bottom=rule_total)
        if col > 1:
            c.number_format, c.alignment = PCT if col == 5 else MONEY, Alignment(horizontal="right")
    ws.conditional_formatting.add(f"E{ct + 1}:E{ctr}", FormulaRule(formula=[f"AND(ISNUMBER(E{ct + 1}),E{ct + 1}>1)"], font=Font(name=FONT, size=11, color=ERROR, bold=True)))

    # reconciliation checks
    ck = ctr + 2
    ws.cell(row=ck, column=1, value="Checks").font = f_section
    checks = [
        ("Months add up to actual spend", f'=IF(ROUND(B{tr}-B6,2)=0,"OK","Check: a transaction falls outside the months listed")'),
        ("Categories add up to actual spend", f'=IF(ROUND(B{ctr}-B6,2)=0,"OK","Check: a transaction has an unlisted category")'),
        ("Budgets add up by month and category", f'=IF(AND(ROUND(C{tr}-B7,2)=0,ROUND(C{ctr}-B7,2)=0),"OK","Check the Budgets sheet")'),
    ]
    for i, (label, formula) in enumerate(checks, ck + 1):
        ws.cell(row=i, column=1, value=label).font = f_body
        c = ws.cell(row=i, column=2, value=formula)
        c.font, c.alignment = f_bold, Alignment(horizontal="right")
        for col in (1, 2):
            ws.cell(row=i, column=col).border = Border(bottom=thin)
    ws.conditional_formatting.add(f"B{ck + 1}:B{ck + len(checks)}", FormulaRule(formula=[f'B{ck + 1}<>"OK"'], font=Font(name=FONT, size=11, color=ERROR, bold=True)))
    ws.conditional_formatting.add(f"B{ck + 1}:B{ck + len(checks)}", FormulaRule(formula=[f'B{ck + 1}="OK"'], font=Font(name=FONT, size=11, color=PLUM, bold=True), fill=PatternFill("solid", fgColor=PLUM_TINT, bgColor=PLUM_TINT)))

    note = ck + len(checks) + 2
    notes = [
        "How to use this workbook",
        "Add spending as new rows at the bottom of Transactions. Positive amounts are spend and negative amounts are refunds.",
        "Add or change budgets on the Budgets sheet, one row per month and category. Monthly mirrors those rows.",
        "Blue text marks values you type. Black text is calculated. Every total updates on its own.",
        "To report a different period, change the first month in the By month table.",
    ]
    for i, text in enumerate(notes):
        c = ws.cell(row=note + i, column=1, value=text)
        c.font = f_section if i == 0 else f_muted

    widths(ws, [36, 16, 16, 16, 14])
    for col in "GHIJKLMN":
        ws.column_dimensions[col].width = 10

    chart = BarChart()
    chart.type = "col"
    chart.grouping = "clustered"
    ws.cell(row=header_row - 1, column=7, value="Actual and budget by month, USD").font = f_section
    chart.add_data(Reference(ws, min_col=2, max_col=3, min_row=header_row, max_row=last), titles_from_data=True)
    chart.set_categories(Reference(ws, min_col=1, min_row=first, max_row=last))
    chart.series[0].graphicalProperties.solidFill = PLUM
    chart.series[0].graphicalProperties.line.solidFill = PLUM
    chart.series[1].graphicalProperties.solidFill = GREY
    chart.series[1].graphicalProperties.line.solidFill = GREY
    chart.gapWidth = 60
    chart.overlap = -6
    chart.legend.position = "t"
    chart.legend.overlay = False
    chart.y_axis.numFmt = "#,##0"
    chart.y_axis.majorGridlines = ChartLines(spPr=GraphicalProperties(ln=LineProperties(solidFill=LINE)))
    chart.x_axis.number_format = "mmm"
    chart.x_axis.delete = False
    chart.y_axis.delete = False
    chart.width, chart.height = 17.5, 9.5
    ws.add_chart(chart, f"G{header_row}")
    setup_print(ws, None, landscape=True)

    wb.active = 0
    output.parent.mkdir(parents=True, exist_ok=True)
    wb.properties.title = "Linden Studio operating expenses"
    wb.properties.creator = "SanderSax"
    wb.save(output)
    return {"months": len(months), "transactions": len(tx), "summary_total_row": tr, "category_total_row": ctr, "checks_row": ck + 1}


if __name__ == "__main__":
    info = build(Path(sys.argv[1]), Path(sys.argv[2]))
    print(info)
