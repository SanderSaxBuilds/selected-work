"""Generate a formula-linked operating expense workbook from CSV or TSV inputs."""

from __future__ import annotations

import argparse
import csv
import io
import os
import re
import tempfile
import zipfile
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.workbook.properties import CalcProperties

MAX_AMOUNT = Decimal("999999999999.99")
MIN_DATE = date(1900, 1, 1)
MAX_DATE = date(9998, 12, 31)


@dataclass(frozen=True)
class Transaction:
    transaction_id: str
    day: date
    category: str
    description: str
    amount: Decimal


@dataclass(frozen=True)
class Budget:
    month: date
    category: str
    amount: Decimal


def _read_rows(path: Path, required: set[str]) -> list[dict[str, str]]:
    if not path.is_file():
        raise ValueError(f"Input file does not exist: {path}")
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        if path.suffix.lower() not in {".csv", ".tsv"}:
            raise ValueError(f"{path.name}: input must use a .csv or .tsv extension")
        delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
        reader = csv.DictReader(handle, delimiter=delimiter, strict=True)
        try:
            headers = reader.fieldnames or []
            if len(headers) != len(set(headers)) or any(not header.strip() for header in headers):
                raise ValueError(f"{path.name} has duplicate or blank column headers")
            missing = required - set(headers)
            if missing:
                raise ValueError(f"{path.name} is missing columns: {', '.join(sorted(missing))}")
            rows = list(reader)
        except csv.Error as error:
            raise ValueError(f"{path.name}: malformed delimited data: {error}") from None
        for index, row in enumerate(rows, start=2):
            if None in row or any(value is None for value in row.values()):
                raise ValueError(f"{path.name} row {index} has a different number of columns than its header")
    if not rows:
        raise ValueError(f"{path.name} has no data rows")
    return rows


def _amount(value: str, source: str) -> Decimal:
    if not isinstance(value, str) or not re.fullmatch(r"-?[0-9]+(?:\.[0-9]{1,2})?", value.strip()):
        raise ValueError(f"{source}: amount must be a decimal number with at most two decimal places")
    try:
        result = Decimal(value.strip())
    except (AttributeError, InvalidOperation):
        raise ValueError(f"{source}: amount must be a decimal number") from None
    if not result.is_finite() or result.as_tuple().exponent < -2:
        raise ValueError(f"{source}: amount must be finite with at most two decimal places")
    if abs(result) > MAX_AMOUNT:
        raise ValueError(f"{source}: amount exceeds the supported limit {MAX_AMOUNT}")
    return result


def _day(value: str, source: str) -> date:
    try:
        if not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", value.strip()):
            raise ValueError
        result = date.fromisoformat(value.strip())
    except (AttributeError, ValueError):
        raise ValueError(f"{source}: date must be YYYY-MM-DD") from None
    if not MIN_DATE <= result <= MAX_DATE:
        raise ValueError(f"{source}: date must be between {MIN_DATE} and {MAX_DATE}")
    return result


def _label(value: str, source: str) -> str:
    if re.search(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ufffe\uffff]", value):
        raise ValueError(f"{source}: text contains an unsupported control character")
    cleaned = value.strip()
    if not cleaned:
        raise ValueError(f"{source}: value cannot be blank")
    if cleaned.startswith(("=", "+", "-", "@")):
        raise ValueError(f"{source}: text cannot start with a spreadsheet formula prefix")
    if cleaned in {"#NULL!", "#DIV/0!", "#VALUE!", "#REF!", "#NAME?", "#NUM!", "#N/A"}:
        raise ValueError(f"{source}: text cannot be an Excel error token")
    if len(cleaned) > 32767:
        raise ValueError(f"{source}: text exceeds Excel's 32767-character cell limit")
    return cleaned


def _category(value: str, source: str, spellings: dict[str, str]) -> str:
    category = _label(value, source)
    # SUMIFS criteria are case-insensitive and interpret these characters.
    if len(category) > 255 or any(char in category for char in "*?~<>"):
        raise ValueError(f"{source}: category must be at most 255 characters without * ? ~ < >")
    try:
        Decimal(category)
    except InvalidOperation:
        pass
    else:
        raise ValueError(f"{source}: category must be a descriptive text label, not a number")
    prior = spellings.setdefault(category.casefold(), category)
    if prior != category:
        raise ValueError(f"{source}: inconsistent category spelling {category!r}, use {prior!r}")
    return category


def load_inputs(transactions_path: Path, budgets_path: Path) -> tuple[list[Transaction], list[Budget]]:
    transaction_rows = _read_rows(transactions_path, {"transaction_id", "date", "category", "description", "amount"})
    budget_rows = _read_rows(budgets_path, {"month", "category", "budget"})
    transactions: list[Transaction] = []
    budgets: list[Budget] = []
    ids: set[str] = set()
    budget_keys: set[tuple[date, str]] = set()
    spellings: dict[str, str] = {}
    for index, row in enumerate(transaction_rows, start=2):
        source = f"{transactions_path.name} row {index}"
        transaction_id = _label(row["transaction_id"], f"{source} transaction_id")
        if transaction_id in ids:
            raise ValueError(f"{source}: duplicate transaction_id {transaction_id}")
        ids.add(transaction_id)
        transactions.append(Transaction(transaction_id, _day(row["date"], source),
                                        _category(row["category"], f"{source} category", spellings),
                                        _label(row["description"], f"{source} description"),
                                        _amount(row["amount"], source)))
    for index, row in enumerate(budget_rows, start=2):
        source = f"{budgets_path.name} row {index}"
        month_text = row["month"].strip()
        if not re.fullmatch(r"[0-9]{4}-[0-9]{2}", month_text):
            raise ValueError(f"{source}: month must be YYYY-MM")
        month = _day(month_text + "-01", source)
        category = _category(row["category"], f"{source} category", spellings)
        key = (month, category)
        if key in budget_keys:
            raise ValueError(f"{source}: duplicate month/category budget")
        budget_keys.add(key)
        amount = _amount(row["budget"], source)
        if amount < 0:
            raise ValueError(f"{source}: budget cannot be negative")
        budgets.append(Budget(month, category, amount))
    required_keys = {(date(item.day.year, item.day.month, 1), item.category) for item in transactions}
    missing_keys = required_keys - budget_keys
    if missing_keys:
        labels = ", ".join(f"{month:%Y-%m}/{category}" for month, category in sorted(missing_keys))
        raise ValueError(f"Missing budgets for transaction groups: {labels}")
    if sum((abs(item.amount) for item in transactions), Decimal(0)) + sum((item.amount for item in budgets), Decimal(0)) > MAX_AMOUNT:
        raise ValueError(f"Combined absolute transaction amounts and budgets exceed the supported limit {MAX_AMOUNT}")
    return transactions, budgets


def expected_totals(transactions: list[Transaction], budgets: list[Budget]) -> dict[str, Decimal]:
    spend = sum((row.amount for row in transactions), Decimal("0"))
    budget = sum((row.amount for row in budgets), Decimal("0"))
    return {"spend": spend, "budget": budget, "variance": budget - spend}


def _header(sheet, labels: list[str]) -> None:
    sheet.append(labels)
    sheet.freeze_panes = "A2"
    sheet.sheet_view.showGridLines = False
    for cell in sheet[1]:
        cell.fill = PatternFill("solid", fgColor="17324D")
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(wrap_text=True, vertical="center")
    sheet.row_dimensions[1].height = 30
    sheet.auto_filter.ref = sheet.dimensions


def build_workbook(transactions: list[Transaction], budgets: list[Budget], output: Path) -> None:
    if output.suffix.lower() != ".xlsx":
        raise ValueError("Output must use an .xlsx extension")
    workbook = Workbook()
    summary = workbook.active
    summary.title = "Summary"
    monthly = workbook.create_sheet("Monthly")
    raw = workbook.create_sheet("Transactions")
    budget_sheet = workbook.create_sheet("Budgets")
    workbook.calculation = CalcProperties(calcMode="auto", fullCalcOnLoad=True, forceFullCalc=True)
    _header(raw, ["Transaction ID", "Date", "Category", "Description", "Amount", "Amount (cents)"])
    for item in sorted(transactions, key=lambda row: (row.day, row.transaction_id)):
        raw.append([item.transaction_id, item.day, item.category, item.description, float(item.amount)])
        raw.cell(raw.max_row, 2).number_format = "yyyy-mm-dd"
        raw.cell(raw.max_row, 5).number_format = '#,##0.00;[Red](#,##0.00)'
        raw.cell(raw.max_row, 6, f"=ROUND(E{raw.max_row}*100,0)").number_format = "0"
    raw.column_dimensions["F"].hidden = True
    _header(budget_sheet, ["Month", "Category", "Budget", "Budget (cents)"])
    for item in sorted(budgets, key=lambda row: (row.month, row.category)):
        budget_sheet.append([item.month, item.category, float(item.amount)])
        budget_sheet.cell(budget_sheet.max_row, 1).number_format = "mmm yyyy"
        budget_sheet.cell(budget_sheet.max_row, 3).number_format = '#,##0.00;[Red](#,##0.00)'
        budget_sheet.cell(budget_sheet.max_row, 4, f"=ROUND(C{budget_sheet.max_row}*100,0)").number_format = "0"
    budget_sheet.column_dimensions["D"].hidden = True
    _header(monthly, ["Month", "Category", "Actual", "Budget", "Variance", "Variance %", "Prior month", "Delta", "Transactions", "Avg per transaction", "Actual (cents)", "Budget (cents)"])
    monthly.column_dimensions["K"].hidden = True
    monthly.column_dimensions["L"].hidden = True
    groups = sorted({(item.month, item.category) for item in budgets} |
                    {(date(item.day.year, item.day.month, 1), item.category) for item in transactions})
    location: dict[tuple[date, str], int] = {}
    last_tx = raw.max_row
    last_budget = budget_sheet.max_row
    for month, category in groups:
        row = monthly.max_row + 1
        location[(month, category)] = row
        monthly.cell(row, 1, month).number_format = "mmm yyyy"
        monthly.cell(row, 2, category)
        # The admitted absolute total is below 10^14 cents, safely below 2^53.
        # Sum exact integers and divide only at the displayed monetary outputs.
        monthly.cell(row, 11, f'=SUMIFS(Transactions!$F$2:$F${last_tx},Transactions!$C$2:$C${last_tx},B{row},Transactions!$B$2:$B${last_tx},">="&A{row},Transactions!$B$2:$B${last_tx},"<"&EDATE(A{row},1))').number_format = "0"
        monthly.cell(row, 12, f'=SUMIFS(Budgets!$D$2:$D${last_budget},Budgets!$B$2:$B${last_budget},B{row},Budgets!$A$2:$A${last_budget},A{row})').number_format = "0"
        monthly.cell(row, 3, f'=K{row}/100')
        monthly.cell(row, 4, f'=L{row}/100')
        monthly.cell(row, 5, f"=(L{row}-K{row})/100")
        monthly.cell(row, 6, f'=IF(D{row}=0,"",E{row}/D{row})')
        prior_month = date(month.year - (month.month == 1), 12 if month.month == 1 else month.month - 1, 1)
        prior_row = location.get((prior_month, category))
        monthly.cell(row, 7, f"=C{prior_row}" if prior_row else None)
        monthly.cell(row, 8, f"=(K{row}-K{prior_row})/100" if prior_row else None)
        monthly.cell(row, 9, f'=COUNTIFS(Transactions!$C$2:$C${last_tx},B{row},Transactions!$B$2:$B${last_tx},">="&A{row},Transactions!$B$2:$B${last_tx},"<"&EDATE(A{row},1))')
        monthly.cell(row, 10, f'=IF(I{row}=0,"",SIGN(K{row})*ROUND(ABS(K{row})/I{row},0)/100)')
        for column in (3, 4, 5, 7, 8, 10):
            monthly.cell(row, column).number_format = '#,##0.00;[Red](#,##0.00)'
        monthly.cell(row, 6).number_format = '0.0%;[Red](0.0%)'
    _header(summary, ["Measure", "Value"])
    summary.append(["Reporting months", len({month for month, _ in groups})])
    summary.append(["Transactions", f"=SUM(Monthly!I2:I{monthly.max_row})"])
    summary.append(["Actual spend", "=$U$2/100"])
    summary.append(["Budget", "=$U$3/100"])
    summary.append(["Remaining budget", "=($U$3-$U$2)/100"])
    summary.append(["Budget variance %", '=IF($U$3=0,"",($U$3-$U$2)/$U$3)'])
    summary.append(["Average spend per month", '=IF(B2=0,"",SIGN($U$2)*ROUND(ABS($U$2)/B2,0)/100)'])
    summary.append(["Scope", "Synthetic operating expenses. Positive amounts are spend. Negative amounts are refunds."])
    summary.append(["Refresh", "Edit existing amounts to recalculate. Rerun after changing dates, categories or input rows."])
    summary.merge_cells("B9:E9")
    summary.merge_cells("B10:E10")
    summary["B9"].alignment = Alignment(wrap_text=True, vertical="center")
    summary["B10"].alignment = Alignment(wrap_text=True, vertical="center")
    summary.row_dimensions[9].height = 30
    summary.row_dimensions[10].height = 30
    summary["A12"] = "Month"
    summary["B12"] = "Actual"
    summary["C12"] = "Budget"
    summary["D12"] = "Period"
    for cell in summary[12]:
        if cell.column <= 4:
            cell.fill = PatternFill("solid", fgColor="17324D")
            cell.font = Font(color="FFFFFF", bold=True)
    for month in sorted({month for month, _ in groups}):
        row = summary.max_row + 1
        summary.cell(row, 1, month).number_format = "mmm yyyy"
        summary.cell(row, 2, f'=SUMIF(Monthly!$A$2:$A${monthly.max_row},A{row},Monthly!$K$2:$K${monthly.max_row})/100')
        summary.cell(row, 3, f'=SUMIF(Monthly!$A$2:$A${monthly.max_row},A{row},Monthly!$L$2:$L${monthly.max_row})/100')
        summary.cell(row, 4, month.strftime("%b %Y"))
        summary.cell(row, 2).number_format = '#,##0.00;[Red](#,##0.00)'
        summary.cell(row, 3).number_format = '#,##0.00;[Red](#,##0.00)'
    summary["B7"].number_format = '0.0%;[Red](0.0%)'
    for row in (4, 5, 6, 8):
        summary.cell(row, 2).number_format = '#,##0.00;[Red](#,##0.00)'
    chart = BarChart()
    chart.title = "Actual spend (blue) and budget (red) by month"
    chart.y_axis.title = "Amount"
    chart.x_axis.title = "Month"
    chart.add_data(Reference(summary, min_col=2, max_col=3, min_row=12, max_row=summary.max_row), titles_from_data=True)
    chart.set_categories(Reference(summary, min_col=4, min_row=13, max_row=summary.max_row))
    chart.series[0].graphicalProperties.solidFill = "4F81BD"
    chart.series[1].graphicalProperties.solidFill = "C0504D"
    chart.legend = None
    chart.width = 23
    chart.height = 11
    summary.add_chart(chart, "F2")
    summary["T2"] = "Total actual (cents)"
    summary["U2"] = f"=SUM(Monthly!K2:K{monthly.max_row})"
    summary["T3"] = "Total budget (cents)"
    summary["U3"] = f"=SUM(Monthly!L2:L{monthly.max_row})"
    summary.column_dimensions["T"].hidden = True
    summary.column_dimensions["U"].hidden = True
    widths = {"Summary": [27, 34, 16, 16, 16], "Monthly": [15, 24, 16, 16, 16, 15, 16, 16, 15, 22],
              "Transactions": [20, 15, 24, 54, 16], "Budgets": [15, 24, 16]}
    for sheet in workbook:
        if sheet.title != "Summary":
            visible_last = {"Transactions": "E", "Budgets": "C", "Monthly": "J"}[sheet.title]
            sheet.auto_filter.ref = f"A1:{visible_last}{sheet.max_row}"
        else:
            sheet.auto_filter.ref = None
        sheet.sheet_properties.pageSetUpPr.fitToPage = True
        sheet.print_options.horizontalCentered = True
        for index, width in enumerate(widths[sheet.title], start=1):
            sheet.column_dimensions[get_column_letter(index)].width = width
    output.parent.mkdir(parents=True, exist_ok=True)
    _save_workbook(workbook, output)


def _save_workbook(workbook: Workbook, output: Path) -> None:
    """Write reproducible bytes and replace the destination only after success."""
    fixed = datetime(2000, 1, 1)
    workbook.properties.created = fixed
    workbook.properties.modified = fixed
    raw = io.BytesIO()
    workbook.save(raw)
    descriptor, name = tempfile.mkstemp(prefix=".report-", suffix=".xlsx", dir=output.parent)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            with zipfile.ZipFile(raw) as source, zipfile.ZipFile(handle, "w", compression=zipfile.ZIP_DEFLATED) as target:
                for member in sorted(source.namelist()):
                    content = source.read(member)
                    if member == "docProps/core.xml":
                        content = re.sub(rb"(<dcterms:modified[^>]*>)[^<]+", rb"\g<1>2000-01-01T00:00:00Z", content)
                    info = zipfile.ZipInfo(member, date_time=(2000, 1, 1, 0, 0, 0))
                    info.compress_type = zipfile.ZIP_DEFLATED
                    target.writestr(info, content)
        os.replace(name, output)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--transactions", type=Path, required=True)
    parser.add_argument("--budgets", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.output.resolve() in {args.transactions.resolve(), args.budgets.resolve()}:
            raise ValueError("Output must not replace an input file")
        transactions, budgets = load_inputs(args.transactions, args.budgets)
        build_workbook(transactions, budgets, args.output)
    except (ValueError, OSError, UnicodeError) as error:
        parser.error(str(error))
    totals = expected_totals(transactions, budgets)
    print(f"Created {args.output} with {len(transactions)} transactions. Actual {totals['spend']}, budget {totals['budget']}, remaining {totals['variance']}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
