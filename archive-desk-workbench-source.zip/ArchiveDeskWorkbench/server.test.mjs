import assert from "node:assert/strict"
import { spawn } from "node:child_process"
import { createHash } from "node:crypto"
import { lstat, mkdir, mkdtemp, readFile, readdir, symlink, writeFile } from "node:fs/promises"
import http from "node:http"
import os from "node:os"
import path from "node:path"
import { once } from "node:events"
import test from "node:test"
import { fileURLToPath } from "node:url"
import { createWorkbench } from "./server.mjs"

const SOURCE_ROOT = path.dirname(fileURLToPath(import.meta.url))
const SERVER_FILE = path.join(SOURCE_ROOT, "server.mjs")
const BODY_LIMIT = 16 * 1024

async function makeFixture() {
  const root = await mkdtemp(path.join(os.tmpdir(), "archive-desk-workbench-"))
  const workspace = path.join(root, "workspace")
  const storage = path.join(root, "storage")
  await mkdir(workspace)
  await mkdir(storage)
  return { root, workspace, storage }
}

async function putFile(root, relative, data) {
  const absolute = path.join(root, ...relative.split("/"))
  await mkdir(path.dirname(absolute), { recursive: true })
  await writeFile(absolute, data)
  return absolute
}

async function sourceFixture() {
  const fixture = await makeFixture()
  const baseline = path.join(fixture.workspace, "project")
  const current = path.join(fixture.workspace, "current")
  await putFile(baseline, "same.txt", "same sample bytes\n")
  await putFile(baseline, "changed.bin", Buffer.from([1, 2, 3, 4, 5]))
  await putFile(baseline, "removed.txt", "kept in the saved baseline\n")
  await putFile(baseline, "nested/資料/café.txt", "unchanged Unicode sample\n")
  await putFile(baseline, ".env", "synthetic excluded text\n")
  await putFile(current, "same.txt", "same sample bytes\n")
  await putFile(current, "changed.bin", Buffer.from([1, 2, 3, 4, 6]))
  await putFile(current, "added.txt", "new sample bytes\n")
  await putFile(current, "nested/資料/café.txt", "unchanged Unicode sample\n")
  await putFile(current, ".env.local", "synthetic excluded current text\n")
  return { ...fixture, baseline, current }
}

async function startApp(t, fixture) {
  const app = await createWorkbench({ workspace: fixture.workspace, storage: fixture.storage, port: 0 })
  let running = true
  t.after(async () => {
    if (!running) return
    running = false
    await app.close()
  })
  return {
    app,
    async close() {
      if (!running) return
      running = false
      await app.close()
    }
  }
}

function requestHeaders(app, extra = {}) {
  return {
    Origin: app.url,
    "Content-Type": "application/json",
    "X-Workbench": "1",
    ...extra
  }
}

async function post(app, route, value, extraHeaders = {}) {
  return fetch(app.url + route, {
    method: "POST",
    headers: requestHeaders(app, extraHeaders),
    body: JSON.stringify(value)
  })
}

async function responseJson(response) {
  const text = await response.text()
  try {
    return JSON.parse(text)
  } catch {
    assert.fail("Expected a JSON response, received: " + text.slice(0, 200))
  }
}

async function rawRequest(app, route, { method = "GET", headers = {}, body = null } = {}) {
  const address = new URL(route, app.url)
  return new Promise((resolve, reject) => {
    const request = http.request({
      hostname: address.hostname,
      port: Number(address.port),
      path: address.pathname + address.search,
      method,
      headers,
      agent: false
    }, response => {
      const chunks = []
      response.on("data", chunk => chunks.push(chunk))
      response.on("end", () => resolve({
        status: response.statusCode,
        headers: response.headers,
        body: Buffer.concat(chunks).toString("utf8")
      }))
    })
    request.once("error", reject)
    request.end(body)
  })
}

async function treeHashes(root) {
  const result = []
  async function visit(directory, prefix = "") {
    const names = (await readdir(directory)).sort()
    for (const name of names) {
      const relative = prefix ? prefix + "/" + name : name
      const absolute = path.join(directory, name)
      const stat = await lstat(absolute)
      assert.equal(stat.isSymbolicLink(), false, "test fixture unexpectedly contains a link")
      if (stat.isDirectory()) {
        await visit(absolute, relative)
      } else {
        const bytes = await readFile(absolute)
        result.push({
          path: relative,
          bytes: bytes.byteLength,
          sha256: createHash("sha256").update(bytes).digest("hex")
        })
      }
    }
  }
  await visit(root)
  return result
}

test("HTTP backup, verification, comparison, report download, restore and restart preserve source bytes", async t => {
  const fixture = await sourceFixture()
  let current = await startApp(t, fixture)
  const before = await treeHashes(fixture.baseline)

  const home = await fetch(current.app.url)
  assert.equal(home.status, 200)
  assert.match(await home.text(), /Archive Desk Workbench/u)
  assert.equal(home.headers.get("access-control-allow-origin"), null)

  const initial = await responseJson(await fetch(current.app.url + "/api/state"))
  assert.equal(initial.version, "0.1.0-candidate.1")
  assert.equal(initial.backups.length, 0)
  assert.equal(initial.busy, false)

  const previewResponse = await fetch(current.app.url + "/api/preview?source=project")
  assert.equal(previewResponse.status, 200)
  const preview = await responseJson(previewResponse)
  assert.deepEqual(preview.files.map(file => file.path), [
    "changed.bin",
    "nested/資料/café.txt",
    "removed.txt",
    "same.txt"
  ])
  assert.equal(preview.count, 4)
  assert.equal(preview.skippedPaths[0].path, ".env")
  assert.equal(JSON.stringify(preview).includes("synthetic excluded text"), false)
  assert.equal(Object.hasOwn(preview.files[0], "data"), false)

  const backupResponse = await post(current.app, "/api/backups", { source: "project", label: "Before sample edit" })
  assert.equal(backupResponse.status, 201)
  const backupPayload = await responseJson(backupResponse)
  const backup = backupPayload.backup
  assert.match(backup.id, /^[a-f0-9]{24}$/u)
  assert.equal(backup.label, "Before sample edit")
  assert.equal(backup.source, "project")
  assert.equal(backup.files, 4)
  assert.equal(backup.demo, false)
  assert.match(backup.sha256, /^[a-f0-9]{64}$/u)

  const verifyResponse = await post(current.app, "/api/backups/" + backup.id + "/verify", {})
  assert.equal(verifyResponse.status, 200)
  const verification = await responseJson(verifyResponse)
  assert.equal(verification.files.length, 4)
  assert.equal(verification.backup.id, backup.id)
  assert.ok(verification.files.every(file => /^[a-f0-9]{64}$/u.test(file.sha256)))

  const compareResponse = await post(current.app, "/api/backups/" + backup.id + "/compare", { source: "current" })
  assert.equal(compareResponse.status, 200)
  const comparison = await responseJson(compareResponse)
  assert.deepEqual(comparison.counts, { added: 1, removed: 1, changed: 1, unchanged: 2 })
  assert.equal(comparison.rows.length, 5)
  assert.equal(comparison.baselineArchiveSha256, backup.sha256)

  const reportResponse = await fetch(current.app.url + "/api/backups/" + backup.id + "/report")
  assert.equal(reportResponse.status, 200)
  assert.match(reportResponse.headers.get("content-disposition"), /comparison-[a-f0-9]{24}\.json/u)
  assert.deepEqual(JSON.parse(await reportResponse.text()).counts, comparison.counts)

  const archiveResponse = await fetch(current.app.url + "/api/backups/" + backup.id + "/download")
  assert.equal(archiveResponse.status, 200)
  assert.match(archiveResponse.headers.get("content-disposition"), /archive-[a-f0-9]{24}\.zip/u)
  assert.equal(archiveResponse.headers.get("content-type"), "application/zip")
  const downloadedArchive = Buffer.from(await archiveResponse.arrayBuffer())
  assert.equal(createHash("sha256").update(downloadedArchive).digest("hex"), backup.sha256)

  const restoreResponse = await post(current.app, "/api/backups/" + backup.id + "/restore", { name: "recovered-one" })
  assert.equal(restoreResponse.status, 200)
  const restore = await responseJson(restoreResponse)
  assert.equal(restore.verified, true)
  assert.equal(restore.files, 4)
  assert.equal(restore.totalBytes, backup.totalBytes)
  assert.equal(path.resolve(restore.destination), path.join(fixture.storage, "restores", "recovered-one"))
  assert.deepEqual(await treeHashes(restore.destination), before.filter(file => file.path !== ".env"))
  assert.deepEqual(await treeHashes(fixture.baseline), before)

  const existingBefore = await treeHashes(restore.destination)
  const existingResponse = await post(current.app, "/api/backups/" + backup.id + "/restore", { name: "recovered-one" })
  assert.equal(existingResponse.status, 409)
  assert.deepEqual(await treeHashes(restore.destination), existingBefore)

  const persistedState = await responseJson(await fetch(current.app.url + "/api/state"))
  assert.equal(persistedState.backups.length, 1)
  assert.equal(persistedState.activity[0].title, "Recovery completed")

  await current.close()
  current = await startApp(t, fixture)
  const restartedState = await responseJson(await fetch(current.app.url + "/api/state"))
  assert.equal(restartedState.backups.length, 1)
  assert.equal(restartedState.backups[0].id, backup.id)
  assert.equal(restartedState.backups[0].sha256, backup.sha256)
  assert.equal(restartedState.activity.length, persistedState.activity.length)
  const persistedReport = await fetch(current.app.url + "/api/backups/" + backup.id + "/report")
  assert.equal(persistedReport.status, 200)
  assert.deepEqual(JSON.parse(await persistedReport.text()).counts, comparison.counts)
  const persistedArchive = await fetch(current.app.url + "/api/backups/" + backup.id + "/download")
  assert.equal(Buffer.from(await persistedArchive.arrayBuffer()).equals(downloadedArchive), true)
})

test("sample workflow uses only a new lab tree and retains its comparison report", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "owner-source.txt", "keep this configured workspace file\n")
  const workspaceBefore = await treeHashes(fixture.workspace)
  const { app } = await startApp(t, fixture)

  const demoResponse = await post(app, "/api/demo", {})
  assert.equal(demoResponse.status, 200)
  const demo = await responseJson(demoResponse)
  assert.equal(demo.backup.demo, true)
  assert.equal(demo.backup.source, "demo:" + demo.backup.id)
  assert.equal(demo.backup.files, 4)
  assert.deepEqual(demo.comparison.counts, { added: 1, removed: 1, changed: 1, unchanged: 2 })
  assert.equal(demo.steps.length, 4)
  assert.ok(demo.steps.every(step => step.status === "pass"))
  assert.equal(demo.restore.verified, true)
  assert.deepEqual(await treeHashes(fixture.workspace), workspaceBefore)

  const baseline = path.join(fixture.storage, "labs", demo.backup.id, "baseline")
  const current = path.join(fixture.storage, "labs", demo.backup.id, "current")
  await lstat(path.join(baseline, "removed.txt"))
  await lstat(path.join(baseline, ".git", "readme.txt"))
  await lstat(path.join(current, "added.txt"))
  const compareResponse = await post(app, "/api/backups/" + demo.backup.id + "/compare", { source: "missing-current-folder" })
  assert.equal(compareResponse.status, 200)
  assert.deepEqual((await responseJson(compareResponse)).counts, demo.comparison.counts)
  const reportResponse = await fetch(app.url + "/api/backups/" + demo.backup.id + "/report")
  assert.equal(reportResponse.status, 200)
  assert.deepEqual(JSON.parse(await reportResponse.text()).counts, demo.comparison.counts)
  const state = await responseJson(await fetch(app.url + "/api/state"))
  assert.equal(state.backups.length, 1)
  assert.equal(state.backups[0].demo, true)
  assert.deepEqual(await treeHashes(fixture.workspace), workspaceBefore)
})

test("request boundaries reject bad host, cross-site writes, missing origin, bad media type, large bodies and unsafe paths", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "note.txt", "synthetic content that must not be returned\n")
  const { app } = await startApp(t, fixture)

  const badHost = await rawRequest(app, "/api/state", { headers: { Host: "example.test" } })
  assert.equal(badHost.status, 421)

  const crossSite = await fetch(app.url + "/api/state", { headers: { "Sec-Fetch-Site": "cross-site" } })
  assert.equal(crossSite.status, 403)

  const foreignOriginRead = await fetch(app.url, { headers: { Origin: "https://elsewhere.example" } })
  assert.equal(foreignOriginRead.status, 200)
  assert.equal(foreignOriginRead.headers.get("access-control-allow-origin"), null)

  const missingOrigin = await fetch(app.url + "/api/backups", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Workbench": "1" },
    body: JSON.stringify({ source: ".", label: "Denied" })
  })
  assert.equal(missingOrigin.status, 403)

  const badOrigin = await post(app, "/api/backups", { source: ".", label: "Denied" }, { Origin: "https://elsewhere.example" })
  assert.equal(badOrigin.status, 403)
  const missingMarker = await post(app, "/api/backups", { source: ".", label: "Denied" }, { "X-Workbench": "0" })
  assert.equal(missingMarker.status, 403)
  const badType = await post(app, "/api/backups", { source: ".", label: "Denied" }, { "Content-Type": "text/plain" })
  assert.equal(badType.status, 415)

  const oversized = await fetch(app.url + "/api/backups", {
    method: "POST",
    headers: requestHeaders(app),
    body: " ".repeat(BODY_LIMIT + 1)
  })
  assert.equal(oversized.status, 413)

  const traversal = await fetch(app.url + "/api/preview?source=..")
  assert.equal(traversal.status, 400)
  const absolute = await fetch(app.url + "/api/preview?source=C%3A%5CUsers")
  assert.equal(absolute.status, 400)
  const duplicate = await fetch(app.url + "/api/preview?source=.&source=.")
  assert.equal(duplicate.status, 400)

  const invalidId = await post(app, "/api/backups/not-an-id/verify", {})
  assert.equal(invalidId.status, 400)
  const privatePath = await fetch(app.url + "/server.mjs")
  assert.equal(privatePath.status, 404)
  const vendorPath = await fetch(app.url + "/vendor/cli.mjs")
  assert.equal(vendorPath.status, 404)
  const corsPreflight = await fetch(app.url + "/api/state", {
    method: "OPTIONS",
    headers: { Origin: "https://elsewhere.example", "Access-Control-Request-Method": "POST" }
  })
  assert.equal(corsPreflight.headers.get("access-control-allow-origin"), null)

  const state = await responseJson(await fetch(app.url + "/api/state"))
  assert.equal(state.backups.length, 0)
  assert.equal(state.busy, false)
})

test("mutations are serialized and a concurrent write receives 409", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "note.txt", "synthetic bytes\n")
  const { app } = await startApp(t, fixture)
  const body = Buffer.from(JSON.stringify({ source: ".", label: "Serialized write" }))
  const firstResponse = new Promise((resolve, reject) => {
    const request = http.request(new URL("/api/backups", app.url), {
      method: "POST",
      headers: {
        Host: new URL(app.url).host,
        Origin: app.url,
        "Content-Type": "application/json",
        "X-Workbench": "1",
        "Content-Length": body.byteLength
      }
    }, response => {
      const chunks = []
      response.on("data", chunk => chunks.push(chunk))
      response.on("end", () => resolve({
        status: response.statusCode,
        body: Buffer.concat(chunks).toString("utf8")
      }))
    })
    request.once("error", reject)
    request.write(body.subarray(0, 4))
    setTimeout(() => request.end(body.subarray(4)), 60)
  })
  await new Promise(resolve => setTimeout(resolve, 20))
  const state = await responseJson(await fetch(app.url + "/api/state"))
  assert.equal(state.busy, true)
  const second = await post(app, "/api/demo", {})
  assert.equal(second.status, 409)
  const first = await firstResponse
  assert.equal(first.status, 201)
})

test("corrupt saved archive bytes are rejected without changing the configured source", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "project/not-secret.txt", "synthetic marker bytes\n")
  const { app } = await startApp(t, fixture)
  const sourceBefore = await treeHashes(path.join(fixture.workspace, "project"))
  const backupResponse = await post(app, "/api/backups", { source: "project", label: "Corruption fixture" })
  assert.equal(backupResponse.status, 201)
  const backup = (await responseJson(backupResponse)).backup
  const archive = path.join(fixture.storage, "archives", backup.id + ".zip")
  const bytes = Buffer.from(await readFile(archive))
  const marker = Buffer.from("synthetic marker bytes\n")
  const offset = bytes.indexOf(marker)
  assert.ok(offset >= 0)
  bytes[offset] ^= 0xff
  await writeFile(archive, bytes)

  const verifyResponse = await post(app, "/api/backups/" + backup.id + "/verify", {})
  assert.equal(verifyResponse.status, 409)
  assert.match((await responseJson(verifyResponse)).error, /archive bytes/u)
  assert.deepEqual(await treeHashes(path.join(fixture.workspace, "project")), sourceBefore)
})

test("workspace and storage must be separate and symlinked source or storage paths are refused", async t => {
  const fixture = await makeFixture()
  const nestedStorage = path.join(fixture.workspace, "nested-storage")
  await assert.rejects(
    createWorkbench({ workspace: fixture.workspace, storage: nestedStorage, port: 0 }),
    /separate folders/u
  )
  await assert.rejects(lstat(nestedStorage), error => error.code === "ENOENT")

  const outside = path.join(fixture.root, "outside")
  const linkedSource = path.join(fixture.workspace, "linked-source")
  await mkdir(outside)
  await putFile(outside, "outside.txt", "synthetic outside file\n")
  try {
    await symlink(outside, linkedSource, "junction")
  } catch (error) {
    if (["EPERM", "EACCES", "UNKNOWN"].includes(error && error.code)) {
      t.skip("This Windows environment did not permit creating a test junction.")
      return
    }
    throw error
  }

  const { app } = await startApp(t, fixture)
  const linkedPreview = await fetch(app.url + "/api/preview?source=linked-source")
  assert.equal(linkedPreview.status, 400)
  assert.match((await responseJson(linkedPreview)).error, /symbolic link or junction/u)

  const linkedStorage = path.join(fixture.root, "linked-storage")
  await symlink(fixture.storage, linkedStorage, "junction")
  const secondWorkspace = path.join(fixture.root, "second-workspace")
  await mkdir(secondWorkspace)
  await assert.rejects(
    createWorkbench({ workspace: secondWorkspace, storage: linkedStorage, port: 0 }),
    /without links/u
  )
})

test("server command starts with explicit options and exposes only the loopback address", async t => {
  const fixture = await makeFixture()
  const child = spawn(process.execPath, [
    SERVER_FILE,
    "--workspace", fixture.workspace,
    "--storage", fixture.storage,
    "--port", "0"
  ], {
    cwd: SOURCE_ROOT,
    env: process.platform === "win32" ? { SystemRoot: process.env.SystemRoot || process.env.SYSTEMROOT } : {},
    shell: false,
    windowsHide: true,
    stdio: ["ignore", "pipe", "pipe"]
  })
  let stdout = ""
  let stderr = ""
  child.stdout.setEncoding("utf8")
  child.stderr.setEncoding("utf8")
  child.stdout.on("data", chunk => { stdout += chunk })
  child.stderr.on("data", chunk => { stderr += chunk })
  let stopped = false
  t.after(async () => {
    if (stopped) return
    stopped = true
    child.kill("SIGTERM")
    await once(child, "exit")
  })
  const deadline = Date.now() + 10_000
  while (!stdout.includes("\n") && Date.now() < deadline && child.exitCode === null) {
    await new Promise(resolve => setTimeout(resolve, 20))
  }
  assert.equal(child.exitCode, null, stderr)
  assert.match(stdout, /Archive Desk Workbench is running at http:\/\/127\.0\.0\.1:\d+/u)
  assert.equal(stdout.includes(fixture.workspace), false)
  assert.equal(stdout.includes(fixture.storage), false)
  const address = stdout.trim().split(" ").at(-1)
  const state = await responseJson(await fetch(address + "/api/state"))
  assert.equal(state.backups.length, 0)
  assert.equal(new URL(address).hostname, "127.0.0.1")
  child.kill("SIGTERM")
  await once(child, "exit")
  stopped = true
})
