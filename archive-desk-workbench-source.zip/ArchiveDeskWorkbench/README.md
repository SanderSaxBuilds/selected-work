# Archive Desk Workbench

Archive Desk Workbench is a local manual backup interface for a selected project folder. It creates ZIP archives, verifies their saved bytes, compares a current folder with a saved baseline, and restores files into a new folder.

## Start

Use Node.js 24. From this folder, run:

    npm start

The default workspace is the included synthetic demo folder. The backup library is created in workbench-data beside that folder. The server listens on 127.0.0.1 and prints the local address to open.

To choose folders and a port, run:

    node server.mjs --workspace "C:\Work\Project" --storage "D:\Project backups" --port 4330

The workspace and backup library must be separate regular folders. Existing linked folder components are refused. The browser interface accepts only local requests addressed to the exact loopback host and port.

## Use

Preview a relative folder within the configured workspace. A dot selects its root. The preview lists file paths and byte counts, plus paths skipped by the standard filename exclusions. It does not return file contents.

Create a backup after reviewing the preview. Each archive is verified after it is saved. The library records the label, source, file count, source size, archive size, archive SHA-256 and verification time. Comparison reports are saved beside the archive library. Restores are placed under the storage folder's restores directory. Existing restore folders are refused.

The sample workflow creates fictional files in a new folder under labs, compares an edited copy and restores the saved baseline into a new recovery folder. It does not write into the configured workspace.

## Supported files and limits

The archive contains regular files and their relative paths. It does not restore empty folders, original timestamps or filesystem permissions. The archive uses the Archive Desk ZIP Store format with UTF-8 names. It does not import arbitrary ZIP files, compressed entries, encrypted archives or ZIP64.

Each backup supports up to 500 files, 20 MiB per file and 50 MiB total source data. Saved archives are limited to 52 MiB. Common .git, node_modules, .ssh, .env, .env.*, credentials.json, .pem, .key, .p12 and .pfx patterns are skipped. These filename exclusions are not sensitive-content detection.

Scanning and reading are not an atomic filesystem snapshot and do not provide an adversarial race guarantee. Close editors or other programs that may change files before creating a backup or comparison. Keep another copy on a separate device. This local preview is not a production backup service.

## Tests

Run the app and CLI test suite with:

    npm test

The HTTP tests use isolated synthetic folders. Test fixtures are retained after completion so their outputs can be inspected.
