# WerkSupply equipment catalogue source

Four editable vector catalogue pages and their fictional product-data CSV. Original illustrations, consistent specifications, a comparison page and a reconciled USD 3,540 quote matrix are included. All products, specifications and prices are fictional. This is not a stock statement or commercial offer.

Open the four SVG files in a compatible vector editor. The CSV contains the matching sample product rows.
