# WerkSupply catalogue, editable source

A four-page product catalogue for WerkSupply, a fictional maker of steel workshop storage.

## Files

- WerkSupply_Catalogue.html holds all four pages. Product drawings, specification tables and the quote are inline SVG and HTML, so you can edit text, prices and colours in any code editor.
- fictional-products.csv lists the three products with dimensions in millimetres, unit prices in USD and the sample quote quantities.

## Make the PDF

Open the HTML file in Chrome, Edge or Brave and print to PDF. Choose no margins and turn on background graphics. The pages are sized for 3:2 landscape.

## Notes

WerkSupply, its products and prices are fictional. The drawings are original. The fonts load from Google Fonts, so print while you're online.
