import assert from "node:assert/strict"
import test from "node:test"
import { createHash } from "node:crypto"
import { spawn } from "node:child_process"
import { lstat, mkdir, mkdtemp, readFile, readdir, symlink, writeFile } from "node:fs/promises"
import os from "node:os"
import path from "node:path"
import { fileURLToPath } from "node:url"
import { verifyArchive } from "./lib/core.mjs"

const HERE = path.dirname(fileURLToPath(import.meta.url))
const CLI = path.join(HERE, "cli.mjs")
const encoder = new TextEncoder()

async function freshFixture() {
  return mkdtemp(path.join(os.tmpdir(), "archive-desk-cli-1145-"))
}

async function putFile(root, relative, textOrBytes) {
  const absolute = path.join(root, ...relative.split("/"))
  await mkdir(path.dirname(absolute), { recursive: true })
  await writeFile(absolute, textOrBytes)
  return absolute
}

function runCli(args) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [CLI, ...args], { windowsHide: true })
    let stdout = ""
    let stderr = ""
    child.stdout.setEncoding("utf8")
    child.stderr.setEncoding("utf8")
    child.stdout.on("data", chunk => { stdout += chunk })
    child.stderr.on("data", chunk => { stderr += chunk })
    child.once("error", reject)
    child.once("close", code => resolve({ code, stdout, stderr }))
  })
}

async function treeHashes(root) {
  const result = []
  const visit = async (absolute, relative = "") => {
    const names = (await readdir(absolute)).sort((left, right) => left < right ? -1 : left > right ? 1 : 0)
    for (const name of names) {
      const childRelative = relative ? `${relative}/${name}` : name
      const childAbsolute = path.join(absolute, name)
      const stat = await lstat(childAbsolute)
      if (stat.isDirectory()) await visit(childAbsolute, childRelative)
      else if (stat.isFile()) {
        const data = await readFile(childAbsolute)
        const hash = createHash("sha256").update(data).digest("hex")
        result.push({ path: childRelative, bytes: data.length, sha256: hash })
      }
    }
  }
  await visit(root)
  return result
}

test("backup writes and verifies a new saved ZIP with deterministic POSIX paths, Unicode, empty data, and exclusions", async () => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "project")
  await mkdir(path.join(source, "nested", "資料"), { recursive: true })
  await putFile(source, "nested/資料/café.txt", "hello from a synthetic fixture")
  await putFile(source, "nested/資料/empty.bin", new Uint8Array())
  await putFile(source, ".env", "fake-token-one")
  await putFile(source, ".env.production", "fake-token-two")
  await putFile(source, "credentials.json", "fake-token-three")
  await putFile(source, "private/identity.PEM", "fake-private-key")
  await putFile(source, ".ssh/id_key", "fake-ssh-key")
  await putFile(source, ".git/config", "synthetic git config")
  const before = await treeHashes(source)
  const archive = path.join(fixture, "saved backup.zip")

  const saved = await runCli(["backup", source, "--out", archive])
  assert.equal(saved.code, 0, saved.stderr)
  assert.match(saved.stdout, /Backup saved and verified/)
  assert.match(saved.stdout, /\.env\.production/)
  assert.match(saved.stdout, /private\/identity\.PEM/)
  assert.match(saved.stdout, /only\. They are not secret detection\./)

  const actualBytes = new Uint8Array(await readFile(archive))
  const verified = await verifyArchive(actualBytes)
  assert.deepEqual(verified.files.map(file => file.path), ["nested/資料/café.txt", "nested/資料/empty.bin"])
  assert.equal(verified.files[0].data.byteLength, "hello from a synthetic fixture".length)
  assert.equal(verified.files[1].data.byteLength, 0)
  const check = await runCli(["verify", archive])
  assert.equal(check.code, 0, check.stderr)
  assert.match(check.stdout, /Backup verified/)
  assert.deepEqual(await treeHashes(source), before)
})

test("compare reports one of each status and saves a new JSON report with skipped paths", async () => {
  const fixture = await freshFixture()
  const original = path.join(fixture, "original")
  const current = path.join(fixture, "current")
  await mkdir(original, { recursive: true })
  await mkdir(current, { recursive: true })
  await putFile(original, "same.txt", "same")
  await putFile(original, "change.txt", "old")
  await putFile(original, "remove.txt", "gone")
  const archive = path.join(fixture, "baseline.zip")
  const backup = await runCli(["backup", original, "--out", archive])
  assert.equal(backup.code, 0, backup.stderr)

  await putFile(current, "same.txt", "same")
  await putFile(current, "change.txt", "new")
  await putFile(current, "add/new.txt", "new")
  await putFile(current, ".env.local", "synthetic-secret")
  const reportPath = path.join(fixture, "compare.json")
  const result = await runCli(["compare", archive, current, "--report", reportPath])
  assert.equal(result.code, 0, result.stderr)
  assert.match(result.stdout, /1 added, 1 removed, 1 changed, 1 unchanged/)
  assert.match(result.stdout, /\.env\.local/)
  assert.match(result.stdout, /not secret detection/)

  const reportBytes = await readFile(reportPath)
  const report = JSON.parse(reportBytes.toString("utf8"))
  assert.deepEqual(reportBytes, Buffer.from(`${JSON.stringify(report, null, 2)}\n`, "utf8"))
  const archiveBytes = await readFile(archive)
  assert.equal(report.baselineArchiveSha256, createHash("sha256").update(archiveBytes).digest("hex"))
  assert.deepEqual(report.counts, { added: 1, removed: 1, changed: 1, unchanged: 1 })
  assert.deepEqual(report.rows.map(row => [row.path, row.status]), [
    ["add/new.txt", "added"],
    ["change.txt", "changed"],
    ["remove.txt", "removed"],
    ["same.txt", "unchanged"]
  ])
  assert.deepEqual(report.skippedPaths.map(item => item.path), [".env.local"])
  assert.match(report.exclusionsNotice, /not secret detection/)
})

test("existing outputs are preserved and output or report paths inside the source are refused", async () => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "source")
  await mkdir(source)
  await putFile(source, "note.txt", "synthetic data")

  const existing = path.join(fixture, "existing.zip")
  await writeFile(existing, "preserve this exact file")
  const before = await readFile(existing)
  const overwrite = await runCli(["backup", source, "--out", existing])
  assert.notEqual(overwrite.code, 0)
  assert.match(overwrite.stderr, /already exists/)
  assert.deepEqual(await readFile(existing), before)

  const inside = path.join(source, "inside.zip")
  const insideResult = await runCli(["backup", source, "--out", inside])
  assert.notEqual(insideResult.code, 0)
  assert.match(insideResult.stderr, /outside the source directory/)
  await assert.rejects(() => lstat(inside), error => error.code === "ENOENT")

  const archive = path.join(fixture, "baseline.zip")
  const backup = await runCli(["backup", source, "--out", archive])
  assert.equal(backup.code, 0, backup.stderr)
  const existingReport = path.join(fixture, "existing.json")
  await writeFile(existingReport, "preserve this report")
  const reportBefore = await readFile(existingReport)
  const reportResult = await runCli(["compare", archive, source, "--report", existingReport])
  assert.notEqual(reportResult.code, 0)
  assert.match(reportResult.stderr, /already exists/)
  assert.deepEqual(await readFile(existingReport), reportBefore)

  const insideReport = await runCli(["compare", archive, source, "--report", path.join(source, "inside.json")])
  assert.notEqual(insideReport.code, 0)
  assert.match(insideReport.stderr, /outside the source directory/)
})

test("unsupported and duplicate arguments fail with a documented usage status", async () => {
  const noCommand = await runCli([])
  assert.equal(noCommand.code, 1)
  assert.match(noCommand.stderr, /Usage:/)
  const unknownFlag = await runCli(["verify", "backup.zip", "--other"])
  assert.equal(unknownFlag.code, 1)
  const duplicateFlag = await runCli(["backup", ".", "--out", "one.zip", "--out", "two.zip"])
  assert.equal(duplicateFlag.code, 1)
  const unsupportedCommand = await runCli(["restore", "backup.zip"])
  assert.equal(unsupportedCommand.code, 1)
})

test("corrupt saved backup bytes are rejected by verify", async () => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "source")
  await mkdir(source)
  await putFile(source, "marker.bin", new Uint8Array([11, 22, 33, 44, 55]))
  const validPath = path.join(fixture, "valid.zip")
  const saved = await runCli(["backup", source, "--out", validPath])
  assert.equal(saved.code, 0, saved.stderr)
  const corruptedPath = path.join(fixture, "corrupted.zip")
  const bytes = new Uint8Array(await readFile(validPath))
  const marker = Buffer.from([11, 22, 33, 44, 55])
  const offset = Buffer.from(bytes).indexOf(marker)
  assert.ok(offset >= 0)
  bytes[offset] ^= 0xff
  await writeFile(corruptedPath, bytes)
  const result = await runCli(["verify", corruptedPath])
  assert.notEqual(result.code, 0)
  assert.match(result.stderr, /CRC check/)
})

test("symlinks and directory junctions are refused where the platform can create one", async context => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "source")
  const outside = path.join(fixture, "outside")
  await mkdir(source)
  await mkdir(outside)
  await putFile(outside, "external.txt", "synthetic outside file")
  const link = path.join(source, "linked-directory")
  try {
    await symlink(outside, link, process.platform === "win32" ? "junction" : "dir")
  } catch (error) {
    if (process.platform === "win32" && ["EPERM", "EACCES", "UNKNOWN"].includes(error?.code)) {
      context.skip(`This Windows environment did not permit creating a test junction: ${error.code}`)
      return
    }
    throw error
  }
  const output = path.join(fixture, "link-test.zip")
  const result = await runCli(["backup", source, "--out", output])
  assert.notEqual(result.code, 0)
  assert.match(result.stderr, /symbolic link or junction/)
  await assert.rejects(() => lstat(output), error => error.code === "ENOENT")
})

test("output and JSON report are new-only and use the documented byte limits", async () => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "source")
  await mkdir(source)
  await putFile(source, "nested/a.txt", "bytes")
  const archive = path.join(fixture, "new.zip")
  const saved = await runCli(["backup", source, "--out", archive])
  assert.equal(saved.code, 0, saved.stderr)
  const report = path.join(fixture, "new.json")
  const compared = await runCli(["compare", archive, source, "--report", report])
  assert.equal(compared.code, 0, compared.stderr)
  const json = JSON.parse(await readFile(report, "utf8"))
  assert.deepEqual(json.limits, { maxFiles: 500, maxFileBytes: 20 * 1024 * 1024, maxTotalBytes: 50 * 1024 * 1024 })
  assert.deepEqual(json.counts, { added: 0, removed: 0, changed: 0, unchanged: 1 })
})
