# Archive Desk CLI

A small manual companion for creating, checking, and comparing Archive Desk ZIP backups. It uses Node.js 24 and built-in modules only.

```text
node cli.mjs backup <source-dir> --out <new-archive.zip>
node cli.mjs verify <saved-archive.zip>
node cli.mjs compare <saved-archive.zip> <current-dir> [--report <new.json>]
```

`backup` reads regular files under the selected directory, stores their relative paths with UTF-8 names, then verifies the bytes read back from the newly saved archive. `verify` checks a saved Archive Desk backup. `compare` shows added, removed, changed, and unchanged files. A JSON report includes the SHA-256 of the saved baseline archive bytes. The destination ZIP or report must be a new file, its parent directory must already exist, and it must be outside the source directory. This CLI has no restore or extraction command.

The default limits are 500 files, 20 MiB per file, and 50 MiB total source data. Archive reads are limited to 52 MiB. The archive core accepts Archive Desk's ZIP Store format with UTF-8 paths. It does not accept arbitrary ZIP imports, ZIP64, encryption, or compressed entries.

The CLI skips paths whose name matches common patterns: `.git`, `node_modules`, `.ssh`, `.env`, `.env.*`, `credentials.json`, and files ending in `.pem`, `.key`, `.p12`, or `.pfx`. Each run reports skipped paths. These filename exclusions catch common patterns only, they are not secret detection, and they do not identify all sensitive files.

Source reads are not an atomic filesystem snapshot. The CLI checks the source during scanning and reading, but it does not provide an adversarial race guarantee. Close editors and other programs that may change source files before making a backup or comparison.

Exit status is `0` for success, `1` for command usage errors, `2` for validation or I/O errors before creating an output, and `3` when an output may have been partially or fully written but could not be verified. Any partial new output is left in place and its path is reported.

The child-process tests use synthetic temporary fixtures. The CLI was tested with Node.js 24.19 on Windows. This bounded check does not establish production security or compatibility beyond the described format and limits.

Original code by SanderSaxBuilds. Uses Node.js built-in modules, with no third-party runtime packages.
