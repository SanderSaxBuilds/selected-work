import path from "node:path"
import { constants } from "node:fs"
import { createHash } from "node:crypto"
import { lstat, open, readdir, realpath } from "node:fs/promises"
import { pathToFileURL } from "node:url"
import {
  LIMITS,
  buildArchive,
  compareArchiveToFiles,
  formatBytes,
  verifyArchive
} from "./lib/core.mjs"

const MAX_ARCHIVE_BYTES = 52 * 1024 * 1024
const NOFOLLOW = process.platform === "win32" ? 0 : (constants.O_NOFOLLOW ?? 0)
const EXCLUSION_NOTICE = "Filename exclusions catch common patterns only. They are not secret detection."
const USAGE = [
  "Usage:",
  "  node cli.mjs backup <source-dir> --out <new-archive.zip>",
  "  node cli.mjs verify <saved-archive.zip>",
  "  node cli.mjs compare <saved-archive.zip> <current-dir> [--report <new.json>]"
].join("\n")

class CliError extends Error {
  constructor(message, exitCode = 2, partialOutput = null) {
    super(message)
    this.name = "CliError"
    this.exitCode = exitCode
    this.partialOutput = partialOutput
  }
}

function fail(message, exitCode = 2) {
  throw new CliError(message, exitCode)
}

function parsePathArgument(value, label) {
  if (typeof value !== "string" || value.length === 0 || value.startsWith("--") || value.includes("\u0000")) {
    fail(`${label} must be a non-empty path, not an option.`, 1)
  }
  return value
}

function parseCommand(args) {
  const command = args[0]
  if (command === "backup") {
    if (args.length !== 4 || args[2] !== "--out") fail(`Invalid backup arguments.\n${USAGE}`, 1)
    return { command, source: parsePathArgument(args[1], "Source directory"), output: parsePathArgument(args[3], "Archive output") }
  }
  if (command === "verify") {
    if (args.length !== 2) fail(`Invalid verify arguments.\n${USAGE}`, 1)
    return { command, archive: parsePathArgument(args[1], "Saved archive") }
  }
  if (command === "compare") {
    if (args.length === 3) {
      return {
        command,
        archive: parsePathArgument(args[1], "Saved archive"),
        source: parsePathArgument(args[2], "Current directory"),
        report: null
      }
    }
    if (args.length === 5 && args[3] === "--report") {
      return {
        command,
        archive: parsePathArgument(args[1], "Saved archive"),
        source: parsePathArgument(args[2], "Current directory"),
        report: parsePathArgument(args[4], "JSON report output")
      }
    }
    fail(`Invalid compare arguments.\n${USAGE}`, 1)
  }
  fail(`Unknown command.\n${USAGE}`, 1)
}

function statKey(stat) {
  return [stat.dev, stat.ino, stat.mode, stat.size, stat.mtimeNs, stat.ctimeNs].map(value => String(value)).join(":")
}

function sameStat(left, right) {
  return statKey(left) === statKey(right)
}

function safeErrorMessage(error) {
  return error instanceof Error ? error.message : String(error)
}

function displayPath(value) {
  return JSON.stringify(value)
}

function classifyFilesystemEntry(stat, relativePath) {
  if (stat.isSymbolicLink()) fail(`Source contains a symbolic link or junction at ${displayPath(relativePath)}. Links are not supported.`)
  if (stat.isFile()) return "file"
  if (stat.isDirectory()) return "directory"
  fail(`Source contains an unsupported special file at ${displayPath(relativePath)}.`)
}

function excludedReason(relativePath, kind) {
  const basename = relativePath.split("/").at(-1) ?? relativePath
  const lower = basename.toLowerCase()
  if (lower === ".git" || lower === "node_modules" || lower === ".ssh") return "default-excluded directory or filename"
  if (lower === ".env" || lower.startsWith(".env.") || lower === "credentials.json") return "common credential filename pattern"
  if (kind === "file" && /\.(pem|key|p12|pfx)$/i.test(basename)) return "common credential file extension"
  return null
}

async function lstatRequired(absolutePath, relativePath, phase) {
  try {
    return await lstat(absolutePath, { bigint: true })
  } catch (error) {
    const detail = safeErrorMessage(error)
    if (error && (error.code === "ENOENT" || error.code === "ENOTDIR")) {
      fail(`Source changed while it was ${phase} at ${displayPath(relativePath || "the selected directory")}.`)
    }
    fail(`Could not inspect ${displayPath(relativePath || "the selected directory")}: ${detail}`)
  }
}

async function initialLstat(absolutePath, label) {
  try {
    return await lstat(absolutePath, { bigint: true })
  } catch (error) {
    if (error && (error.code === "ENOENT" || error.code === "ENOTDIR")) fail(`${label} was not found.`)
    fail(`Could not inspect ${label}: ${safeErrorMessage(error)}`)
  }
}

async function readNames(absoluteDirectory, relativeDirectory) {
  let names
  try {
    names = await readdir(absoluteDirectory)
  } catch (error) {
    if (error && (error.code === "ENOENT" || error.code === "ENOTDIR")) {
      fail(`Source changed while it was being scanned at ${displayPath(relativeDirectory || "the selected directory")}.`)
    }
    fail(`Could not list ${displayPath(relativeDirectory || "the selected directory")}: ${safeErrorMessage(error)}`)
  }
  return names.sort((left, right) => left < right ? -1 : left > right ? 1 : 0)
}

function sameNames(left, right) {
  return left.length === right.length && left.every((name, index) => name === right[index])
}

function sameBytes(left, right) {
  if (left.byteLength !== right.byteLength) return false
  for (let index = 0; index < left.byteLength; index += 1) {
    if (left[index] !== right[index]) return false
  }
  return true
}

async function resolveSourceDirectory(sourceArgument) {
  const argumentPath = path.resolve(sourceArgument)
  const initial = await initialLstat(argumentPath, "Source directory")
  if (initial.isSymbolicLink()) fail("The selected source directory is a symbolic link or junction. Choose its actual directory path.")
  if (!initial.isDirectory()) fail("The selected source path is not a directory.")
  let root
  try {
    root = await realpath(argumentPath)
  } catch (error) {
    fail(`Could not resolve the source directory: ${safeErrorMessage(error)}`)
  }
  const resolvedStat = await lstatRequired(root, root, "checked")
  if (resolvedStat.isSymbolicLink() || !resolvedStat.isDirectory()) fail("The selected source path is not a regular directory.")
  return root
}

async function scanSource(sourceArgument) {
  const root = await resolveSourceDirectory(sourceArgument)
  const inventory = new Map()
  const files = []
  const skippedPaths = []

  const visit = async (absoluteDirectory, relativeDirectory, expectedStat = null) => {
    const before = await lstatRequired(absoluteDirectory, relativeDirectory, "being scanned")
    if (before.isSymbolicLink() || !before.isDirectory()) {
      fail(`Source changed while it was being scanned at ${displayPath(relativeDirectory || "the selected directory")}.`)
    }
    if (expectedStat && !sameStat(before, expectedStat)) {
      fail(`Source changed while it was being scanned at ${displayPath(relativeDirectory || "the selected directory")}.`)
    }
    const namesBefore = await readNames(absoluteDirectory, relativeDirectory)
    inventory.set(relativeDirectory, { kind: "directory", stat: before, excluded: null })
    for (const name of namesBefore) {
      const relativePath = relativeDirectory ? `${relativeDirectory}/${name}` : name
      const absolutePath = path.join(absoluteDirectory, name)
      const stat = await lstatRequired(absolutePath, relativePath, "being scanned")
      const kind = classifyFilesystemEntry(stat, relativePath)
      const excluded = excludedReason(relativePath, kind)
      inventory.set(relativePath, { kind, stat, excluded })
      if (excluded) {
        skippedPaths.push({ path: relativePath, reason: excluded })
        continue
      }
      if (kind === "directory") {
        await visit(absolutePath, relativePath, stat)
        continue
      }
      if (stat.size > BigInt(LIMITS.maxFileBytes)) {
        fail(`File ${relativePath} is larger than the ${formatBytes(LIMITS.maxFileBytes)} per-file limit.`)
      }
      files.push({ path: relativePath, absolutePath, stat, statKey: statKey(stat) })
      if (files.length > LIMITS.maxFiles) fail(`The source contains more than ${LIMITS.maxFiles} eligible files.`)
    }
    const namesAfter = await readNames(absoluteDirectory, relativeDirectory)
    const after = await lstatRequired(absoluteDirectory, relativeDirectory, "being scanned")
    if (!sameNames(namesBefore, namesAfter) || !sameStat(before, after)) {
      fail(`Source changed while it was being scanned at ${displayPath(relativeDirectory || "the selected directory")}.`)
    }
  }

  const rootStat = await lstatRequired(root, "", "being scanned")
  await visit(root, "", rootStat)
  files.sort((left, right) => left.path < right.path ? -1 : left.path > right.path ? 1 : 0)
  skippedPaths.sort((left, right) => left.path < right.path ? -1 : left.path > right.path ? 1 : 0)
  const totalBytes = files.reduce((sum, file) => sum + file.stat.size, 0n)
  if (totalBytes > BigInt(LIMITS.maxTotalBytes)) {
    fail(`Eligible source files exceed the ${formatBytes(LIMITS.maxTotalBytes)} total limit.`)
  }
  if (files.length === 0) fail("No eligible files remain after the default filename exclusions.")
  return { root, inventory, files, skippedPaths }
}

function compareInventories(first, second) {
  if (first.size !== second.size) fail("Source changed while files were being read.")
  for (const [relativePath, before] of first) {
    const after = second.get(relativePath)
    if (!after || before.kind !== after.kind || before.excluded !== after.excluded || !sameStat(before.stat, after.stat)) {
      fail(`Source changed while files were being read at ${displayPath(relativePath || "the selected directory")}.`)
    }
  }
}

async function readSourceFile(file) {
  const currentPathStat = await lstatRequired(file.absolutePath, file.path, "being read")
  if (currentPathStat.isSymbolicLink() || !currentPathStat.isFile() || !sameStat(currentPathStat, file.stat)) {
    fail(`Source changed before ${displayPath(file.path)} could be read.`)
  }
  let handle
  try {
    handle = await open(file.absolutePath, constants.O_RDONLY | NOFOLLOW)
    const openedStat = await handle.stat({ bigint: true })
    if (!sameStat(openedStat, file.stat)) fail(`Source changed while ${displayPath(file.path)} was being opened.`)
    const length = Number(file.stat.size)
    const data = new Uint8Array(length)
    let offset = 0
    while (offset < length) {
      const result = await handle.read(data, offset, length - offset, offset)
      if (result.bytesRead === 0) fail(`Source changed while ${displayPath(file.path)} was being read.`)
      offset += result.bytesRead
    }
    const finishedStat = await handle.stat({ bigint: true })
    const pathAfter = await lstatRequired(file.absolutePath, file.path, "being read")
    if (!sameStat(finishedStat, file.stat) || pathAfter.isSymbolicLink() || !sameStat(pathAfter, file.stat)) {
      fail(`Source changed while ${displayPath(file.path)} was being read.`)
    }
    return {
      path: file.path,
      data,
      modifiedAt: Number(file.stat.mtimeNs / 1_000_000n)
    }
  } catch (error) {
    if (error instanceof CliError) throw error
    fail(`Could not read ${displayPath(file.path)}: ${safeErrorMessage(error)}`)
  } finally {
    if (handle) {
      try {
        await handle.close()
      } catch {
        // The read error or successful data snapshot is already determined.
      }
    }
  }
}

async function readStableRegularFile(absolutePath, label, maxBytes) {
  const before = await initialLstat(absolutePath, label)
  if (before.isSymbolicLink()) fail(`${label} is a symbolic link or junction. Links are not supported.`)
  if (!before.isFile()) fail(`${label} is not a regular file.`)
  if (before.size > BigInt(maxBytes)) fail(`${label} exceeds the supported ${formatBytes(maxBytes)} input limit.`)
  let handle
  try {
    handle = await open(absolutePath, constants.O_RDONLY | NOFOLLOW)
    const openedStat = await handle.stat({ bigint: true })
    if (!sameStat(openedStat, before)) fail(`${label} changed while it was being opened.`)
    const length = Number(before.size)
    const data = new Uint8Array(length)
    let offset = 0
    while (offset < length) {
      const result = await handle.read(data, offset, length - offset, offset)
      if (result.bytesRead === 0) fail(`${label} changed while it was being read.`)
      offset += result.bytesRead
    }
    const finishedStat = await handle.stat({ bigint: true })
    const pathAfter = await lstatRequired(absolutePath, label, "being read")
    if (!sameStat(finishedStat, before) || pathAfter.isSymbolicLink() || !sameStat(pathAfter, before)) {
      fail(`${label} changed while it was being read.`)
    }
    return data
  } catch (error) {
    if (error instanceof CliError) throw error
    fail(`Could not read ${label}: ${safeErrorMessage(error)}`)
  } finally {
    if (handle) {
      try {
        await handle.close()
      } catch {
        // No further action is safe after a read has failed.
      }
    }
  }
}

function isWithinDirectory(directory, candidate) {
  const relative = path.relative(directory, candidate)
  return relative === "" || (!path.isAbsolute(relative) && relative !== ".." && !relative.startsWith(`..${path.sep}`))
}

async function resolveNewOutput(rawPath, sourceRoot, label) {
  const lexicalPath = path.resolve(rawPath)
  if (isWithinDirectory(sourceRoot, lexicalPath)) fail(`${label} must be outside the source directory.`)
  const parentPath = path.dirname(lexicalPath)
  let resolvedParent
  try {
    resolvedParent = await realpath(parentPath)
  } catch (error) {
    fail(`The parent directory for ${label} must already exist: ${safeErrorMessage(error)}`)
  }
  const canonicalPath = path.join(resolvedParent, path.basename(lexicalPath))
  if (isWithinDirectory(sourceRoot, canonicalPath)) fail(`${label} must be outside the source directory.`)
  try {
    await lstat(canonicalPath)
    fail(`${label} already exists. Choose a new path.`)
  } catch (error) {
    if (error instanceof CliError) throw error
    if (!error || error.code !== "ENOENT") fail(`Could not check ${label}: ${safeErrorMessage(error)}`)
  }
  return canonicalPath
}

async function writeNewOutput(absolutePath, data, label) {
  let handle
  let created = false
  try {
    handle = await open(absolutePath, "wx", 0o600)
    created = true
    await handle.writeFile(data)
    await handle.sync()
    await handle.close()
    handle = null
  } catch (error) {
    if (handle) {
      try {
        await handle.close()
      } catch {
        // Keep any partial output for inspection.
      }
    }
    if (created) throw new CliError(`Could not finish writing ${label}: ${safeErrorMessage(error)}`, 3, absolutePath)
    if (error && error.code === "EEXIST") fail(`${label} already exists. Choose a new path.`)
    fail(`Could not create ${label}: ${safeErrorMessage(error)}`)
  }
}

function printSkipped(skippedPaths) {
  if (skippedPaths.length > 0) {
    console.log(`Skipped paths (${skippedPaths.length}):`)
    for (const item of skippedPaths) console.log(`  ${displayPath(item.path)} (${item.reason})`)
  } else {
    console.log("Skipped paths: none")
  }
  console.log(EXCLUSION_NOTICE)
}

async function backup(command) {
  const root = await resolveSourceDirectory(command.source)
  const outputPath = await resolveNewOutput(command.output, root, "Archive output")
  const source = await scanSource(root)
  const inputFiles = []
  for (const file of source.files) inputFiles.push(await readSourceFile(file))
  const afterRead = await scanSource(source.root)
  compareInventories(source.inventory, afterRead.inventory)
  const archive = await buildArchive(inputFiles)
  await writeNewOutput(outputPath, archive, "archive output")

  let verified
  try {
    const savedBytes = await readStableRegularFile(outputPath, "Saved backup", MAX_ARCHIVE_BYTES)
    verified = await verifyArchive(savedBytes)
  } catch (error) {
    throw new CliError(`The new archive was written, but readback verification failed: ${safeErrorMessage(error)}`, 3, outputPath)
  }
  const total = verified.files.reduce((sum, file) => sum + file.bytes, 0)
  console.log(`Backup saved and verified: ${displayPath(outputPath)}.`)
  console.log(`${verified.files.length} files, ${formatBytes(total)} of source data.`)
  printSkipped(source.skippedPaths)
}

async function verify(command) {
  const archivePath = path.resolve(command.archive)
  const bytes = await readStableRegularFile(archivePath, "Saved archive", MAX_ARCHIVE_BYTES)
  const verified = await verifyArchive(bytes)
  const total = verified.files.reduce((sum, file) => sum + file.bytes, 0)
  console.log(`Backup verified: ${displayPath(archivePath)}.`)
  console.log(`${verified.files.length} files, ${formatBytes(total)} of source data.`)
  console.log(`Created at ${verified.manifest.createdAt}.`)
}

async function compare(command) {
  const archivePath = path.resolve(command.archive)
  const archiveBytes = await readStableRegularFile(archivePath, "Saved archive", MAX_ARCHIVE_BYTES)
  await verifyArchive(archiveBytes)
  const source = await scanSource(command.source)
  const reportPath = command.report ? await resolveNewOutput(command.report, source.root, "JSON report") : null
  const currentFiles = []
  for (const file of source.files) currentFiles.push(await readSourceFile(file))
  const afterRead = await scanSource(source.root)
  compareInventories(source.inventory, afterRead.inventory)
  const comparison = await compareArchiveToFiles(archiveBytes, currentFiles)
  const count = comparison.counts
  console.log(`Compare: ${count.added} added, ${count.removed} removed, ${count.changed} changed, ${count.unchanged} unchanged.`)
  printSkipped(source.skippedPaths)

  if (reportPath) {
    const report = {
      format: "archive-desk-compare",
      version: 1,
      baselineArchiveSha256: createHash("sha256").update(archiveBytes).digest("hex"),
      counts: comparison.counts,
      rows: comparison.rows,
      skippedPaths: source.skippedPaths,
      exclusionsNotice: EXCLUSION_NOTICE,
      limits: LIMITS
    }
    const reportBytes = new TextEncoder().encode(JSON.stringify(report, null, 2) + "\n")
    await writeNewOutput(reportPath, reportBytes, "JSON report")
    try {
      const savedReport = await readStableRegularFile(reportPath, "Saved JSON report", 1024 * 1024)
      if (!sameBytes(savedReport, reportBytes)) fail("Saved JSON report bytes do not match the report written by this run.")
      const text = new TextDecoder("utf-8", { fatal: true }).decode(savedReport)
      JSON.parse(text)
    } catch (error) {
      throw new CliError(`The report was written, but readback verification failed: ${safeErrorMessage(error)}`, 3, reportPath)
    }
    console.log(`JSON report saved and verified: ${reportPath}.`)
  }
}

async function run(args) {
  const command = parseCommand(args)
  if (command.command === "backup") return backup(command)
  if (command.command === "verify") return verify(command)
  if (command.command === "compare") return compare(command)
}

async function main(args) {
  try {
    await run(args)
  } catch (error) {
    const exitCode = Number.isInteger(error?.exitCode) ? error.exitCode : 2
    console.error(`Archive Desk error: ${safeErrorMessage(error)}`)
    if (error?.partialOutput) {
    console.error(`A partial new output may remain at ${displayPath(error.partialOutput)}. It was left in place.`)
    }
    if (exitCode === 1 && !safeErrorMessage(error).includes("Usage:")) console.error(USAGE)
    process.exitCode = exitCode
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  await main(process.argv.slice(2))
}
