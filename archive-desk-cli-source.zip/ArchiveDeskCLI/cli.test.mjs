import assert from "node:assert/strict"
import test from "node:test"
import { createHash } from "node:crypto"
import { spawn } from "node:child_process"
import { lstat, mkdir, mkdtemp, readFile, readdir, symlink, writeFile } from "node:fs/promises"
import os from "node:os"
import path from "node:path"
import { fileURLToPath } from "node:url"
import { buildArchive, verifyArchive } from "./lib/core.mjs"

const HERE = path.dirname(fileURLToPath(import.meta.url))
const CLI = path.join(HERE, "cli.mjs")
const encoder = new TextEncoder()

async function freshFixture() {
  return mkdtemp(path.join(os.tmpdir(), "archive-desk-cli-1145-"))
}

async function putFile(root, relative, textOrBytes) {
  const absolute = path.join(root, ...relative.split("/"))
  await mkdir(path.dirname(absolute), { recursive: true })
  await writeFile(absolute, textOrBytes)
  return absolute
}

function startCli(args) {
  const child = spawn(process.execPath, [CLI, ...args], { windowsHide: true })
  const done = new Promise((resolve, reject) => {
    let stdout = ""
    let stderr = ""
    child.stdout.setEncoding("utf8")
    child.stderr.setEncoding("utf8")
    child.stdout.on("data", chunk => { stdout += chunk })
    child.stderr.on("data", chunk => { stderr += chunk })
    child.once("error", reject)
    child.once("close", (code, signal) => resolve({ code, signal, stdout, stderr }))
  })
  return { child, done }
}

function runCli(args) {
  return startCli(args).done
}

function crc32(bytes) {
  let crc = 0xffffffff
  for (const byte of bytes) {
    crc ^= byte
    for (let bit = 0; bit < 8; bit += 1) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0)
  }
  return (crc ^ 0xffffffff) >>> 0
}

function makeStoredZip(entries) {
  const localParts = []
  const centralParts = []
  let localOffset = 0
  const dateBits = ((2026 - 1980) << 9) | (10 << 5) | 18
  for (const entry of entries) {
    const name = Buffer.from(entry.name, "utf8")
    const data = Buffer.from(entry.data)
    const crc = crc32(data)
    const local = Buffer.alloc(30)
    local.writeUInt32LE(0x04034b50, 0)
    local.writeUInt16LE(20, 4)
    local.writeUInt16LE(0x0800, 6)
    local.writeUInt16LE(0, 8)
    local.writeUInt16LE(0, 10)
    local.writeUInt16LE(dateBits, 12)
    local.writeUInt32LE(crc, 14)
    local.writeUInt32LE(data.length, 18)
    local.writeUInt32LE(data.length, 22)
    local.writeUInt16LE(name.length, 26)
    local.writeUInt16LE(0, 28)
    localParts.push(local, name, data)

    const central = Buffer.alloc(46)
    central.writeUInt32LE(0x02014b50, 0)
    central.writeUInt16LE(20, 4)
    central.writeUInt16LE(20, 6)
    central.writeUInt16LE(0x0800, 8)
    central.writeUInt16LE(0, 10)
    central.writeUInt16LE(0, 12)
    central.writeUInt16LE(dateBits, 14)
    central.writeUInt32LE(crc, 16)
    central.writeUInt32LE(data.length, 20)
    central.writeUInt32LE(data.length, 24)
    central.writeUInt16LE(name.length, 28)
    central.writeUInt16LE(0, 30)
    central.writeUInt16LE(0, 32)
    central.writeUInt16LE(0, 34)
    central.writeUInt16LE(0, 36)
    central.writeUInt32LE(0, 38)
    central.writeUInt32LE(localOffset, 42)
    centralParts.push(central, name)
    localOffset += local.length + name.length + data.length
  }
  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0)
  const end = Buffer.alloc(22)
  end.writeUInt32LE(0x06054b50, 0)
  end.writeUInt16LE(0, 4)
  end.writeUInt16LE(0, 6)
  end.writeUInt16LE(entries.length, 8)
  end.writeUInt16LE(entries.length, 10)
  end.writeUInt32LE(centralSize, 12)
  end.writeUInt32LE(localOffset, 16)
  end.writeUInt16LE(0, 20)
  return Buffer.concat([...localParts, ...centralParts, end])
}

async function treeHashes(root) {
  const result = []
  const visit = async (absolute, relative = "") => {
    const names = (await readdir(absolute)).sort((left, right) => left < right ? -1 : left > right ? 1 : 0)
    for (const name of names) {
      const childRelative = relative ? `${relative}/${name}` : name
      const childAbsolute = path.join(absolute, name)
      const stat = await lstat(childAbsolute)
      if (stat.isDirectory()) await visit(childAbsolute, childRelative)
      else if (stat.isFile()) {
        const data = await readFile(childAbsolute)
        const hash = createHash("sha256").update(data).digest("hex")
        result.push({ path: childRelative, bytes: data.length, sha256: hash })
      }
    }
  }
  await visit(root)
  return result
}

test("backup writes and verifies a new saved ZIP with deterministic POSIX paths, Unicode, empty data, and exclusions", async () => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "project")
  await mkdir(path.join(source, "nested", "資料"), { recursive: true })
  await putFile(source, "nested/資料/café.txt", "hello from a synthetic fixture")
  await putFile(source, "nested/資料/empty.bin", new Uint8Array())
  await putFile(source, ".env", "fake-token-one")
  await putFile(source, ".env.production", "fake-token-two")
  await putFile(source, "credentials.json", "fake-token-three")
  await putFile(source, "private/identity.PEM", "fake-private-key")
  await putFile(source, ".ssh/id_key", "fake-ssh-key")
  await putFile(source, ".git/config", "synthetic git config")
  const before = await treeHashes(source)
  const archive = path.join(fixture, "saved backup.zip")

  const saved = await runCli(["backup", source, "--out", archive])
  assert.equal(saved.code, 0, saved.stderr)
  assert.match(saved.stdout, /Backup saved and verified/)
  assert.match(saved.stdout, /\.env\.production/)
  assert.match(saved.stdout, /private\/identity\.PEM/)
  assert.match(saved.stdout, /only\. They are not secret detection\./)

  const actualBytes = new Uint8Array(await readFile(archive))
  const verified = await verifyArchive(actualBytes)
  assert.deepEqual(verified.files.map(file => file.path), ["nested/資料/café.txt", "nested/資料/empty.bin"])
  assert.equal(verified.files[0].data.byteLength, "hello from a synthetic fixture".length)
  assert.equal(verified.files[1].data.byteLength, 0)
  const check = await runCli(["verify", archive])
  assert.equal(check.code, 0, check.stderr)
  assert.match(check.stdout, /Backup verified/)
  assert.deepEqual(await treeHashes(source), before)
})

test("compare reports one of each status and saves a new JSON report with skipped paths", async () => {
  const fixture = await freshFixture()
  const original = path.join(fixture, "original")
  const current = path.join(fixture, "current")
  await mkdir(original, { recursive: true })
  await mkdir(current, { recursive: true })
  await putFile(original, "same.txt", "same")
  await putFile(original, "change.txt", "old")
  await putFile(original, "remove.txt", "gone")
  const archive = path.join(fixture, "baseline.zip")
  const backup = await runCli(["backup", original, "--out", archive])
  assert.equal(backup.code, 0, backup.stderr)

  await putFile(current, "same.txt", "same")
  await putFile(current, "change.txt", "new")
  await putFile(current, "add/new.txt", "new")
  await putFile(current, ".env.local", "synthetic-secret")
  const reportPath = path.join(fixture, "compare.json")
  const result = await runCli(["compare", archive, current, "--report", reportPath])
  assert.equal(result.code, 0, result.stderr)
  assert.match(result.stdout, /1 added, 1 removed, 1 changed, 1 unchanged/)
  assert.match(result.stdout, /\.env\.local/)
  assert.match(result.stdout, /not secret detection/)

  const reportBytes = await readFile(reportPath)
  const report = JSON.parse(reportBytes.toString("utf8"))
  assert.deepEqual(reportBytes, Buffer.from(`${JSON.stringify(report, null, 2)}\n`, "utf8"))
  const archiveBytes = await readFile(archive)
  assert.equal(report.baselineArchiveSha256, createHash("sha256").update(archiveBytes).digest("hex"))
  assert.deepEqual(report.counts, { added: 1, removed: 1, changed: 1, unchanged: 1 })
  assert.deepEqual(report.rows.map(row => [row.path, row.status]), [
    ["add/new.txt", "added"],
    ["change.txt", "changed"],
    ["remove.txt", "removed"],
    ["same.txt", "unchanged"]
  ])
  assert.deepEqual(report.skippedPaths.map(item => item.path), [".env.local"])
  assert.match(report.exclusionsNotice, /not secret detection/)
})

test("existing outputs are preserved and output or report paths inside the source are refused", async () => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "source")
  await mkdir(source)
  await putFile(source, "note.txt", "synthetic data")

  const existing = path.join(fixture, "existing.zip")
  await writeFile(existing, "preserve this exact file")
  const before = await readFile(existing)
  const overwrite = await runCli(["backup", source, "--out", existing])
  assert.notEqual(overwrite.code, 0)
  assert.match(overwrite.stderr, /already exists/)
  assert.deepEqual(await readFile(existing), before)

  const inside = path.join(source, "inside.zip")
  const insideResult = await runCli(["backup", source, "--out", inside])
  assert.notEqual(insideResult.code, 0)
  assert.match(insideResult.stderr, /outside the source directory/)
  await assert.rejects(() => lstat(inside), error => error.code === "ENOENT")

  const archive = path.join(fixture, "baseline.zip")
  const backup = await runCli(["backup", source, "--out", archive])
  assert.equal(backup.code, 0, backup.stderr)
  const existingReport = path.join(fixture, "existing.json")
  await writeFile(existingReport, "preserve this report")
  const reportBefore = await readFile(existingReport)
  const reportResult = await runCli(["compare", archive, source, "--report", existingReport])
  assert.notEqual(reportResult.code, 0)
  assert.match(reportResult.stderr, /already exists/)
  assert.deepEqual(await readFile(existingReport), reportBefore)

  const insideReport = await runCli(["compare", archive, source, "--report", path.join(source, "inside.json")])
  assert.notEqual(insideReport.code, 0)
  assert.match(insideReport.stderr, /outside the source directory/)
})

test("unsupported and duplicate arguments fail with a documented usage status", async () => {
  const noCommand = await runCli([])
  assert.equal(noCommand.code, 1)
  assert.match(noCommand.stderr, /Usage:/)
  const unknownFlag = await runCli(["verify", "backup.zip", "--other"])
  assert.equal(unknownFlag.code, 1)
  const duplicateFlag = await runCli(["backup", ".", "--out", "one.zip", "--out", "two.zip"])
  assert.equal(duplicateFlag.code, 1)
  const unsupportedCommand = await runCli(["restore", "backup.zip"])
  assert.equal(unsupportedCommand.code, 1)
  const restoreExtra = await runCli(["restore", "backup.zip", "--out", "recovered", "--out", "again"])
  assert.equal(restoreExtra.code, 1)
})

test("corrupt saved backup bytes are rejected by verify", async () => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "source")
  await mkdir(source)
  await putFile(source, "marker.bin", new Uint8Array([11, 22, 33, 44, 55]))
  const validPath = path.join(fixture, "valid.zip")
  const saved = await runCli(["backup", source, "--out", validPath])
  assert.equal(saved.code, 0, saved.stderr)
  const corruptedPath = path.join(fixture, "corrupted.zip")
  const bytes = new Uint8Array(await readFile(validPath))
  const marker = Buffer.from([11, 22, 33, 44, 55])
  const offset = Buffer.from(bytes).indexOf(marker)
  assert.ok(offset >= 0)
  bytes[offset] ^= 0xff
  await writeFile(corruptedPath, bytes)
  const result = await runCli(["verify", corruptedPath])
  assert.notEqual(result.code, 0)
  assert.match(result.stderr, /CRC check/)
})

test("restore recreates Unicode, multilevel, empty, binary, and BOM files from the actual saved ZIP", async () => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "source")
  await mkdir(source)
  await putFile(source, "nested/資料/café.txt", "restored from the saved archive")
  await putFile(source, "nested/資料/empty.bin", new Uint8Array())
  await putFile(source, "binary/data.bin", new Uint8Array([0, 255, 16, 128, 10, 13]))
  await putFile(source, "text/with-bom.txt", new Uint8Array([0xef, 0xbb, 0xbf, 0x41, 0x0a]))
  const sourceBefore = await treeHashes(source)
  const archive = path.join(fixture, "saved.zip")
  const backup = await runCli(["backup", source, "--out", archive])
  assert.equal(backup.code, 0, backup.stderr)
  const archiveBytes = await readFile(archive)
  const verified = await verifyArchive(new Uint8Array(archiveBytes))
  assert.equal(verified.files.length, 4)

  const destination = path.join(fixture, "new recovery")
  const result = await runCli(["restore", archive, "--out", destination])
  assert.equal(result.code, 0, result.stderr)
  assert.match(result.stdout, /Restore completed/)
  assert.match(result.stdout, /Every file was synced and read back against its manifest/)
  assert.deepEqual(await treeHashes(destination), sourceBefore)
  assert.deepEqual(await treeHashes(source), sourceBefore)
  assert.deepEqual(new Uint8Array(await readFile(path.join(destination, "binary", "data.bin"))), new Uint8Array([0, 255, 16, 128, 10, 13]))
  assert.deepEqual(new Uint8Array(await readFile(path.join(destination, "text", "with-bom.txt"))), new Uint8Array([0xef, 0xbb, 0xbf, 0x41, 0x0a]))
})

test("restore refuses existing folder and file destinations without changing them", async () => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "source")
  await mkdir(source)
  await putFile(source, "note.txt", "synthetic source")
  const archive = path.join(fixture, "saved.zip")
  const backup = await runCli(["backup", source, "--out", archive])
  assert.equal(backup.code, 0, backup.stderr)

  const existingFolder = path.join(fixture, "existing-folder")
  await mkdir(existingFolder)
  await putFile(existingFolder, "keep.txt", "folder sentinel")
  const folderBefore = await treeHashes(existingFolder)
  const folderResult = await runCli(["restore", archive, "--out", existingFolder])
  assert.notEqual(folderResult.code, 0)
  assert.match(folderResult.stderr, /already exists/)
  assert.deepEqual(await treeHashes(existingFolder), folderBefore)

  const existingFile = path.join(fixture, "existing-file")
  await writeFile(existingFile, "file sentinel")
  const fileBefore = await readFile(existingFile)
  const fileResult = await runCli(["restore", archive, "--out", existingFile])
  assert.notEqual(fileResult.code, 0)
  assert.match(fileResult.stderr, /already exists/)
  assert.deepEqual(await readFile(existingFile), fileBefore)
})

test("corrupt and traversal archives are rejected before creating a restore destination", async () => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "source")
  await mkdir(source)
  await putFile(source, "marker.txt", "good bytes")
  const archive = path.join(fixture, "saved.zip")
  const backup = await runCli(["backup", source, "--out", archive])
  assert.equal(backup.code, 0, backup.stderr)

  const corruptPath = path.join(fixture, "corrupt.zip")
  const corruptBytes = new Uint8Array(await readFile(archive))
  const marker = Buffer.from("good bytes")
  const markerOffset = Buffer.from(corruptBytes).indexOf(marker)
  assert.ok(markerOffset >= 0)
  corruptBytes[markerOffset] ^= 0xff
  await writeFile(corruptPath, corruptBytes)
  const corruptDestination = path.join(fixture, "corrupt-recovery")
  const corruptResult = await runCli(["restore", corruptPath, "--out", corruptDestination])
  assert.notEqual(corruptResult.code, 0)
  await assert.rejects(() => lstat(corruptDestination), error => error.code === "ENOENT")

  const unsafeManifest = Buffer.from(JSON.stringify({
    format: "archive-desk",
    version: 1,
    createdAt: "2026-10-18T00:00:00.000Z",
    files: [{
      path: "../../escape.txt",
      bytes: 1,
      sha256: createHash("sha256").update("x").digest("hex"),
      modifiedAt: 0
    }]
  }), "utf8")
  const traversalZip = makeStoredZip([
    { name: "ArchiveDesk/manifest.json", data: unsafeManifest },
    { name: "files/../../escape.txt", data: Buffer.from("x") }
  ])
  const traversalPath = path.join(fixture, "traversal.zip")
  await writeFile(traversalPath, traversalZip)
  const traversalDestination = path.join(fixture, "traversal-recovery")
  const traversalResult = await runCli(["restore", traversalPath, "--out", traversalDestination])
  assert.notEqual(traversalResult.code, 0)
  await assert.rejects(() => lstat(traversalDestination), error => error.code === "ENOENT")
  await assert.rejects(() => lstat(path.join(fixture, "escape.txt")), error => error.code === "ENOENT")
})

test("restore reports and preserves a partial new destination after a mid-run path conflict", async () => {
  const fixture = await freshFixture()
  const archive = path.join(fixture, "many-files.zip")
  const files = [
    { path: "a-first.txt", data: new Uint8Array([1, 2, 3]), modifiedAt: 0 },
    ...Array.from({ length: 498 }, (_, index) => ({
      path: `m-${String(index).padStart(3, "0")}.txt`,
      data: new Uint8Array([index & 0xff]),
      modifiedAt: 0
    })),
    { path: "z/nested.txt", data: new Uint8Array([9]), modifiedAt: 0 }
  ]
  await writeFile(archive, await buildArchive(files, { createdAt: "2026-10-18T00:00:00.000Z" }))
  const destination = path.join(fixture, "interrupted-recovery")
  const firstFile = path.join(destination, "a-first.txt")
  const blocker = path.join(destination, "z")
  const running = startCli(["restore", archive, "--out", destination])
  const deadline = Date.now() + 20000
  let injected = false
  while (Date.now() < deadline) {
    try {
      const stat = await lstat(firstFile)
      if (stat.isFile()) {
        await writeFile(blocker, "synthetic destination conflict")
        injected = true
        break
      }
    } catch (error) {
      if (error.code !== "ENOENT") throw error
    }
    if (running.child.exitCode !== null) break
    await new Promise(resolve => setTimeout(resolve, 2))
  }
  assert.equal(injected, true, "restore should expose its first output file before reaching the conflicting later folder")
  const result = await running.done
  assert.equal(result.code, 3, result.stderr)
  assert.match(result.stderr, /Restore stopped after creating the new destination/)
  assert.match(result.stderr, /partial output may remain/i)
  assert.ok(result.stderr.includes(JSON.stringify(destination)))
  assert.deepEqual(new Uint8Array(await readFile(firstFile)), new Uint8Array([1, 2, 3]))
  assert.equal(await readFile(blocker, "utf8"), "synthetic destination conflict")
})

test("restore refuses symlink destinations and symlink parents where junction creation is supported", async context => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "source")
  const outside = path.join(fixture, "outside")
  const outsideParent = path.join(fixture, "outside-parent")
  await mkdir(source)
  await mkdir(outside)
  await mkdir(outsideParent)
  await putFile(source, "note.txt", "synthetic source")
  await putFile(outside, "keep.txt", "outside sentinel")
  await putFile(outsideParent, "keep.txt", "parent sentinel")
  const archive = path.join(fixture, "saved.zip")
  const backup = await runCli(["backup", source, "--out", archive])
  assert.equal(backup.code, 0, backup.stderr)

  const linkedDestination = path.join(fixture, "linked-destination")
  const linkedParent = path.join(fixture, "linked-parent")
  try {
    await symlink(outside, linkedDestination, "junction")
    await symlink(outsideParent, linkedParent, "junction")
  } catch (error) {
    if (["EPERM", "EACCES", "UNKNOWN"].includes(error?.code)) {
      context.skip(`This Windows environment did not permit creating test junctions: ${error.code}`)
      return
    }
    throw error
  }

  const destinationResult = await runCli(["restore", archive, "--out", linkedDestination])
  assert.notEqual(destinationResult.code, 0)
  assert.deepEqual(await treeHashes(outside), [{
    path: "keep.txt",
    bytes: Buffer.byteLength("outside sentinel"),
    sha256: createHash("sha256").update("outside sentinel").digest("hex")
  }])

  const parentDestination = path.join(linkedParent, "new-recovery")
  const parentResult = await runCli(["restore", archive, "--out", parentDestination])
  assert.notEqual(parentResult.code, 0)
  assert.match(parentResult.stderr, /symbolic link or junction/)
  await assert.rejects(() => lstat(path.join(outsideParent, "new-recovery")), error => error.code === "ENOENT")
})

test("symlinks and directory junctions are refused where the platform can create one", async context => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "source")
  const outside = path.join(fixture, "outside")
  await mkdir(source)
  await mkdir(outside)
  await putFile(outside, "external.txt", "synthetic outside file")
  const link = path.join(source, "linked-directory")
  try {
    await symlink(outside, link, process.platform === "win32" ? "junction" : "dir")
  } catch (error) {
    if (process.platform === "win32" && ["EPERM", "EACCES", "UNKNOWN"].includes(error?.code)) {
      context.skip(`This Windows environment did not permit creating a test junction: ${error.code}`)
      return
    }
    throw error
  }
  const output = path.join(fixture, "link-test.zip")
  const result = await runCli(["backup", source, "--out", output])
  assert.notEqual(result.code, 0)
  assert.match(result.stderr, /symbolic link or junction/)
  await assert.rejects(() => lstat(output), error => error.code === "ENOENT")
})

test("output and JSON report are new-only and use the documented byte limits", async () => {
  const fixture = await freshFixture()
  const source = path.join(fixture, "source")
  await mkdir(source)
  await putFile(source, "nested/a.txt", "bytes")
  const archive = path.join(fixture, "new.zip")
  const saved = await runCli(["backup", source, "--out", archive])
  assert.equal(saved.code, 0, saved.stderr)
  const report = path.join(fixture, "new.json")
  const compared = await runCli(["compare", archive, source, "--report", report])
  assert.equal(compared.code, 0, compared.stderr)
  const json = JSON.parse(await readFile(report, "utf8"))
  assert.deepEqual(json.limits, { maxFiles: 500, maxFileBytes: 20 * 1024 * 1024, maxTotalBytes: 50 * 1024 * 1024 })
  assert.deepEqual(json.counts, { added: 0, removed: 0, changed: 0, unchanged: 1 })
})
