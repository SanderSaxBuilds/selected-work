import { mkdir, copyFile, readFile, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
const files = ['index.html', 'styles.css', 'app.mjs', 'core.mjs', 'assets/mark.svg']
await mkdir(new URL('./dist/assets/', import.meta.url), { recursive: true })
for (const path of files) await copyFile(new URL(path, import.meta.url), new URL('dist/' + path, import.meta.url))
console.log('Copied the five application files into dist. Existing unrelated files were preserved.')

const read = async path => (await readFile(new URL(path, import.meta.url), 'utf8')).replace(/\r\n?/g, '\n')
const [html, css, core, app, mark] = await Promise.all(['index.html', 'styles.css', 'core.mjs', 'app.mjs', 'assets/mark.svg'].map(read))
const script = core.replace(/^export /gm, '') + '\n' + app.replace(/^import .* from '\.\/core\.mjs'\r?\n/, '')
if (/^import |^export /m.test(script) || /<\/script/i.test(script) || /<\/style/i.test(css)) throw new Error('The portable bundle contains unsupported module or tag boundaries.')
const digest = text => createHash('sha256').update(text).digest('base64')
const csp = `default-src 'none'; script-src 'sha256-${digest(script)}'; style-src 'sha256-${digest(css)}'; img-src data:; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'`
const icon = 'data:image/svg+xml;base64,' + Buffer.from(mark).toString('base64')
let portable = html.replace(/<meta http-equiv="Content-Security-Policy" content="[^"]*">/, `<meta http-equiv="Content-Security-Policy" content="${csp}">`)
portable = portable.replace('<link rel="stylesheet" href="styles.css">', `<style>${css}</style>`)
portable = portable.replace('<script type="module" src="app.mjs"></script>', `<script type="module">${script}</script>`)
portable = portable.replaceAll('assets/mark.svg', icon).replace('class="brand" href="./"', 'class="brand" href="#workspace"')
await writeFile(new URL('./dist/ArchiveDesk.html', import.meta.url), portable)
console.log('Built dist/ArchiveDesk.html with embedded source, styles and vector mark. No external assets or network connections are required by the bundle.')
