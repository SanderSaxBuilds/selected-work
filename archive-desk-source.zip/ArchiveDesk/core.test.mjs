import assert from "node:assert/strict"
import test from "node:test"
import {
  LIMITS,
  buildArchive,
  compareArchiveToFiles,
  createRecoveryZip,
  formatBytes,
  verifyArchive
} from "./core.mjs"

const encoder = new TextEncoder()
const decoder = new TextDecoder("utf-8", { fatal: true })
const CREATED_AT = "2026-10-18T02:03:04.567Z"

function crc32(bytes) {
  let crc = 0xffffffff
  for (const byte of bytes) {
    crc ^= byte
    for (let bit = 0; bit < 8; bit += 1) crc = (crc & 1) ? (0xedb88320 ^ (crc >>> 1)) : (crc >>> 1)
  }
  return (crc ^ 0xffffffff) >>> 0
}

function rawZip(entries) {
  const prepared = entries.map(entry => ({
    name: encoder.encode(entry.name),
    data: entry.data instanceof Uint8Array ? entry.data : encoder.encode(entry.data),
    crc: crc32(entry.data instanceof Uint8Array ? entry.data : encoder.encode(entry.data)),
    date: entry.date ?? 0x21,
    time: entry.time ?? 0,
    localFlags: entry.localFlags ?? 0x0800,
    centralFlags: entry.centralFlags ?? 0x0800,
    localMethod: entry.localMethod ?? 0,
    centralMethod: entry.centralMethod ?? 0,
    localName: entry.localName ? encoder.encode(entry.localName) : null
  }))
  const localBytes = prepared.reduce((sum, entry) => sum + 30 + entry.name.length + entry.data.length, 0)
  const centralBytes = prepared.reduce((sum, entry) => sum + 46 + entry.name.length, 0)
  const output = new Uint8Array(localBytes + centralBytes + 22)
  const view = new DataView(output.buffer)
  let offset = 0
  for (const entry of prepared) {
    entry.localOffset = offset
    view.setUint32(offset, 0x04034b50, true)
    view.setUint16(offset + 4, 20, true)
    view.setUint16(offset + 6, entry.localFlags, true)
    view.setUint16(offset + 8, entry.localMethod, true)
    view.setUint16(offset + 10, entry.time, true)
    view.setUint16(offset + 12, entry.date, true)
    view.setUint32(offset + 14, entry.crc, true)
    view.setUint32(offset + 18, entry.data.length, true)
    view.setUint32(offset + 22, entry.data.length, true)
    const localName = entry.localName ?? entry.name
    view.setUint16(offset + 26, localName.length, true)
    view.setUint16(offset + 28, 0, true)
    offset += 30
    output.set(localName, offset)
    offset += localName.length
    entry.dataStart = offset
    output.set(entry.data, offset)
    offset += entry.data.length
  }
  const centralOffset = offset
  for (const entry of prepared) {
    view.setUint32(offset, 0x02014b50, true)
    view.setUint16(offset + 4, 20, true)
    view.setUint16(offset + 6, 20, true)
    view.setUint16(offset + 8, entry.centralFlags, true)
    view.setUint16(offset + 10, entry.centralMethod, true)
    view.setUint16(offset + 12, entry.time, true)
    view.setUint16(offset + 14, entry.date, true)
    view.setUint32(offset + 16, entry.crc, true)
    view.setUint32(offset + 20, entry.data.length, true)
    view.setUint32(offset + 24, entry.data.length, true)
    view.setUint16(offset + 28, entry.name.length, true)
    view.setUint16(offset + 30, 0, true)
    view.setUint16(offset + 32, 0, true)
    view.setUint16(offset + 34, 0, true)
    view.setUint16(offset + 36, 0, true)
    view.setUint32(offset + 38, 0, true)
    view.setUint32(offset + 42, entry.localOffset, true)
    offset += 46
    output.set(entry.name, offset)
    offset += entry.name.length
  }
  view.setUint32(offset, 0x06054b50, true)
  view.setUint16(offset + 4, 0, true)
  view.setUint16(offset + 6, 0, true)
  view.setUint16(offset + 8, prepared.length, true)
  view.setUint16(offset + 10, prepared.length, true)
  view.setUint32(offset + 12, centralBytes, true)
  view.setUint32(offset + 16, centralOffset, true)
  view.setUint16(offset + 20, 0, true)
  return { bytes: output, entries: prepared }
}

function manifestEntry(path, data, sha256Override) {
  const bytes = data instanceof Uint8Array ? data : encoder.encode(data)
  const hash = sha256Override ?? "0".repeat(64)
  return {
    name: "ArchiveDesk/manifest.json",
    data: encoder.encode(JSON.stringify({
      format: "archive-desk",
      version: 1,
      createdAt: CREATED_AT,
      files: [{ path, bytes: bytes.length, sha256: hash, modifiedAt: 0 }]
    }))
  }
}

function parseStoreZip(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
  const end = bytes.length - 22
  assert.equal(view.getUint32(end, true), 0x06054b50)
  const count = view.getUint16(end + 10, true)
  const centralOffset = view.getUint32(end + 16, true)
  const files = new Map()
  let cursor = centralOffset
  for (let index = 0; index < count; index += 1) {
    assert.equal(view.getUint32(cursor, true), 0x02014b50)
    const nameLength = view.getUint16(cursor + 28, true)
    const localOffset = view.getUint32(cursor + 42, true)
    const name = decoder.decode(bytes.subarray(cursor + 46, cursor + 46 + nameLength))
    const localNameLength = view.getUint16(localOffset + 26, true)
    const dataStart = localOffset + 30 + localNameLength
    const size = view.getUint32(cursor + 24, true)
    files.set(name, bytes.slice(dataStart, dataStart + size))
    cursor += 46 + nameLength
  }
  return files
}

async function validRawBackup(path = "safe.txt", data = "safe data") {
  const fileBytes = encoder.encode(data)
  const digest = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", fileBytes)), byte => byte.toString(16).padStart(2, "0")).join("")
  return rawZip([
    manifestEntry(path, fileBytes, digest),
    { name: `files/${path}`, data: fileBytes }
  ])
}

test("backup round trip preserves binary, empty, BOM, Unicode names, metadata, and caller bytes", async () => {
  const binary = new Uint8Array([0, 255, 1, 2, 0, 128])
  const binaryBefore = binary.slice()
  const bomText = new Uint8Array([0xef, 0xbb, 0xbf, 0x48, 0x69])
  const files = [
    { path: "reports/quarter 1.txt", data: encoder.encode("line one\nline two"), modifiedAt: 1_700_000_000_123 },
    { path: "資料/bytes.bin", data: binary, modifiedAt: 1_700_000_000_000 },
    { path: "empty.dat", data: new Uint8Array(), modifiedAt: 0 },
    { path: "utf8-bom.txt", data: bomText, modifiedAt: 1_700_000_000_001 }
  ]
  const archive = await buildArchive(files, { createdAt: CREATED_AT })
  assert.ok(archive instanceof Uint8Array)
  assert.deepEqual(binary, binaryBefore)

  const result = await verifyArchive(archive)
  assert.equal(result.manifest.format, "archive-desk")
  assert.equal(result.manifest.version, 1)
  assert.equal(result.manifest.createdAt, CREATED_AT)
  assert.equal(result.files.length, files.length)
  for (let index = 0; index < files.length; index += 1) {
    assert.equal(result.files[index].path, files[index].path)
    assert.equal(result.files[index].bytes, files[index].data.byteLength)
    assert.equal(result.files[index].modifiedAt, files[index].modifiedAt)
    assert.deepEqual(result.files[index].data, files[index].data)
    assert.match(result.files[index].sha256, /^[0-9a-f]{64}$/)
  }
  const zipEntries = parseStoreZip(archive)
  assert.ok(zipEntries.has("ArchiveDesk/manifest.json"))
  assert.ok(zipEntries.has("files/資料/bytes.bin"))
  assert.deepEqual(await buildArchive(files, { createdAt: CREATED_AT }), archive)
})

test("comparison reports added, removed, changed, and unchanged files by path and content", async () => {
  const original = [
    { path: "keep/same.txt", data: encoder.encode("unchanged"), modifiedAt: 10 },
    { path: "edit/report.txt", data: encoder.encode("old report"), modifiedAt: 20 },
    { path: "remove/old.bin", data: new Uint8Array([1, 2, 3]), modifiedAt: 30 }
  ]
  const archive = await buildArchive(original, { createdAt: CREATED_AT })
  const changed = encoder.encode("new report")
  const fresh = [
    { path: "keep/same.txt", data: encoder.encode("unchanged"), modifiedAt: 999 },
    { path: "edit/report.txt", data: changed, modifiedAt: 20 },
    { path: "add/new folder/new.txt", data: encoder.encode("new"), modifiedAt: 40 }
  ]
  const originalSnapshot = fresh.map(file => file.data.slice())
  const result = await compareArchiveToFiles(archive, fresh)
  assert.deepEqual(result.counts, { added: 1, removed: 1, changed: 1, unchanged: 1 })
  assert.deepEqual(result.rows, [
    { path: "add/new folder/new.txt", status: "added", beforeBytes: null, afterBytes: 3 },
    { path: "edit/report.txt", status: "changed", beforeBytes: 10, afterBytes: 10 },
    { path: "keep/same.txt", status: "unchanged", beforeBytes: 9, afterBytes: 9 },
    { path: "remove/old.bin", status: "removed", beforeBytes: 3, afterBytes: null }
  ])
  for (let index = 0; index < fresh.length; index += 1) assert.deepEqual(fresh[index].data, originalSnapshot[index])
})

test("recovery ZIP has only original root paths and byte-for-byte file data", async () => {
  const source = [
    { path: "folder/one.txt", data: encoder.encode("restore me"), modifiedAt: 1_700_000_000_000 },
    { path: "資料/two.bin", data: new Uint8Array([0, 255, 2]), modifiedAt: 1_700_000_000_002 }
  ]
  const backup = await buildArchive(source, { createdAt: CREATED_AT })
  const recovery = await createRecoveryZip(backup)
  const entries = parseStoreZip(recovery)
  assert.deepEqual(Array.from(entries.keys()).sort(), ["folder/one.txt", "資料/two.bin"].sort())
  assert.deepEqual(entries.get("folder/one.txt"), source[0].data)
  assert.deepEqual(entries.get("資料/two.bin"), source[1].data)
  await assert.rejects(() => createRecoveryZip(new Uint8Array([1, 2, 3])), /end record|Unsupported/)
})

test("payload damage, truncation, ZIP64 markers, unsupported compression, and mismatched local records fail", async () => {
  const built = await buildArchive([{ path: "note.txt", data: encoder.encode("integrity") }], { createdAt: CREATED_AT })
  const parsed = parseStoreZip(built)
  const fileEntry = Array.from(parsed.entries()).find(([name]) => name === "files/note.txt")
  const damaged = built.slice()
  const dataMarker = Array.from(encoder.encode("integrity"))
  let found = -1
  outer: for (let start = 0; start <= damaged.length - dataMarker.length; start += 1) {
    for (let index = 0; index < dataMarker.length; index += 1) if (damaged[start + index] !== dataMarker[index]) continue outer
    found = start
    break
  }
  assert.ok(found >= 0)
  damaged[found] ^= 1
  await assert.rejects(() => verifyArchive(damaged), /CRC check/)
  await assert.rejects(() => verifyArchive(built.subarray(0, built.length - 1)), /end record|central directory/)

  const valid = await validRawBackup()
  const zip64 = valid.bytes.slice()
  new DataView(zip64.buffer).setUint32(zip64.length - 22 + 12, 0xffffffff, true)
  await assert.rejects(() => verifyArchive(zip64), /ZIP64/)

  const fileBytes = encoder.encode("safe data")
  const digest = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", fileBytes)), byte => byte.toString(16).padStart(2, "0")).join("")
  const compressed = rawZip([
    manifestEntry("safe.txt", fileBytes, digest),
    { name: "files/safe.txt", data: fileBytes, localMethod: 8, centralMethod: 8 }
  ])
  await assert.rejects(() => verifyArchive(compressed.bytes), /STORE|compression/)

  const mismatched = rawZip([
    manifestEntry("safe.txt", fileBytes, digest),
    { name: "files/safe.txt", data: fileBytes, localName: "files/nope.txt" }
  ])
  await assert.rejects(() => verifyArchive(mismatched.bytes), /filenames do not match/)
  assert.ok(fileEntry)
})

test("hostile paths, case and NFC collisions, unknown product fields, and unknown files are rejected", async () => {
  const safeData = encoder.encode("safe data")
  const safeDigest = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", safeData)), byte => byte.toString(16).padStart(2, "0")).join("")

  const traversal = rawZip([
    manifestEntry("safe.txt", safeData, safeDigest),
    { name: "files/../safe.txt", data: safeData }
  ])
  await assert.rejects(() => verifyArchive(traversal.bytes), /parent path segment/)

  const unknownManifest = rawZip([
    { name: "ArchiveDesk/manifest.json", data: encoder.encode(JSON.stringify({
      format: "archive-desk", version: 1, createdAt: CREATED_AT, files: [{ path: "safe.txt", bytes: safeData.length, sha256: safeDigest, modifiedAt: 0 }], extraProductField: true
    })) },
    { name: "files/safe.txt", data: safeData }
  ])
  await assert.rejects(() => verifyArchive(unknownManifest.bytes), /unsupported fields/)

  const extraFile = rawZip([
    manifestEntry("safe.txt", safeData, safeDigest),
    { name: "files/safe.txt", data: safeData },
    { name: "unexpected.txt", data: "outside the product format" }
  ])
  await assert.rejects(() => verifyArchive(extraFile.bytes), /unexpected or missing files/)

  const duplicate = rawZip([
    manifestEntry("same.txt", safeData, safeDigest),
    { name: "files/same.txt", data: safeData },
    { name: "FILES/SAME.TXT", data: safeData }
  ])
  await assert.rejects(() => verifyArchive(duplicate.bytes), /collisions/)

  await assert.rejects(() => buildArchive([
    { path: "café.txt", data: safeData },
    { path: "cafe\u0301.txt", data: safeData }
  ], { createdAt: CREATED_AT }), /collisions/)
  await assert.rejects(() => buildArchive([{ path: "../escape.txt", data: safeData }], { createdAt: CREATED_AT }), /parent path segment/)
  await assert.rejects(() => buildArchive([{ path: "NUL.txt", data: safeData }], { createdAt: CREATED_AT }), /Windows-reserved/)
  await assert.rejects(() => buildArchive([{ path: "bad\u0085name.txt", data: safeData }], { createdAt: CREATED_AT }), /control character/)
})

test("manifest duplicate keys, local-central flag mismatch, bad SHA, invalid dates, and invalid limits fail clearly", async () => {
  const safeData = encoder.encode("safe data")
  const digest = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", safeData)), byte => byte.toString(16).padStart(2, "0")).join("")
  const duplicateJson = `{"format":"archive-desk","format":"archive-desk","version":1,"createdAt":"${CREATED_AT}","files":[]}`
  const duplicateManifest = rawZip([
    { name: "ArchiveDesk/manifest.json", data: encoder.encode(duplicateJson) },
    { name: "files/safe.txt", data: safeData }
  ])
  await assert.rejects(() => verifyArchive(duplicateManifest.bytes), /duplicate JSON field/)

  const flagMismatch = rawZip([
    manifestEntry("safe.txt", safeData, digest),
    { name: "files/safe.txt", data: safeData, localFlags: 0x0000 }
  ])
  await assert.rejects(() => verifyArchive(flagMismatch.bytes), /flags, compression, or extra fields/)

  const badSha = rawZip([
    manifestEntry("safe.txt", safeData, "f".repeat(64)),
    { name: "files/safe.txt", data: safeData }
  ])
  await assert.rejects(() => verifyArchive(badSha.bytes), /SHA-256 check/)

  const invalidDateManifest = rawZip([
    { name: "ArchiveDesk/manifest.json", data: encoder.encode(JSON.stringify({
      format: "archive-desk", version: 1, createdAt: "2026-02-30T00:00:00.000Z", files: [{ path: "safe.txt", bytes: safeData.length, sha256: digest, modifiedAt: 0 }]
    })) },
    { name: "files/safe.txt", data: safeData }
  ])
  await assert.rejects(() => verifyArchive(invalidDateManifest.bytes), /valid ISO UTC date/)

  await assert.rejects(() => buildArchive([], { createdAt: CREATED_AT }), /at least one file/)
  await assert.rejects(() => buildArchive([{ path: "a.txt", data: safeData, surprise: true }], { createdAt: CREATED_AT }), /unsupported field/)
  await assert.rejects(() => buildArchive([{ path: "a.txt", data: safeData }], { createdAt: "yesterday" }), /valid ISO UTC date/)
  await assert.rejects(() => buildArchive([{ path: "a.txt", data: new Uint8Array(LIMITS.maxFileBytes + 1) }], { createdAt: CREATED_AT }), /per-file limit/)
})

test("size labels and input limits are explicit", async () => {
  assert.deepEqual(LIMITS, { maxFiles: 500, maxFileBytes: 20 * 1024 * 1024, maxTotalBytes: 50 * 1024 * 1024 })
  assert.equal(formatBytes(0), "0 B")
  assert.equal(formatBytes(1024), "1.0 KiB")
  assert.equal(formatBytes(1024 * 1024), "1.0 MiB")
  assert.throws(() => formatBytes(-1), /non-negative/)
  await assert.rejects(() => buildArchive(Array.from({ length: LIMITS.maxFiles + 1 }, (_, index) => ({ path: `f${index}.txt`, data: new Uint8Array() })), { createdAt: CREATED_AT }), /at most 500 files/)
})


test('filename components respect the 255 UTF-16 unit boundary during creation and import', async () => {
  for (const path of ['x'.repeat(255), 'folder/' + '界'.repeat(255), '📦'.repeat(127) + 'x']) {
    const source = [{ path, data: encoder.encode('boundary data'), modifiedAt: 0 }]
    const checked = await verifyArchive(await buildArchive(source, {createdAt: CREATED_AT}))
    assert.equal(checked.files[0].path, path)
    const imported = await verifyArchive((await validRawBackup(path, 'boundary data')).bytes)
    assert.equal(imported.files[0].path, path)
    assert.ok((await createRecoveryZip((await validRawBackup(path, 'boundary data')).bytes)).length > 0)
  }
  for (const path of ['x'.repeat(256), 'folder/' + '界'.repeat(256), '📦'.repeat(128)]) {
    await assert.rejects(buildArchive([{path, data: encoder.encode('boundary data'), modifiedAt: 0}], {createdAt: CREATED_AT}), /filename component.*255/)
    await assert.rejects(verifyArchive((await validRawBackup(path, 'boundary data')).bytes), /filename component.*255/)
  }
})
