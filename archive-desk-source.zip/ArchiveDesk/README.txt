ARCHIVE DESK 1.0.0
Project backup utility

Create an ordinary ZIP from selected project files, reopen that saved copy to check each file, compare it with a newer selection and export recovered files into a new ZIP.

PORTABLE BUILD
ArchiveDesk.html is a self-contained candidate with embedded scripts, styles and the original vector mark. It contains no external runtime assets and uses hash-restricted inline code. Open it in a current desktop Chromium browser to try the local-file version. Final browser acceptance of this portable build is still pending. The source package also contains the server version below.

RUN THE SERVER VERSION
Use a current desktop Chromium browser and Node.js 20 or later.
1. Extract this source package into a new folder.
2. Open a terminal in that folder and run: node server.mjs
3. Visit http://127.0.0.1:4321 in the browser.
No package installation or account is required. Keep the terminal open while using the app. Stop the server when finished.
The server listens only on this computer and serves a fixed list of application files. It does not accept uploads.

MAKE A CHECKED BACKUP
Choose individual files or choose a folder to preserve relative paths. Check the file list and total size. Create the backup, then download it. Open the file you actually downloaded in Verify archive. A successful in-memory build alone does not prove a saved copy exists.

RECOVER INTO A NEW FOLDER
Open an Archive Desk backup in Verify archive. The app checks the ZIP structure, CRC values and each file's SHA-256 against the manifest. Download recovered files, then use your ZIP utility to extract into a NEW empty folder. Inspect that copy before using it. Archive Desk never writes into the original project folder.

COMPARE VERSIONS
Open a saved backup in Compare versions and select the newer files in Create backup. Compare files reports added, changed, removed and unchanged paths. Removed means absent from the selected set. No comparison deletes a file. This version requires at least one current file. The JSON report records the baseline archive hash and differences.
The changed demo gives one added, one changed, one removed and two unchanged files when compared with the original demo backup.

LIMITS AND COMPATIBILITY
Up to 500 files, 20 MiB per file and 50 MiB total file content. A saved archive input can be up to 52 MiB including headers and manifest. Paths are limited to 1024 UTF-8 bytes, with each filename or folder component limited to 255 UTF-16 code units. Conservative Windows filename checks and file/folder collision checks also apply. A long path can still exceed the extraction limits of your operating system or ZIP utility.
Archive Desk reads its own ZIP v1 format only. It uses uncompressed ZIP STORE with UTF-8 names. Arbitrary compressed, encrypted, split and ZIP64 archives are unsupported. Empty files are supported. Empty directories, permissions, symbolic links and creation timestamps are not preserved. Modified timestamps are recorded in the manifest. ZIP timestamps are clamped to the ZIP date range and have two-second precision.
Use the ordinary recovery ZIP with a compatible ZIP utility. No claim is made that Archive Desk imports every ordinary ZIP.

PRIVACY AND INTEGRITY
All selected file processing runs inside the browser tab. There is no upload endpoint, cloud account or automatic sync. The app does not save its file selection in browser storage. Closing or reloading the tab discards the selection, so download the ZIP first.
Backups are NOT encrypted. Do not publish an archive containing credentials, private keys, identity records or client files. Filename warnings are incomplete and cannot identify every secret.
CRC and SHA-256 checks detect inconsistencies and corruption. They do not authenticate the author or protect against someone rewriting both the payload and its manifest. Keep a trusted copy or independently retained archive hash if authenticity matters. Keep a second backup in a separate place.

DEVELOPMENT CHECKS
Run: node --test core.test.mjs acceptance.test.mjs
Run: node build.mjs
The build copies five application files into dist and writes a self-contained ArchiveDesk.html. It does not remove unrelated files.

STATUS
Independent demonstration. Browser acceptance is recorded separately from source test results. No customer acceptance, production migration, financial checkout, Etsy listing or sale is implied by this package. Do not rely on it as the only copy of important data.

CREDITS
Original application code and vector mark by SanderSaxBuilds. System fonts. No third-party runtime packages or artwork are bundled.