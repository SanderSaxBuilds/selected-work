import test from 'node:test'
import assert from 'node:assert/strict'
import { buildArchive, verifyArchive, createRecoveryZip, LIMITS } from './core.mjs'
const data = new TextEncoder().encode('a known payload')
const file = path => ({ path, data, modifiedAt: 1792281600000 })
const options = { createdAt: '2026-10-18T02:00:00.000Z' }

test('file and directory collisions are rejected in either order, including case and NFC aliases', async () => {
  for (const paths of [['a', 'a/b.txt'], ['a/b.txt', 'a'], ['A', 'a/b'], ['café', 'cafe\u0301/b']]) {
    await assert.rejects(buildArchive(paths.map(file), options), /file and folder path collision/)
  }
})

test('path cap uses UTF-8 bytes, not only code units', async () => {
  await assert.rejects(buildArchive([file('x'.repeat(1025))], options), /too long/)
  await assert.rejects(buildArchive([file('界'.repeat(171) + '/' + '界'.repeat(171))], options), /too long/)
  const valid = await verifyArchive(await buildArchive([file([...Array(4).fill('x'.repeat(200)), 'x'.repeat(220)].join('/'))], options))
  assert.equal(valid.files[0].path.length, 1024)
})

test('all Windows device names and unsafe path forms are rejected', async () => {
  for (const path of ['/absolute', 'C:/drive', 'back\\slash', 'a//b', './a', 'a/../b', 'a.', 'a ', 'CON.txt', 'COM1', 'LPT9.log', 'COM¹.txt', 'a\u0000b', 'a:b', 'x?y']) {
    await assert.rejects(buildArchive([file(path)], options), Error, path)
  }
})

test('both writing and verification snapshot caller bytes across asynchronous hashing', async () => {
  const input = data.slice()
  const pending = buildArchive([{ ...file('a.txt'), data: input }], options)
  input.fill(0)
  const zip = await pending
  assert.deepEqual((await verifyArchive(zip)).files[0].data, data)
  const before = zip.slice()
  const checking = verifyArchive(zip)
  zip.fill(0)
  assert.deepEqual((await checking).files[0].data, data)
  assert.ok(before.some(byte => byte !== 0))
})

test('total and per-file limits accept the boundary and reject one byte over', async () => {
  const a = new Uint8Array(LIMITS.maxFileBytes)
  const b = new Uint8Array(10 * 1024 * 1024)
  const files = [{path:'a.bin',data:a}, {path:'b.bin',data:a}, {path:'c.bin',data:b}]
  const zip = await buildArchive(files, options)
  assert.ok(zip.length > LIMITS.maxTotalBytes && zip.length < 52 * 1024 * 1024)
  assert.equal((await verifyArchive(zip)).files.reduce((sum, item) => sum + item.bytes, 0), LIMITS.maxTotalBytes)
  await assert.rejects(buildArchive([...files, {path:'extra',data:new Uint8Array([0])}], options), /total limit/)
})

test('central data overlap and bytes appended after the end record fail', async () => {
  const zip = await buildArchive([file('a.txt'), file('b.txt')], options)
  const corrupted = zip.slice()
  const view = new DataView(corrupted.buffer)
  const central = view.getUint32(corrupted.length - 6, true)
  view.setUint32(central + 42, 1, true)
  await assert.rejects(verifyArchive(corrupted), /local file record|local records/)
  const appended = new Uint8Array(zip.length + 1)
  appended.set(zip)
  await assert.rejects(verifyArchive(appended), /end record/)
})

test('a previously valid archive is checked again at recovery time', async () => {
  const zip = await buildArchive([file('a.txt')], options)
  await verifyArchive(zip)
  zip[40] ^= 1
  await assert.rejects(createRecoveryZip(zip), Error)
})
