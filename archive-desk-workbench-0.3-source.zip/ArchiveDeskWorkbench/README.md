# Archive Desk Workbench

Archive Desk Workbench is a local manual backup interface for a selected project folder. It creates ZIP archives, verifies their saved bytes, compares a current folder with a saved baseline, and restores files into a new folder. Version 0.3 adds a read-only recovery plan and downloadable verification reports. It also imports an existing Archive Desk ZIP when its original Workbench library record is unavailable.

## Start

Use Node.js 24. From this folder, run:

    npm start

The default workspace is the included synthetic demo folder. The backup library is created in workbench-data beside that folder. The server listens on 127.0.0.1 and prints the local address to open.

To choose folders and a port, run:

    node server.mjs --workspace "C:\Work\Project" --storage "D:\Project backups" --port 4330

The workspace and backup library must be separate regular folders. Existing linked folder components are refused. The browser interface accepts only local requests addressed to the exact loopback host and port.

## Use

Preview a relative folder within the configured workspace. A dot selects its root. The preview lists file paths and byte counts, plus paths skipped by the standard filename exclusions. It does not return file contents.

Create a backup after reviewing the preview. Each archive is verified after it is saved. The library records the label, source, file count, source size, archive size, archive SHA-256 and verification time. Comparison reports are saved beside the archive library. Restores are placed under the storage folder's restores directory. Existing restore folders are refused.

The sample workflow creates fictional files in a new folder under labs, compares an edited copy and restores the saved baseline into a new recovery folder. It does not write into the configured workspace.

## Import an existing backup

Choose a ZIP created by Archive Desk in the import panel and select Inspect archive. The app checks the ZIP structure, file manifest, CRC values and SHA-256 hashes. The preview lists the included paths and file sizes. Inspection does not add an archive or record to the library.

After inspection, choose a label and select Add verified copy to library. The app checks the uploaded bytes again, writes a new copy under the configured backup storage and verifies that saved copy before registering it. The selected original ZIP stays unchanged. A ZIP already present in this library is refused, even if you choose a different label.

An imported archive is marked Imported archive. It has no known original workspace folder. Compare changes uses the project folder currently entered in the source panel. Review recovery always writes beneath the backup storage's restores folder and refuses an existing destination. Keep your original archive until you have checked the recovered files.

The app can read the existing version 1 library format from Workbench 0.1. A corrupt or unrecognized library is refused, not silently replaced. To recover a ZIP without that library, restart the app with a new, separate empty storage folder and import the original ZIP there. Preserve the old storage folder for inspection.

## Review a recovery before writing

Select a saved backup and choose Review recovery. Enter a new folder name and select Check recovery plan. The app rereads the saved archive, checks its ZIP structure and file hashes, and confirms that the requested destination does not exist. The plan lists the relative recovery destination, file paths, sizes and SHA-256 hashes. Creating this plan does not write a folder, change library metadata or add activity.

After checking the inventory, select Restore checked copy. Changing the folder name clears the plan. Recovery checks the saved archive again, requires the same archive fingerprint shown in the plan, and still refuses an existing destination. A plan is a dated snapshot, not an atomic reservation or a guarantee against other programs changing files. The source remains unchanged.

## Download verification evidence

Download verification JSON checks the saved archive again before preparing a report. It includes the check time, backup label, archive fingerprint, file counts and each file's relative path, size and SHA-256. This download does not change the library or add activity. A damaged or missing archive is rejected instead of producing a passing report.

The report omits absolute workspace and backup-library paths. Labels and relative filenames can still identify your work. Review the report before sharing it. Hashes check consistency with the recorded archive, they do not prove ownership, a trusted origin or the absence of harmful content.

## Supported files and limits

The archive contains regular files and their relative paths. It does not restore empty folders, original timestamps or filesystem permissions. The archive uses the Archive Desk ZIP Store format with UTF-8 names. It does not import arbitrary ZIP files, compressed entries, encrypted archives or ZIP64.

Import accepts at most 52 MiB per ZIP and retains the same file-count and source-size limits. It supports the unencrypted Archive Desk ZIP Store profile produced by the browser app and CLI. The separate encrypted protection preview is not supported by this import flow.

Each backup supports up to 500 files, 20 MiB per file and 50 MiB total source data. Saved archives are limited to 52 MiB. Common .git, node_modules, .ssh, .env, .env.*, credentials.json, .pem, .key, .p12 and .pfx patterns are skipped. These filename exclusions are not sensitive-content detection.

Scanning and reading are not an atomic filesystem snapshot and do not provide an adversarial race guarantee. Close editors or other programs that may change files before creating a backup or comparison. Keep another copy on a separate device. This local preview is not a production backup service.

## Tests

Run the app and CLI test suite with:

    npm test

The HTTP tests use isolated synthetic folders. Test fixtures are retained after completion so their outputs can be inspected.
