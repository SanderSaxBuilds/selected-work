# Countback receiving workflow demo

Independent prototype using a synthetic three-line delivery. The guided walkthrough is scripted. Receiving counts, corrections and CSV export are manual. The demo makes no live voice, API or microphone calls. It does not persist the draft after leaving the page.

The original MIT license is included in `LICENSE`.
