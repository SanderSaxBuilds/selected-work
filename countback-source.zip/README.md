# Countback receiving workflow demo

Independent prototype using a synthetic six-line delivery. The guided walkthrough is scripted. Receiving counts, corrections and CSV export are manual. The demo makes no live voice, API or microphone calls. The draft is kept in the browser's local storage for this page only and is cleared by New receipt. Nothing is sent anywhere.

Open `index.html` through any static file server, for example `python -m http.server`, because the app loads as ES modules.

The original MIT license is included in `LICENSE`.
