import { mkdir, copyFile } from 'node:fs/promises'
const files = ['index.html', 'styles.css', 'app.mjs', 'core.mjs', 'protection.mjs', 'assets/mark.svg']
await mkdir(new URL('./dist/assets/', import.meta.url), { recursive: true })
for (const path of files) await copyFile(new URL(path, import.meta.url), new URL('dist/' + path, import.meta.url))
console.log('Built the six modular application files. No standalone compatibility claim.')
