import test from 'node:test'
import assert from 'node:assert/strict'
import { pbkdf2Sync, createDecipheriv, createCipheriv, randomBytes } from 'node:crypto'
import { buildArchive } from './core.mjs'
import { protectArchive, unlockArchive, inspectLockedFile, PROTECTION } from './protection.mjs'

// Public synthetic test phrase, never a user's account credential.
const phrase = 'synthetic backup recovery phrase'
const enc = new TextEncoder()
const samples = [
  { path: 'project/notes.txt', data: enc.encode('A deliberately recognizable synthetic payload, not client data.') },
  { path: 'project/empty.txt', data: new Uint8Array() },
  { path: 'project/日本語.bin', data: new Uint8Array([0, 255, 128, 1]) }
]
const source = () => buildArchive(samples, { createdAt: '2026-10-18T03:00:00.000Z' })

function independentDecrypt(envelope, password) {
  const b = Buffer.from(envelope)
  assert.equal(b.subarray(0, 8).toString(), 'ADLOCK01')
  const key = pbkdf2Sync(password, b.subarray(14, 30), b.readUInt32BE(10), 32, 'sha256')
  const decipher = createDecipheriv('aes-256-gcm', key, b.subarray(30, 42))
  decipher.setAAD(b.subarray(0, 48))
  decipher.setAuthTag(b.subarray(b.length - 16))
  return Buffer.concat([decipher.update(b.subarray(48, b.length - 16)), decipher.final()])
}

function independentEncrypt(zip, password) {
  const h = Buffer.alloc(48)
  h.write('ADLOCK01')
  h[8] = 1
  h[9] = 1
  h.writeUInt32BE(600000, 10)
  randomBytes(16).copy(h, 14)
  randomBytes(12).copy(h, 30)
  h.writeUInt32BE(zip.length, 42)
  const key = pbkdf2Sync(password, h.subarray(14, 30), 600000, 32, 'sha256')
  const cipher = createCipheriv('aes-256-gcm', key, h.subarray(30, 42))
  cipher.setAAD(h)
  return new Uint8Array(Buffer.concat([h, cipher.update(zip), cipher.final(), cipher.getAuthTag()]))
}

test('protected backup opens in an independent Node crypto reader and preserves exact ZIP bytes', async () => {
  const zip = await source()
  const locked = await protectArchive(zip, phrase)
  assert.deepEqual(independentDecrypt(locked, phrase), Buffer.from(zip))
  assert.equal(inspectLockedFile(locked).archiveBytes, zip.length)
  const reopened = await unlockArchive(locked, phrase)
  assert.deepEqual(reopened.bytes, zip)
  assert.deepEqual(reopened.result.files.map(f => [f.path, [...f.data]]), samples.map(f => [f.path, [...f.data]]))
})

test('an independently encrypted envelope unlocks and passes existing ZIP checks', async () => {
  const zip = await source()
  const independent = independentEncrypt(zip, phrase)
  const result = await unlockArchive(independent, phrase)
  assert.deepEqual(result.bytes, zip)
  assert.equal(result.result.files.length, 3)
})

test('fresh protection uses a different salt and nonce for the same file and passphrase', async () => {
  const zip = await source()
  const a = await protectArchive(zip, phrase)
  const b = await protectArchive(zip, phrase)
  assert.notDeepEqual(a.slice(14, 30), b.slice(14, 30))
  assert.notDeepEqual(a.slice(30, 42), b.slice(30, 42))
  assert.notDeepEqual(a, b)
  assert.equal(Buffer.from(a).includes(Buffer.from(samples[0].path)), false)
  assert.equal(Buffer.from(a).includes(Buffer.from(samples[0].data)), false)
})

test('wrong passphrases and altered ciphertext or authentication tags never return plaintext', async () => {
  const locked = await protectArchive(await source(), phrase)
  await assert.rejects(unlockArchive(locked, 'a different synthetic phrase'), /wrong or the file is damaged/)
  for (const index of [48, 65, locked.length - 1]) {
    const changed = locked.slice()
    changed[index] ^= 1
    await assert.rejects(unlockArchive(changed, phrase), /wrong or the file is damaged/)
  }
})

test('salt and nonce are authenticated, and reserved or unsupported key fields are rejected', async () => {
  const locked = await protectArchive(await source(), phrase)
  for (const index of [14, 30]) {
    const changed = locked.slice()
    changed[index] ^= 1
    await assert.rejects(unlockArchive(changed, phrase), /wrong or the file is damaged/)
  }
  for (const index of [8, 9, 13, 46, 47]) {
    const changed = locked.slice()
    changed[index] ^= 1
    await assert.rejects(unlockArchive(changed, phrase), /unsupported/)
  }
})

test('truncated, appended, oversized and non-envelope inputs fail before decryption', async () => {
  const locked = await protectArchive(await source(), phrase)
  for (const input of [locked.slice(0, 10), locked.slice(0, -1), new Uint8Array([...locked, 0]), enc.encode('not a locked file')]) {
    await assert.rejects(unlockArchive(input, phrase), /complete|length|adlock/)
  }
  const oversize = new Uint8Array(PROTECTION.maxArchiveBytes + 65)
  await assert.rejects(unlockArchive(oversize, phrase), /size/)
  const lengthTampered = locked.slice()
  new DataView(lengthTampered.buffer).setUint32(42, 0xffffffff)
  await assert.rejects(unlockArchive(lengthTampered, phrase), /length/)
})

test('only validated Archive Desk ZIPs are protected or accepted after authenticated decryption', async () => {
  const garbage = enc.encode('This is not a ZIP archive, and should not become a verified backup.')
  await assert.rejects(protectArchive(garbage, phrase), Error)
  await assert.rejects(unlockArchive(independentEncrypt(garbage, phrase), phrase), Error)
})

test('passphrase boundaries reject short, blank, too long and malformed Unicode input', async () => {
  const zip = await source()
  for (const password of ['', 'short', ' '.repeat(12), '\ud800'.repeat(12), '界'.repeat(342)]) {
    await assert.rejects(protectArchive(zip, password), /passphrase|Unicode/)
  }
  const valid = '界'.repeat(341) + 'x'
  const locked = await protectArchive(zip, valid)
  assert.deepEqual((await unlockArchive(locked, valid)).bytes, zip)
})

test('Unicode normalization, leading spaces and capitalization remain literal', async () => {
  const password = '  Café synthetic phrase'
  const locked = await protectArchive(await source(), password)
  assert.equal((await unlockArchive(locked, password)).result.files.length, 3)
  await assert.rejects(unlockArchive(locked, password.normalize('NFD')), /wrong or the file is damaged/)
  await assert.rejects(unlockArchive(locked, password.trim()), /wrong or the file is damaged/)
  await assert.rejects(unlockArchive(locked, password.toLowerCase()), /wrong or the file is damaged/)
})

test('asynchronous protection and unlock snapshot caller-owned bytes', async () => {
  const original = await source()
  const mutable = original.slice()
  const pending = protectArchive(mutable, phrase)
  mutable.fill(0)
  const locked = await pending
  assert.deepEqual(independentDecrypt(locked, phrase), Buffer.from(original))
  const copy = locked.slice()
  const opening = unlockArchive(copy, phrase)
  copy.fill(0)
  assert.deepEqual((await opening).bytes, original)
})
