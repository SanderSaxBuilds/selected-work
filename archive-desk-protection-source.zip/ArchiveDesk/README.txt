ARCHIVE DESK 1.1.0 CANDIDATE
Project backups with optional encrypted copies

This developer source candidate adds Protect a backup to the existing create, verify, compare and recovery tools. The public 1.0 app is a separate release. This candidate is not an Etsy listing or an independently audited security product.

RUN THE MODULAR APP
Extract this package into a new folder. In that folder run:
node server.mjs
Open http://127.0.0.1:4322 in a current Chromium browser.
The server listens only on 127.0.0.1 and serves six fixed application files. It accepts no uploads. No package installation, account or paid service is required. The tested runtime is Node.js 24.19.0. Other runtimes and browsers are not certified by this package.
ARCHIVE_DESK_PORT can select another local port if 4322 is already in use.
This package contains no standalone HTML build. Direct local-file compatibility is not claimed.

CREATE AND CHECK A ZIP
Choose files or a folder, inspect relative paths and create the backup. Download it. In Verify archive reopen the file actually downloaded. Each file is checked against the manifest. An in-memory build does not prove a saved copy exists.

LOCK A BACKUP
Open Protect a backup. Use the ZIP just created, or choose an existing Archive Desk ZIP from disk.
Set and repeat a unique passphrase of at least 12 characters. Use a longer phrase and keep it separate from the locked file. Spaces, capitalization and Unicode are literal, not normalized. The limit is 1024 UTF-8 bytes.
Encrypt, download the .adlock file, then reopen that actual saved file in the same workspace and enter its passphrase. The app authenticates the encrypted payload and verifies the ZIP and file hashes before offering recovery.
The original ZIP stays unencrypted. Locking creates a separate copy, it never deletes or rewrites the original.
A lost passphrase cannot be reset or recovered.

RECOVER
After an unlock, Download recovered ZIP exports original file bytes and relative paths. That recovery ZIP is UNENCRYPTED. Extract into a NEW folder and inspect the result. Keep important files in more than one place.

COMPARE
Compare versions accepts ordinary Archive Desk ZIPs. It does not accept locked envelopes directly. Unlock a saved envelope and recover the files first if needed. Comparison never changes the originals. At least one current file is required. Reports distinguish added, changed, removed and unchanged paths.

LIMITS
Up to 500 files, 20 MiB per file and 50 MiB of file content. Ordinary archive input is limited to 52 MiB. Locked envelopes add 64 bytes. Paths are capped at 1024 UTF-8 bytes and each component at 255 UTF-16 units, with conservative Windows path and collision checks. Operating-system extraction limits can be lower.
Own ZIP v1 format only, uncompressed UTF-8 STORE. Arbitrary compressed, encrypted, split or ZIP64 archives are unsupported. The .adlock format is a separate authenticated envelope, not a password-protected ZIP. Standard ZIP utilities cannot read it directly. Empty files are supported, empty directories, symlinks and permissions are not preserved.

PRIVACY AND SECURITY LIMITS
File names, file contents and manifest are encrypted inside .adlock. The outside filename and total file size remain visible.
Processing stays in the browser tab. There is no upload, cloud account, sync or persistent browser storage. Fields clear after an encryption or unlock attempt, but this does not guarantee removal from device memory. A compromised browser or device can expose files while they are in use.
AES-256-GCM uses a fresh random 128-bit salt and 96-bit nonce for each encryption. PBKDF2-HMAC-SHA-256 derives the key with 600,000 iterations. The fixed header is authenticated as additional data. Wrong passwords and damaged payloads do not return recovery data.
This is scoped functional evidence, not an independent cryptographic audit or production security certification. Keep another tested copy.

DEVELOPMENT CHECKS
node --test core.test.mjs acceptance.test.mjs protection.test.mjs
node build.mjs
The build copies six modular files to dist and preserves unrelated files. Final local evidence covers 25 core tests, 14 browser cases, five populated widths and independent saved-file crypto and ZIP readers. Public deployment and direct local-file checks are separate.

CREDITS
Original code and vector mark by SanderSaxBuilds. System fonts. No third-party runtime packages or artwork are bundled.

REFERENCES
https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/encrypt
https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/deriveKey
https://developer.mozilla.org/en-US/docs/Web/API/AesGcmParams
