import http from 'node:http'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
const files = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/index.html', ['index.html', 'text/html; charset=utf-8']],
  ['/styles.css', ['styles.css', 'text/css; charset=utf-8']],
  ['/app.mjs', ['app.mjs', 'text/javascript; charset=utf-8']],
  ['/core.mjs', ['core.mjs', 'text/javascript; charset=utf-8']],
  ['/protection.mjs', ['protection.mjs', 'text/javascript; charset=utf-8']],
  ['/assets/mark.svg', ['assets/mark.svg', 'image/svg+xml']]
])
const port = Number(process.env.ARCHIVE_DESK_PORT || 4322)
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Choose a port between 1024 and 65535.')
const server = http.createServer(async (req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { Allow: 'GET, HEAD' })
    res.end('Method not allowed')
    return
  }
  let pathname
  try { pathname = new URL(req.url, 'http://127.0.0.1').pathname } catch { res.writeHead(400).end('Invalid URL'); return }
  const match = files.get(pathname)
  if (!match) { res.writeHead(404).end('Not found'); return }
  try {
    const body = await readFile(fileURLToPath(new URL(match[0], import.meta.url)))
    res.writeHead(200, { 'Content-Type': match[1], 'Content-Length': body.length, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' })
    res.end(req.method === 'HEAD' ? undefined : body)
  } catch { res.writeHead(500).end('Could not load the application file') }
})
server.listen(port, '127.0.0.1', () => console.log(`Archive Desk: http://127.0.0.1:${port}`))