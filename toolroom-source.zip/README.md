# Toolroom 1.0.1

A working digital product storefront study by SanderSaxBuilds. It has a responsive catalogue, product details, saved tools, a bag, local demo checkout, a download library and portable backups.

This independent demonstration is not connected to Etsy, Payhip or a payment service. It does not charge money, grant real licenses, send email or distribute full product archives. Checkout records are demo data. The four product names and versions refer to existing local tools. Prices are draft hypotheses, and preview files are illustrative samples.

## Run locally

Use Node.js 22 or later. There are no dependencies or installation hooks.

```text
node server.mjs
```

Open http://127.0.0.1:4319 in a browser. The preview server binds only to the local device and serves an explicit allowlist of application files. Backups, tests and development receipts are not exposed.

## Check the core

```text
node --test core.test.mjs
```

The pure data layer uses integer cents, trusted product snapshots, idempotent bag additions and normalized demo contacts. Restore rejects malformed versions, unknown fields, invalid totals and dangerous object keys before changing the active library. This validates structure and contents, not the origin of a backup.

## Try the flow

1. Search, filter, sort or save a tool.
2. Open details and download a free sample.
3. Add tools to the bag, remove an item, then try demo checkout with fictional details.
4. Open Your library to download a sample or demo receipt.
5. Export a backup. Choose the file in Backup and restore, inspect the preview and confirm the replacement.

Browser storage is local to a device and origin. Cleared storage, private browsing or changing the hosted address can remove or separate the library. Export a backup before moving between addresses. Backups include demo contact fields entered at checkout.

## Files

- `index.html`, `styles.css` and `app.mjs` contain the interface.
- `core.mjs` contains state, catalogue and validation.
- `core.test.mjs` covers transitions, totals and malformed backups.
- `server.mjs` is the loopback preview server.
- `build.mjs` copies only the five browser files into `dist`.

## Production boundary

Real checkout, payment verification, taxes, protected fulfillment, email delivery, authentication and customer support are not implemented. Production needs those services, a server-side order source of truth, refund and licensing decisions, and a security review. Do not use local demo records as payment proof. No secrets belong in browser files or backups.

Version 1.0.1 prepares the public portfolio demonstration. It normalizes interface labels and removes overlapping decorative labels and keeps the illustration inside narrow layouts. Core behavior and backup format remain unchanged.
