import http from 'node:http'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
const root = path.dirname(fileURLToPath(import.meta.url))
const types = { '.html': 'text/html; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml' }
const allowed = new Set(['/index.html', '/styles.css', '/app.mjs', '/core.mjs', '/assets/mark.svg'])
const server = http.createServer(async (request, response) => {
  try {
    if (!['GET', 'HEAD'].includes(request.method)) { response.writeHead(405, { Allow: 'GET, HEAD' }); return response.end('Method not allowed') }
    const pathname = new URL(request.url, 'http://localhost').pathname
    const file = pathname === '/' ? '/index.html' : pathname
    if (!allowed.has(file)) { response.writeHead(404); return response.end('Not found') }
    const content = await readFile(path.join(root, file))
    response.writeHead(200, { 'Content-Type': types[path.extname(file)], 'Content-Length': content.length, 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'", 'Cache-Control': 'no-store' })
    response.end(request.method === 'HEAD' ? undefined : content)
  } catch { response.writeHead(500); response.end('Preview could not load this file') }
})
server.listen(4319, '127.0.0.1', () => process.stdout.write('Toolroom preview: http://127.0.0.1:4319\n'))
