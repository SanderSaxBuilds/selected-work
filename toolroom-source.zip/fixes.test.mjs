// Regression tests for the 19 October 2026 Toolroom audit.
import assert from 'node:assert/strict'
import test from 'node:test'
import { addToCart, backupFileName, checkoutProblem, createDemoOrder, createState, parseBackup, receiptText } from './core.mjs'

test('core errors read as complete sentences so restore messages do not run together', () => {
  assert.throws(() => addToCart(createState(), 'nope'), error => error.message === 'Unknown product id.')
  assert.throws(() => parseBackup('hello'), error => error.message.endsWith('.'))
})

test('checkoutProblem explains whitespace names and incomplete emails in plain language', () => {
  assert.equal(checkoutProblem({ name: '   ', email: 'jo@example.com' }), 'Enter your name.')
  assert.equal(checkoutProblem({ name: 'Jo', email: '' }), 'Enter an email address.')
  assert.match(checkoutProblem({ name: 'Jo', email: 'jo@example' }), /full email address/)
  assert.equal(checkoutProblem({ name: 'x'.repeat(81), email: 'jo@example.com' }), 'Keep the name to 80 characters or fewer.')
  assert.equal(checkoutProblem({ name: ' Jordan Example ', email: 'jordan@example.com ' }), '')
})

test('backup file name uses the local calendar date, not the UTC date', () => {
  const lateEvening = new Date(2026, 9, 19, 23, 30)
  assert.equal(backupFileName(lateEvening), 'Toolroom_backup_2026-10-19.json')
  const earlyMorning = new Date(2026, 0, 2, 0, 15)
  assert.equal(backupFileName(earlyMorning), 'Toolroom_backup_2026-01-02.json')
})

test('receipt is readable text with each tool, the total and an honest note', () => {
  const state = addToCart(addToCart(createState(), 'quotecheck'), 'exportcheck')
  const next = createDemoOrder(state, { name: 'Jordan Example', email: 'jordan@example.com' }, { id: 'TR-ABC12345', createdAt: '2026-10-19T08:00:00.000Z' })
  const text = receiptText(next.orders[0])
  assert.match(text, /Order TR-ABC12345/)
  assert.match(text, /QuoteCheck 1\.1\.0 +\$14\.00/)
  assert.match(text, /ExportCheck 1\.1\.0 +\$19\.00/)
  assert.match(text, /Total +\$33\.00/)
  assert.match(text, /No payment was taken/)
})
