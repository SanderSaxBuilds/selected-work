import { mkdir, copyFile, readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
const root = path.dirname(fileURLToPath(import.meta.url))
const files = ['index.html', 'styles.css', 'app.mjs', 'core.mjs', 'assets/mark.svg']
for (const file of files) {
  await mkdir(path.dirname(path.join(root, 'dist', file)), { recursive: true })
  await copyFile(path.join(root, file), path.join(root, 'dist', file))
  if (!(await readFile(path.join(root, file))).equals(await readFile(path.join(root, 'dist', file)))) throw new Error('Build copy mismatch')
}
process.stdout.write('Toolroom static build verified: 5 files\n')
