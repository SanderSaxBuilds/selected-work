import assert from 'node:assert/strict'
import test from 'node:test'
import {
  CATALOG,
  addToCart,
  createDemoOrder,
  createState,
  exportBackup,
  parseBackup,
  removeFromCart,
  subtotal,
  toggleSaved
} from './core.mjs'

const TIMESTAMP = '2026-10-18T01:02:03.000Z'
const CONTACT = { name: 'Casey Example', email: 'casey@example.com' }

function createOneItemOrder(id = 'order-1') {
  return {
    id,
    createdAt: TIMESTAMP,
    name: CONTACT.name,
    email: CONTACT.email,
    items: [{
      productId: 'quotecheck',
      title: 'QuoteCheck',
      version: '1.1.0',
      priceCents: 1400
    }],
    totalCents: 1400,
    mode: 'demo',
    currency: 'USD'
  }
}

function stateWithOrders(count) {
  return {
    schema: 1,
    cart: [],
    saved: [],
    orders: Array.from({ length: count }, (_, index) => createOneItemOrder(`order-${index + 1}`))
  }
}

function orderState() {
  const cart = addToCart(addToCart(createState(), 'quotecheck'), 'exportcheck')
  return createDemoOrder(cart, CONTACT, { id: 'order-1', createdAt: TIMESTAMP })
}

test('catalog contains the four specified draft products and is immutable', () => {
  assert.deepEqual(CATALOG.map(({ id, name, version, priceCents, category }) => ({
    id,
    name,
    version,
    priceCents,
    category
  })), [
    { id: 'quotecheck', name: 'QuoteCheck', version: '1.1.0', priceCents: 1400, category: 'pricing' },
    { id: 'exportcheck', name: 'ExportCheck', version: '1.1.0', priceCents: 1900, category: 'data' },
    { id: 'handoffdesk', name: 'Handoff Desk', version: '1.0.1', priceCents: 1200, category: 'projects' },
    { id: 'quotehandoffkit', name: 'Quote and Handoff Kit', version: '1.1.0r2', priceCents: 2200, category: 'bundles' }
  ])
  assert.ok(Object.isFrozen(CATALOG))
  assert.ok(CATALOG.every(product => Object.isFrozen(product) && Object.isFrozen(product.tags) && Object.isFrozen(product.includes)))
})

test('cart math, saved toggles, and demo order lifecycle use trusted catalog cents', () => {
  const initial = createState()
  const cart = addToCart(addToCart(initial, 'quotecheck'), 'exportcheck')
  assert.equal(subtotal(cart), 3300)
  assert.deepEqual(initial, { schema: 1, cart: [], saved: [], orders: [] })

  const saved = toggleSaved(toggleSaved(cart, 'handoffdesk'), 'quotehandoffkit')
  assert.deepEqual(saved.saved, ['handoffdesk', 'quotehandoffkit'])
  const unsaved = toggleSaved(saved, 'handoffdesk')
  assert.deepEqual(unsaved.saved, ['quotehandoffkit'])

  const completed = createDemoOrder(saved, { name: ' Casey Example ', email: 'casey@example.com ' }, {
    id: 'order-17',
    createdAt: TIMESTAMP
  })
  assert.deepEqual(completed.cart, [])
  assert.deepEqual(completed.saved, ['handoffdesk', 'quotehandoffkit'])
  assert.deepEqual(completed.orders[0], {
    id: 'order-17',
    createdAt: TIMESTAMP,
    name: 'Casey Example',
    email: 'casey@example.com',
    items: [
      { productId: 'quotecheck', title: 'QuoteCheck', version: '1.1.0', priceCents: 1400 },
      { productId: 'exportcheck', title: 'ExportCheck', version: '1.1.0', priceCents: 1900 }
    ],
    totalCents: 3300,
    mode: 'demo',
    currency: 'USD'
  })
  assert.equal(completed.orders[0].mode, 'demo')
  assert.equal(completed.orders[0].currency, 'USD')
  assert.deepEqual(saved.cart, ['quotecheck', 'exportcheck'])
})

test('cart addition is idempotent and removal is safe when the product is absent', () => {
  const state = addToCart(createState(), 'quotecheck')
  const duplicate = addToCart(state, 'quotecheck')
  assert.deepEqual(duplicate, state)
  assert.notEqual(duplicate, state)
  assert.deepEqual(removeFromCart(state, 'exportcheck'), state)
  assert.deepEqual(removeFromCart(state, 'quotecheck').cart, [])
  assert.throws(() => addToCart(state, 'QuoteCheck'), /Unknown product id/)
  assert.throws(() => removeFromCart(state, '__proto__'), /Unknown product id/)
  assert.throws(() => toggleSaved(state, null), /Unknown product id/)
})

test('demo order rejects an empty cart, invalid contacts, unsafe ids, and repeated ids', () => {
  const empty = createState()
  const cart = addToCart(empty, 'quotecheck')
  const details = { id: 'safe-1', createdAt: TIMESTAMP }
  assert.throws(() => createDemoOrder(empty, CONTACT, details), /Cart is empty/)
  assert.throws(() => createDemoOrder(cart, { name: ' ', email: 'casey@example.com' }, details), /Name must be/)
  for (const email of [
    'bad@host',
    'casey..example@example.com',
    '.casey@example.com',
    'casey.@example.com',
    'casey\u0001@example.com',
    'casey@-example.com',
    'casey@example-.com'
  ]) {
    assert.throws(() => createDemoOrder(cart, { name: 'Casey', email }, details), /Email is invalid/)
  }
  assert.throws(() => createDemoOrder(cart, { name: 'x'.repeat(81), email: 'casey@example.com' }, details), /Name must be/)
  const maxNameOrder = createDemoOrder(cart, { name: 'x'.repeat(80), email: 'casey@example.com' }, {
    id: 'maximum-name',
    createdAt: TIMESTAMP
  })
  assert.equal(maxNameOrder.orders[0].name.length, 80)
  assert.throws(() => createDemoOrder(cart, CONTACT, { id: '../bad', createdAt: TIMESTAMP }), /Order id is invalid/)
  assert.throws(() => createDemoOrder(cart, CONTACT, { id: 'bad_id', createdAt: TIMESTAMP }), /Order id is invalid/)
  assert.throws(() => createDemoOrder(cart, CONTACT, { id: 'safe-1', createdAt: '2026-10-18' }), /Order date/)

  const first = createDemoOrder(cart, CONTACT, details)
  assert.throws(() => createDemoOrder(addToCart(first, 'exportcheck'), CONTACT, details), /already exists/)
})

test('state and order limits are enforced', () => {
  assert.throws(() => addToCart({ schema: 1, cart: ['quotecheck', 'exportcheck', 'handoffdesk', 'quotehandoffkit', 'quotecheck'], saved: [], orders: [] }, 'quotecheck'), /exceeds the allowed limit/)
  const fullHistory = stateWithOrders(100)
  assert.throws(() => createDemoOrder(addToCart(fullHistory, 'quotecheck'), CONTACT, {
    id: 'next-order',
    createdAt: TIMESTAMP
  }), /history is full/)
  assert.throws(() => parseBackup(JSON.stringify({ format: 'toolroom-backup', version: 1, state: stateWithOrders(101) })), /exceeds the allowed limit/)
  assert.throws(() => parseBackup(' '.repeat(1024 * 1024 + 1)), /1 MiB limit/)
})

test('backup round trip preserves canonical state and returns an independent copy', () => {
  const state = toggleSaved(orderState(), 'handoffdesk')
  const backup = exportBackup(state)
  const parsed = parseBackup(backup)
  assert.deepEqual(parsed, state)
  assert.deepEqual(parseBackup(exportBackup(parsed)), parsed)
  parsed.orders[0].items[0].title = 'Changed in restored copy'
  parsed.saved.push('quotehandoffkit')
  assert.equal(state.orders[0].items[0].title, 'QuoteCheck')
  assert.deepEqual(state.saved, ['handoffdesk'])
})

test('state transitions clone their input and nested order snapshots', () => {
  const before = orderState()
  const beforeJson = JSON.stringify(before)
  const after = addToCart(before, 'handoffdesk')
  after.orders[0].items[0].title = 'Local edit'
  after.saved.push('quotehandoffkit')
  assert.equal(JSON.stringify(before), beforeJson)

  const contact = { name: ' Casey ', email: 'casey@example.com ' }
  const details = { id: 'new-order', createdAt: TIMESTAMP }
  const input = addToCart(createState(), 'quotecheck')
  const inputJson = JSON.stringify(input)
  createDemoOrder(input, contact, details)
  assert.equal(JSON.stringify(input), inputJson)
  assert.deepEqual(contact, { name: ' Casey ', email: 'casey@example.com ' })
  assert.deepEqual(details, { id: 'new-order', createdAt: TIMESTAMP })
})

test('backup parser rejects unsupported formats, unknown fields, and invalid state shapes', () => {
  const valid = JSON.parse(exportBackup(createState()))
  assert.throws(() => parseBackup(JSON.stringify({ ...valid, version: 2 })), /unsupported/)
  assert.throws(() => parseBackup(JSON.stringify({ ...valid, extra: true })), /missing or unknown fields/)
  assert.throws(() => parseBackup(JSON.stringify({ ...valid, state: { ...valid.state, cart: ['quotecheck', 'quotecheck'] } })), /unique/)
  assert.throws(() => parseBackup(JSON.stringify({ ...valid, state: { ...valid.state, saved: ['unknown'] } })), /Unknown product id/)
  assert.throws(() => parseBackup(JSON.stringify({ ...valid, state: { ...valid.state, schema: 2 } })), /unsupported/)
})

test('backup parser checks order snapshots, totals, contact, dates, and duplicate order ids', () => {
  const valid = JSON.parse(exportBackup(orderState()))
  const badSnapshot = structuredClone(valid)
  badSnapshot.state.orders[0].items[0].priceCents = 1
  assert.throws(() => parseBackup(JSON.stringify(badSnapshot)), /snapshot/)

  const badTotal = structuredClone(valid)
  badTotal.state.orders[0].totalCents += 1
  assert.throws(() => parseBackup(JSON.stringify(badTotal)), /total is invalid/)

  const badMode = structuredClone(valid)
  badMode.state.orders[0].mode = 'paid'
  assert.throws(() => parseBackup(JSON.stringify(badMode)), /mode or currency/)

  const badContact = structuredClone(valid)
  badContact.state.orders[0].email = 'broken'
  assert.throws(() => parseBackup(JSON.stringify(badContact)), /Email is invalid/)

  const badDate = structuredClone(valid)
  badDate.state.orders[0].createdAt = 'yesterday'
  assert.throws(() => parseBackup(JSON.stringify(badDate)), /canonical UTC timestamp/)

  const duplicateId = structuredClone(valid)
  duplicateId.state.orders.push(structuredClone(duplicateId.state.orders[0]))
  assert.throws(() => parseBackup(JSON.stringify(duplicateId)), /Order ids must be unique/)
})

test('backup parser rejects dangerous keys recursively without polluting prototypes', () => {
  const payload = '{"format":"toolroom-backup","version":1,"state":{"schema":1,"cart":[],"saved":[],"orders":[],"note":{"__proto__":{"polluted":true}}}}'
  assert.throws(() => parseBackup(payload), /dangerous key/)
  assert.equal(Object.prototype.polluted, undefined)

  const constructorPayload = '{"format":"toolroom-backup","version":1,"state":{"schema":1,"cart":[],"saved":[],"orders":[{"constructor":{}}]}}'
  assert.throws(() => parseBackup(constructorPayload), /dangerous key/)
})
