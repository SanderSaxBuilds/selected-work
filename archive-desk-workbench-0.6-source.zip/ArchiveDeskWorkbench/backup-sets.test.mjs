import assert from "node:assert/strict"
import { createHash } from "node:crypto"
import { lstat, mkdir, mkdtemp, readFile, readdir, rename, symlink, writeFile } from "node:fs/promises"
import http from "node:http"
import os from "node:os"
import path from "node:path"
import test from "node:test"
import { createWorkbench } from "./server.mjs"

async function makeFixture() {
  const root = await mkdtemp(path.join(os.tmpdir(), "archive-desk-backup-sets-"))
  const workspace = path.join(root, "workspace")
  const storage = path.join(root, "storage")
  await mkdir(workspace)
  await mkdir(storage)
  return { root, workspace, storage }
}

async function putFile(root, relative, value) {
  const absolute = path.join(root, ...relative.split("/"))
  await mkdir(path.dirname(absolute), { recursive: true })
  await writeFile(absolute, value)
  return absolute
}

async function startApp(t, fixture) {
  const app = await createWorkbench({ workspace: fixture.workspace, storage: fixture.storage, port: 0 })
  let running = true
  t.after(async () => {
    if (!running) return
    running = false
    await app.close()
  })
  return {
    app,
    async close() {
      if (!running) return
      running = false
      await app.close()
    }
  }
}

function headers(app, extra = {}) {
  return {
    Origin: app.url,
    "Content-Type": "application/json",
    "X-Workbench": "1",
    ...extra
  }
}

async function post(app, route, value, extraHeaders = {}) {
  return fetch(app.url + route, {
    method: "POST",
    headers: headers(app, extraHeaders),
    body: JSON.stringify(value)
  })
}

async function responseJson(response) {
  const text = await response.text()
  try {
    return JSON.parse(text)
  } catch {
    assert.fail("Expected a JSON response, received: " + text.slice(0, 200))
  }
}

async function treeHashes(root) {
  const files = []
  const visit = async (directory, relativeDirectory = "") => {
    const entries = await readdir(directory, { withFileTypes: true })
    entries.sort((left, right) => left.name.localeCompare(right.name, "en"))
    for (const entry of entries) {
      const relative = relativeDirectory ? relativeDirectory + "/" + entry.name : entry.name
      const absolute = path.join(directory, entry.name)
      if (entry.isDirectory()) {
        await visit(absolute, relative)
      } else {
        const bytes = await readFile(absolute)
        files.push({ path: relative, bytes: bytes.byteLength, sha256: createHash("sha256").update(bytes).digest("hex") })
      }
    }
  }
  await visit(root)
  return files
}

async function storageSnapshot(root) {
  return JSON.stringify(await treeHashes(root))
}

async function rawRequest(app, route, { method = "GET", requestHeaders = {}, body = null } = {}) {
  const address = new URL(route, app.url)
  return new Promise((resolve, reject) => {
    const chunks = []
    const request = http.request({
      hostname: address.hostname,
      port: Number(address.port),
      path: address.pathname + address.search,
      method,
      headers: requestHeaders,
      agent: false
    }, response => {
      response.on("data", chunk => chunks.push(chunk))
      response.on("end", () => resolve({
        status: response.statusCode,
        headers: response.headers,
        body: Buffer.concat(chunks).toString("utf8")
      }))
    })
    request.once("error", reject)
    request.end(body)
  })
}

function oneSource(label, source = "project") {
  return { label, sources: [{ source, label: "Project source" }] }
}

test("saved sets create, edit and survive restart while state.json stays byte-identical", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "project/one.txt", "one\n")
  const first = await startApp(t, fixture)
  const stateFile = path.join(fixture.storage, "state.json")
  const stateBefore = await readFile(stateFile)

  const createdResponse = await post(first.app, "/api/sets", {
    label: "  Client handoff  ",
    sources: [{ source: "project", label: "  Source A  " }]
  })
  assert.equal(createdResponse.status, 201)
  const created = (await responseJson(createdResponse)).set
  assert.match(created.id, /^[a-f0-9]{24}$/u)
  assert.equal(created.label, "Client handoff")
  assert.equal(created.sources[0].label, "Source A")
  assert.deepEqual(Object.keys(created).sort(), ["createdAt", "id", "label", "sources", "updatedAt"])
  assert.deepEqual(await readFile(stateFile), stateBefore)

  const editedResponse = await post(first.app, "/api/sets/" + created.id, {
    label: "Release package",
    sources: [{ source: "project", label: "Final source" }]
  })
  assert.equal(editedResponse.status, 200)
  const edited = (await responseJson(editedResponse)).set
  assert.equal(edited.createdAt, created.createdAt)
  assert.ok(Date.parse(edited.updatedAt) > Date.parse(created.updatedAt))
  assert.equal(edited.label, "Release package")
  assert.deepEqual(await readFile(stateFile), stateBefore)

  const library = await responseJson(await fetch(first.app.url + "/api/state"))
  assert.equal(library.version, "0.6.0-candidate.1")
  assert.equal(library.backups.length, 0)
  assert.deepEqual(Object.keys(JSON.parse(await readFile(stateFile, "utf8"))).sort(), ["activity", "backups", "format", "version"])

  await first.close()
  const restarted = await startApp(t, fixture)
  const listing = await responseJson(await fetch(restarted.app.url + "/api/sets"))
  assert.deepEqual(Object.keys(listing).sort(), ["format", "limits", "sets", "version"])
  assert.equal(listing.format, "archive-desk-backup-sets")
  assert.equal(listing.version, 1)
  assert.deepEqual(listing.limits, { maxSets: 12, maxSources: 8 })
  assert.deepEqual(listing.sets, [edited])
  assert.deepEqual(await readFile(stateFile), stateBefore)

  await restarted.close()
  const missingStore = path.join(fixture.storage, "backup-sets.json")
  const retainedStore = path.join(fixture.storage, "backup-sets.saved.json")
  await rename(missingStore, retainedStore)
  await assert.rejects(
    createWorkbench({ workspace: fixture.workspace, storage: fixture.storage, port: 0 }),
    /missing\. It was not reset/u
  )
  await lstat(retainedStore)
})

test("set validation rejects unknown fields, normalized duplicates, overlaps and capacity overflow", async t => {
  const fixture = await makeFixture()
  const { app } = await startApp(t, fixture)

  const unknown = await post(app, "/api/sets", { ...oneSource("Unknown"), extra: true })
  assert.equal(unknown.status, 400)
  assert.match((await responseJson(unknown)).error, /unsupported field/u)

  const unknownSource = await post(app, "/api/sets", {
    label: "Unknown source field",
    sources: [{ source: "project", label: "One", extra: true }]
  })
  assert.equal(unknownSource.status, 400)

  const duplicate = await post(app, "/api/sets", {
    label: "Duplicate",
    sources: [{ source: "Projects/Current", label: "A" }, { source: "projects/current", label: "B" }]
  })
  assert.equal(duplicate.status, 400)
  assert.match((await responseJson(duplicate)).error, /repeat or overlap/u)

  const unicodeDuplicate = await post(app, "/api/sets", {
    label: "Unicode duplicate",
    sources: [{ source: "caf\u00e9", label: "A" }, { source: "cafe\u0301", label: "B" }]
  })
  assert.equal(unicodeDuplicate.status, 400)

  const overlap = await post(app, "/api/sets", {
    label: "Overlap",
    sources: [{ source: "parent", label: "A" }, { source: "PARENT/child", label: "B" }]
  })
  assert.equal(overlap.status, 400)

  const emptySources = await post(app, "/api/sets", { label: "No sources", sources: [] })
  assert.equal(emptySources.status, 400)
  const tooManySources = await post(app, "/api/sets", {
    label: "Too many",
    sources: Array.from({ length: 9 }, (_, index) => ({ source: "folder-" + index, label: "Folder " + index }))
  })
  assert.equal(tooManySources.status, 400)

  for (let index = 0; index < 12; index += 1) {
    const saved = await post(app, "/api/sets", oneSource("Set " + index, "folder-" + index))
    assert.equal(saved.status, 201)
  }
  const overflow = await post(app, "/api/sets", oneSource("Thirteenth", "folder-13"))
  assert.equal(overflow.status, 409)
  assert.match((await responseJson(overflow)).error, /limit of 12/u)
  assert.equal((await responseJson(await fetch(app.url + "/api/sets"))).sets.length, 12)
})

test("startup refuses corrupt or link-based saved set files instead of resetting them", async t => {
  const corruptFixture = await makeFixture()
  const corruptPath = path.join(corruptFixture.storage, "backup-sets.json")
  const corruptBytes = Buffer.from('{"format":"unknown","version":7,"sets":[]}\n')
  await writeFile(corruptPath, corruptBytes)
  await assert.rejects(
    createWorkbench({ workspace: corruptFixture.workspace, storage: corruptFixture.storage, port: 0 }),
    /format is not recognized/u
  )
  assert.deepEqual(await readFile(corruptPath), corruptBytes)

  const linkFixture = await makeFixture()
  const target = path.join(linkFixture.root, "saved-sets.json")
  const link = path.join(linkFixture.storage, "backup-sets.json")
  await writeFile(target, JSON.stringify({ format: "archive-desk-backup-sets", version: 1, sets: [] }))
  try {
    await symlink(target, link, "file")
  } catch (error) {
    if (["EPERM", "EACCES", "UNKNOWN"].includes(error && error.code)) {
      t.diagnostic("File symlinks were unavailable, checking a linked saved-set path with a junction.")
      const targetDirectory = path.join(linkFixture.root, "saved-sets-directory")
      await mkdir(targetDirectory)
      try {
        await symlink(targetDirectory, link, "junction")
      } catch (junctionError) {
        if (["EPERM", "EACCES", "UNKNOWN"].includes(junctionError && junctionError.code)) {
          t.diagnostic("This Windows environment did not permit creating the saved-set junction.")
          return
        }
        throw junctionError
      }
    } else {
      throw error
    }
  }
  await assert.rejects(
    createWorkbench({ workspace: linkFixture.workspace, storage: linkFixture.storage, port: 0 }),
    /not a supported regular file/u
  )
  assert.equal((await lstat(link)).isSymbolicLink(), true)
})

test("preview is byte-read-only and reports ready, missing and empty sources independently", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "ready/visible.txt", "synthetic visible bytes\n")
  await putFile(fixture.workspace, "ready/.env", "synthetic skipped bytes\n")
  await mkdir(path.join(fixture.workspace, "empty"))
  const { app } = await startApp(t, fixture)
  const setResponse = await post(app, "/api/sets", {
    label: "Partial set",
    sources: [
      { source: "ready", label: "Ready source" },
      { source: "missing", label: "Missing source" },
      { source: "empty", label: "Empty source" }
    ]
  })
  assert.equal(setResponse.status, 201)
  const set = (await responseJson(setResponse)).set
  const storageBefore = await storageSnapshot(fixture.storage)
  const stateBefore = await readFile(path.join(fixture.storage, "state.json"))
  const setsBefore = await readFile(path.join(fixture.storage, "backup-sets.json"))

  const previewResponse = await post(app, "/api/sets/" + set.id + "/preview", {})
  assert.equal(previewResponse.status, 200)
  const preview = await responseJson(previewResponse)
  assert.equal(preview.format, "archive-desk-backup-set-plan")
  assert.equal(preview.version, 1)
  assert.match(preview.planId, /^[a-f0-9]{24}$/u)
  assert.equal(Date.parse(preview.expiresAt) - Date.parse(preview.plannedAt), 600000)
  assert.deepEqual(preview.counts, { sources: 3, ready: 1, failed: 2, files: 1, totalBytes: Buffer.byteLength("synthetic visible bytes\n") })
  assert.deepEqual(preview.results.map(result => result.status), ["ready", "failed", "failed"])
  assert.equal(preview.results[0].files[0].path, "visible.txt")
  assert.match(preview.results[0].files[0].sha256, /^[a-f0-9]{64}$/u)
  assert.deepEqual(preview.results[0].skippedPaths.map(item => item.path), [".env"])
  const downloadedPlan = JSON.stringify(preview)
  assert.equal(downloadedPlan.includes(fixture.workspace), false)
  assert.equal(downloadedPlan.includes(fixture.storage), false)
  assert.deepEqual(await readFile(path.join(fixture.storage, "state.json")), stateBefore)
  assert.deepEqual(await readFile(path.join(fixture.storage, "backup-sets.json")), setsBefore)
  assert.equal(await storageSnapshot(fixture.storage), storageBefore)

  const runResponse = await post(app, "/api/sets/" + set.id + "/run", { planId: preview.planId })
  assert.equal(runResponse.status, 200)
  const run = await responseJson(runResponse)
  assert.deepEqual(run.counts, { sources: 3, created: 1, failed: 0, skipped: 2 })
  assert.deepEqual(run.results.map(result => result.status), ["created", "skipped", "skipped"])
  assert.equal(Object.hasOwn(run.results[0].backup, "storagePath"), false)
  assert.equal(JSON.stringify(run).includes(fixture.workspace), false)
  assert.equal(JSON.stringify(run).includes(fixture.storage), false)
})

test("same-length content changes after preview are rejected before any archive is written", async t => {
  const fixture = await makeFixture()
  const sourceFile = await putFile(fixture.workspace, "project/value.txt", "before\n")
  const { app } = await startApp(t, fixture)
  const created = await responseJson(await post(app, "/api/sets", oneSource("Changed source")))
  const preview = await responseJson(await post(app, "/api/sets/" + created.set.id + "/preview", {}))
  await writeFile(sourceFile, "after!\n")
  const runResponse = await post(app, "/api/sets/" + created.set.id + "/run", { planId: preview.planId })
  assert.equal(runResponse.status, 200)
  const run = await responseJson(runResponse)
  assert.deepEqual(run.counts, { sources: 1, created: 0, failed: 1, skipped: 0 })
  assert.match(run.results[0].error, /inventory changed after preview/u)
  assert.deepEqual(await readdir(path.join(fixture.storage, "archives")), [])
  assert.deepEqual((await responseJson(await fetch(app.url + "/api/state"))).backups, [])
})

test("a source changed to a junction after preview is rejected", async t => {
  const fixture = await makeFixture()
  const linkedSource = path.join(fixture.workspace, "project")
  const savedSource = path.join(fixture.workspace, "project-saved")
  const outside = path.join(fixture.root, "outside")
  await putFile(linkedSource, "value.txt", "inside\n")
  await putFile(outside, "value.txt", "outside\n")
  const { app } = await startApp(t, fixture)
  const created = await responseJson(await post(app, "/api/sets", oneSource("Linked source")))
  const preview = await responseJson(await post(app, "/api/sets/" + created.set.id + "/preview", {}))
  await rename(linkedSource, savedSource)
  try {
    await symlink(outside, linkedSource, "junction")
  } catch (error) {
    if (["EPERM", "EACCES", "UNKNOWN"].includes(error && error.code)) {
      t.skip("This Windows environment did not permit creating a test junction.")
      return
    }
    throw error
  }
  const run = await responseJson(await post(app, "/api/sets/" + created.set.id + "/run", { planId: preview.planId }))
  assert.equal(run.results[0].status, "failed")
  assert.match(run.results[0].error, /symbolic link or junction/u)
  assert.deepEqual(await readdir(path.join(fixture.storage, "archives")), [])
})

test("stale set revisions and replayed plans are refused", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "project/value.txt", "synthetic\n")
  const { app } = await startApp(t, fixture)
  const created = await responseJson(await post(app, "/api/sets", oneSource("Revision one")))
  const firstPlan = await responseJson(await post(app, "/api/sets/" + created.set.id + "/preview", {}))
  const editResponse = await post(app, "/api/sets/" + created.set.id, {
    label: "Revision two",
    sources: [{ source: "project", label: "Renamed source" }]
  })
  assert.equal(editResponse.status, 200)
  const stale = await post(app, "/api/sets/" + created.set.id + "/run", { planId: firstPlan.planId })
  assert.equal(stale.status, 409)
  assert.match((await responseJson(stale)).error, /changed after preview/u)
  assert.deepEqual(await readdir(path.join(fixture.storage, "archives")), [])

  const freshPlan = await responseJson(await post(app, "/api/sets/" + created.set.id + "/preview", {}))
  const successful = await post(app, "/api/sets/" + created.set.id + "/run", { planId: freshPlan.planId })
  assert.equal(successful.status, 200)
  assert.equal((await responseJson(successful)).counts.created, 1)
  const replay = await post(app, "/api/sets/" + created.set.id + "/run", { planId: freshPlan.planId })
  assert.equal(replay.status, 409)
  assert.match((await responseJson(replay)).error, /unknown or expired/u)
  assert.equal((await responseJson(await fetch(app.url + "/api/state"))).backups.length, 1)
})

test("emoji set labels stay within the library limit and survive restart", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "project/value.txt", "synthetic\n")
  const first = await startApp(t, fixture)
  const setLabel = "🧪".repeat(20)
  const sourceLabel = "📦".repeat(20)
  const createdResponse = await post(first.app, "/api/sets", {
    label: setLabel,
    sources: [{ source: "project", label: sourceLabel }]
  })
  assert.equal(createdResponse.status, 201)
  const set = (await responseJson(createdResponse)).set
  const plan = await responseJson(await post(first.app, "/api/sets/" + set.id + "/preview", {}))
  const run = await responseJson(await post(first.app, "/api/sets/" + set.id + "/run", { planId: plan.planId }))
  assert.equal(run.counts.created, 1)
  const backupLabel = run.results[0].backup.label
  assert.ok(backupLabel.length <= 80)
  assert.equal(Array.from(backupLabel).some(character => {
    const codePoint = character.codePointAt(0)
    return codePoint >= 0xd800 && codePoint <= 0xdfff
  }), false)

  await first.close()
  const restarted = await startApp(t, fixture)
  const state = await responseJson(await fetch(restarted.app.url + "/api/state"))
  assert.equal(state.backups.length, 1)
  assert.equal(state.backups[0].label, backupLabel)
})

test("multiple set archives pass existing verification and restore operations", async t => {
  const fixture = await makeFixture()
  const firstBytes = Buffer.from("first synthetic source\n")
  const secondBytes = Buffer.from([0, 1, 2, 255, 10])
  await putFile(fixture.workspace, "first/nested/one.txt", firstBytes)
  await putFile(fixture.workspace, "second/two.bin", secondBytes)
  const { app } = await startApp(t, fixture)
  const setResponse = await post(app, "/api/sets", {
    label: "Two projects",
    sources: [
      { source: "first", label: "First" },
      { source: "second", label: "Second" }
    ]
  })
  assert.equal(setResponse.status, 201)
  const set = (await responseJson(setResponse)).set
  const plan = await responseJson(await post(app, "/api/sets/" + set.id + "/preview", {}))
  assert.equal(plan.counts.ready, 2)
  const runResponse = await post(app, "/api/sets/" + set.id + "/run", { planId: plan.planId })
  assert.equal(runResponse.status, 200)
  const run = await responseJson(runResponse)
  assert.deepEqual(run.counts, { sources: 2, created: 2, failed: 0, skipped: 0 })

  const expectedBySource = new Map([
    ["first", [{ path: "nested/one.txt", bytes: firstBytes.byteLength, sha256: createHash("sha256").update(firstBytes).digest("hex") }]],
    ["second", [{ path: "two.bin", bytes: secondBytes.byteLength, sha256: createHash("sha256").update(secondBytes).digest("hex") }]]
  ])
  for (const [index, result] of run.results.entries()) {
    assert.equal(result.status, "created")
    assert.match(result.backup.id, /^[a-f0-9]{24}$/u)
    assert.match(result.backup.label, /^Two projects - /u)
    const verification = await responseJson(await fetch(app.url + "/api/backups/" + result.backup.id + "/verification"))
    assert.equal(verification.format, "archive-desk-verification")
    assert.deepEqual(verification.files, expectedBySource.get(result.source))
    const restored = await responseJson(await post(app, "/api/backups/" + result.backup.id + "/restore", { name: "set-restore-" + (index + 1) }))
    assert.equal(restored.verified, true)
    assert.deepEqual(await treeHashes(restored.destination), expectedBySource.get(result.source))
  }
  const state = await responseJson(await fetch(app.url + "/api/state"))
  assert.equal(state.backups.length, 2)
  assert.equal(state.backups.every(backup => backup.origin === "workspace"), true)
  assert.equal(state.activity.filter(item => item.title === "Backup set source created").length, 2)
})

test("set writes retain loopback, Origin, marker and shared busy controls", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "project/value.txt", "synthetic\n")
  const { app } = await startApp(t, fixture)
  const body = Buffer.from(JSON.stringify(oneSource("Serialized set")))

  const badHost = await rawRequest(app, "/api/sets", { requestHeaders: { Host: "localhost:4330" } })
  assert.equal(badHost.status, 421)

  const missingOrigin = await rawRequest(app, "/api/sets", {
    method: "POST",
    requestHeaders: { Host: new URL(app.url).host, "Content-Type": "application/json", "X-Workbench": "1", "Content-Length": body.byteLength },
    body
  })
  assert.equal(missingOrigin.status, 403)

  const missingMarker = await post(app, "/api/sets", oneSource("Missing marker"), { "X-Workbench": "0" })
  assert.equal(missingMarker.status, 403)

  const slowPost = new Promise((resolve, reject) => {
    const request = http.request(new URL("/api/sets", app.url), {
      method: "POST",
      headers: {
        Host: new URL(app.url).host,
        Origin: app.url,
        "Content-Type": "application/json",
        "X-Workbench": "1",
        "Content-Length": body.byteLength
      }
    }, response => {
      const chunks = []
      response.on("data", chunk => chunks.push(chunk))
      response.on("end", () => resolve({ status: response.statusCode, body: Buffer.concat(chunks).toString("utf8") }))
    })
    request.once("error", reject)
    request.write(body.subarray(0, 5))
    setTimeout(() => request.end(body.subarray(5)), 80)
  })
  await new Promise(resolve => setTimeout(resolve, 20))
  const busy = await post(app, "/api/backups", { source: "project", label: "Concurrent backup" })
  assert.equal(busy.status, 409)
  const completed = await slowPost
  assert.equal(completed.status, 201, completed.body)
  assert.equal((await responseJson(await fetch(app.url + "/api/state"))).busy, false)
})
