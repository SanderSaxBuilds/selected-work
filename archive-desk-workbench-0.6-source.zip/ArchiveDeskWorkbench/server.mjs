import { createServer } from "node:http"
import { spawn } from "node:child_process"
import { createHash, randomBytes } from "node:crypto"
import { lstat, mkdir, readFile, rename, writeFile } from "node:fs/promises"
import path from "node:path"
import { fileURLToPath, pathToFileURL } from "node:url"
import {
  assertDirectoryTree,
  assertNewDirectory,
  assertWorkspaceSource,
  createDirectoryExclusive,
  isInsideOrSame,
  LIMITS,
  readRegularFile,
  scanWorkspace,
  validateRelativeDirectory,
  WorkspaceError
} from "./lib/workspace.mjs"
import {
  BACKUP_SET_LIMITS,
  defaultBackupSets,
  makeBackupSetId,
  normalizeBackupSetInput,
  persistBackupSetsMarker,
  persistBackupSetsFile,
  publicBackupSet,
  readBackupSetsMarker,
  readBackupSetsFile,
  validateBackupSetsState
} from "./lib/backup-sets.mjs"
import {
  listRunHistory,
  persistRunHistory,
  readRunHistory,
  RUN_HISTORY_LIMITATIONS
} from "./lib/run-history.mjs"
import { verifyArchive } from "./vendor/lib/core.mjs"

const APP_ROOT = path.dirname(fileURLToPath(import.meta.url))
const PUBLIC_ROOT = path.join(APP_ROOT, "public")
const CLI_PATH = path.join(APP_ROOT, "vendor", "cli.mjs")
const ID_PATTERN = /^[a-f0-9]{24}$/u
const HASH_PATTERN = /^[a-f0-9]{64}$/u
const STATE_FORMAT = "archive-desk-workbench"
const STATE_VERSION = 1
const VERSION = "0.6.0-candidate.1"
const MAX_BODY_BYTES = 16 * 1024
const MAX_STATE_BYTES = 10 * 1024 * 1024
const MAX_ACTIVITY = 100
const MAX_CLI_OUTPUT_BYTES = 2 * 1024 * 1024
const CLI_TIMEOUT_MS = 180_000
const EXCLUSION_NOTICE = "Filename exclusions catch common patterns only. They are not secret detection."
const RESTORE_PLAN_LIMITATIONS = Object.freeze([
  "This plan is a read-only snapshot, not an atomic authorization or security token.",
  "A restore request must independently recheck the saved archive and destination before writing."
])
const VERIFICATION_LIMITATIONS = Object.freeze([
  "This report covers the saved archive and its manifest, not a live workspace comparison or recovery destination."
])
const LIBRARY_CHECK_LIMITS = Object.freeze([
  "Each readable archive is checked sequentially, so a large library may take time to finish.",
  "Missing or unsafe archive files cannot be passed to the CLI verifier and are reported as failed.",
  "Results describe the check time. Hashes check consistency, not authenticity, and do not prevent later changes."
])
const BACKUP_SET_PLAN_TTL_MS = 10 * 60 * 1000
const BACKUP_SET_PLAN_CACHE_SIZE = 8
const BACKUP_SET_PLAN_LIMITATIONS = Object.freeze([
  "This plan is a read-only snapshot that expires after ten minutes. It is not an atomic authorization or security token.",
  "Ready sources are rescanned and their file hashes are rechecked before archives are written, then the archive contents are compared with the plan.",
  "These checks do not provide an adversarial race guarantee. Files may change after a check, and hashes show byte consistency rather than authenticity.",
  "Loopback and request-marker checks help reject cross-site requests but do not establish a trusted origin."
])
const STATIC_FILES = new Map([
  ["/app.mjs", ["app.mjs", "text/javascript; charset=utf-8"]],
  ["/sets.mjs", ["sets.mjs", "text/javascript; charset=utf-8"]],
  ["/history.mjs", ["history.mjs", "text/javascript; charset=utf-8"]],
  ["/history.css", ["history.css", "text/css; charset=utf-8"]],
  ["/styles.css", ["styles.css", "text/css; charset=utf-8"]],
  ["/mark.svg", ["mark.svg", "image/svg+xml"]]
])
const SECURITY_HEADERS = Object.freeze({
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
})

class HttpError extends Error {
  constructor(status, message) {
    super(message)
    this.name = "HttpError"
    this.status = status
  }
}

function fail(status, message) {
  throw new HttpError(status, message)
}

function randomId() {
  return randomBytes(12).toString("hex")
}

function isoNow() {
  return new Date().toISOString()
}

function isRecord(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return false
  const prototype = Object.getPrototypeOf(value)
  return prototype === Object.prototype || prototype === null
}

function exactKeys(value, allowed, label) {
  if (!isRecord(value)) fail(400, label + " must be a JSON object.")
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) fail(400, label + " contains an unsupported field.")
  }
}

function validIso(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/u.test(value)) return false
  const date = new Date(value)
  return Number.isFinite(date.getTime()) && date.toISOString() === value
}

function normalizeLabel(value, fallback = "Project backup") {
  if (value === undefined) return fallback
  if (typeof value !== "string") fail(400, "Backup label must be text.")
  const label = value.trim()
  if (!label || label.length > 80 || /[\u0000-\u001f\u007f-\u009f]/u.test(label)) {
    fail(400, "Backup label must contain 1 to 80 printable characters.")
  }
  return label
}

function validateId(value) {
  if (typeof value !== "string" || !ID_PATTERN.test(value)) fail(400, "Backup ID is invalid.")
  return value
}

function validateRestoreName(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,59}$/u.test(value)) {
    fail(400, "Use a recovery folder name with letters, numbers, hyphens or underscores.")
  }
  return value
}

function makeActivity(title, detail, status = "pass") {
  return { id: randomId(), at: isoNow(), title, detail, status }
}

function publicBackup(record) {
  return {
    id: record.id,
    label: record.label,
    source: record.source,
    createdAt: record.createdAt,
    files: record.files,
    totalBytes: record.totalBytes,
    archiveBytes: record.archiveBytes,
    sha256: record.sha256,
    verifiedAt: record.verifiedAt,
    demo: record.demo,
    origin: record.origin ?? (record.demo ? "demo" : "workspace")
  }
}

function isValidRecord(record) {
  if (!isRecord(record)) return false
  const allowed = new Set(["id", "label", "source", "createdAt", "files", "totalBytes", "archiveBytes", "sha256", "verifiedAt", "demo", "reportIds", "origin"])
  if (Object.keys(record).some(key => !allowed.has(key))) return false
  if (!ID_PATTERN.test(record.id) || typeof record.demo !== "boolean") return false
  if (Object.hasOwn(record, "origin") && !["workspace", "import", "demo"].includes(record.origin)) return false
  if (typeof record.label !== "string" || record.label.length < 1 || record.label.length > 80 || /[\u0000-\u001f\u007f-\u009f]/u.test(record.label)) return false
  if (record.demo) {
    if (record.source !== "demo:" + record.id) return false
    if (record.origin !== undefined && record.origin !== "demo") return false
  } else {
    try {
      if (validateRelativeDirectory(record.source) !== record.source) return false
    } catch {
      return false
    }
    if (record.origin === "demo") return false
    if (record.origin === "import" && record.source !== ".") return false
  }
  if (!validIso(record.createdAt) || !validIso(record.verifiedAt)) return false
  if (!Number.isSafeInteger(record.files) || record.files < 1 || record.files > LIMITS.maxFiles) return false
  if (!Number.isSafeInteger(record.totalBytes) || record.totalBytes < 0 || record.totalBytes > LIMITS.maxTotalBytes) return false
  if (!Number.isSafeInteger(record.archiveBytes) || record.archiveBytes < 1 || record.archiveBytes > LIMITS.maxArchiveBytes) return false
  if (typeof record.sha256 !== "string" || !HASH_PATTERN.test(record.sha256)) return false
  if (!Array.isArray(record.reportIds) || record.reportIds.some(id => typeof id !== "string" || !ID_PATTERN.test(id))) return false
  if (new Set(record.reportIds).size !== record.reportIds.length) return false
  return true
}

function isValidActivity(item) {
  if (!isRecord(item)) return false
  const allowed = new Set(["id", "at", "title", "detail", "status"])
  if (Object.keys(item).some(key => !allowed.has(key))) return false
  return ID_PATTERN.test(item.id)
    && validIso(item.at)
    && typeof item.title === "string"
    && item.title.length > 0
    && item.title.length <= 120
    && typeof item.detail === "string"
    && item.detail.length <= 300
    && (item.status === "pass" || item.status === "notice")
}

function defaultState() {
  return { format: STATE_FORMAT, version: STATE_VERSION, backups: [], activity: [] }
}

async function statePathIsNew(filename) {
  try {
    await lstat(filename)
    return false
  } catch (error) {
    if (error && error.code === "ENOENT") return true
    throw error
  }
}

async function readStateFile(filename) {
  let stat
  try {
    stat = await lstat(filename)
  } catch (error) {
    if (error && error.code === "ENOENT") return defaultState()
    fail(500, "The saved backup library could not be inspected safely.")
  }
  if (stat.isSymbolicLink() || !stat.isFile() || stat.size > MAX_STATE_BYTES) {
    fail(500, "The saved backup library is not a supported regular file.")
  }
  let bytes
  try {
    bytes = await readFile(filename)
  } catch {
    fail(500, "The saved backup library could not be read.")
  }
  let parsed
  try {
    parsed = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes))
  } catch {
    fail(500, "The saved backup library is not valid UTF-8 JSON.")
  }
  if (!isRecord(parsed) || parsed.format !== STATE_FORMAT || parsed.version !== STATE_VERSION || !Array.isArray(parsed.backups) || !Array.isArray(parsed.activity)) {
    fail(500, "The saved backup library format is not recognized.")
  }
  const backupIds = new Set()
  for (const record of parsed.backups) {
    if (!isValidRecord(record) || backupIds.has(record.id)) {
      fail(500, "The saved backup library contains an invalid record.")
    }
    backupIds.add(record.id)
  }
  if (parsed.activity.length > MAX_ACTIVITY || parsed.activity.some(item => !isValidActivity(item))) {
    fail(500, "The saved activity list contains an invalid record.")
  }
  return parsed
}

async function persistState(filename, state) {
  const bytes = Buffer.from(JSON.stringify(state, null, 2) + "\n", "utf8")
  if (bytes.byteLength > MAX_STATE_BYTES) fail(500, "The backup library reached its supported size limit.")
  let temporary
  let created = false
  for (let attempt = 0; attempt < 5; attempt += 1) {
    temporary = filename + "." + randomId() + ".tmp"
    try {
      await writeFile(temporary, bytes, { flag: "wx" })
      created = true
      break
    } catch (error) {
      if (error && error.code === "EEXIST") continue
      fail(500, "The backup library could not be saved.")
    }
  }
  if (!created) fail(500, "The backup library could not be saved.")
  try {
    await rename(temporary, filename)
  } catch {
    fail(500, "The backup library could not be updated. The previous library was preserved.")
  }
}

function addActivity(state, title, detail, status = "pass") {
  state.activity.unshift(makeActivity(title, detail, status))
  state.activity = state.activity.slice(0, MAX_ACTIVITY)
}

async function persistMutation(state, filename, update) {
  const previous = structuredClone(state)
  try {
    update()
    await persistState(filename, state)
  } catch (error) {
    state.format = previous.format
    state.version = previous.version
    state.backups = previous.backups
    state.activity = previous.activity
    throw error
  }
}

function archivePath(storage, id) {
  return path.join(storage, "archives", id + ".zip")
}

function reportPath(storage, backupId, reportId) {
  return path.join(storage, "reports", backupId + "-" + reportId + ".json")
}

function currentSourcePath(workspace, storage, record, suppliedSource) {
  if (record.demo) {
    const labPath = path.join(storage, "labs", record.id)
    return path.join(labPath, "current")
  }
  return suppliedSource.absolute
}

function minimalChildEnv() {
  if (process.platform !== "win32") return {}
  const systemRoot = process.env.SystemRoot || process.env.SYSTEMROOT
  return systemRoot ? { SystemRoot: systemRoot } : {}
}

function runCli(args, failureMessage, partialOutput = null) {
  return new Promise((resolve, reject) => {
    let child
    try {
      child = spawn(process.execPath, [CLI_PATH, ...args], {
        cwd: APP_ROOT,
        env: minimalChildEnv(),
        shell: false,
        windowsHide: true,
        stdio: ["ignore", "pipe", "pipe"]
      })
    } catch {
      reject(new HttpError(500, "The local archive operation could not be started."))
      return
    }
    let outputBytes = 0
    let timedOut = false
    let outputTooLarge = false
    const timer = setTimeout(() => {
      timedOut = true
      child.kill()
    }, CLI_TIMEOUT_MS)
    const consume = chunk => {
      outputBytes += chunk.byteLength
      if (outputBytes > MAX_CLI_OUTPUT_BYTES && !outputTooLarge) {
        outputTooLarge = true
        child.kill()
      }
    }
    child.stdout.on("data", consume)
    child.stderr.on("data", consume)
    child.once("error", () => {
      clearTimeout(timer)
      reject(new HttpError(500, "The local archive operation could not be started."))
    })
    child.once("close", async code => {
      clearTimeout(timer)
      let partialDetail = ""
      if (partialOutput) {
        try {
          const outputStat = await lstat(partialOutput)
          if (outputStat.isDirectory() || outputStat.isFile()) {
            partialDetail = " A new recovery folder may be partial at " + JSON.stringify(partialOutput) + ". Review it before trying again."
          }
        } catch {
          partialDetail = ""
        }
      }
      if (timedOut) {
        reject(new HttpError(504, "The local archive operation took too long." + partialDetail))
      } else if (outputTooLarge) {
        reject(new HttpError(502, "The local archive operation returned more output than expected." + partialDetail))
      } else if (code !== 0) {
        reject(new HttpError(422, failureMessage + partialDetail))
      } else {
        resolve()
      }
    })
  })
}

async function hashArchive(bytes) {
  return createHash("sha256").update(bytes).digest("hex")
}

async function readVerifiedArchive(storage, record) {
  validateId(record.id)
  const bytes = await readRegularFile(archivePath(storage, record.id), LIMITS.maxArchiveBytes)
  const sha256 = await hashArchive(bytes)
  if (sha256 !== record.sha256 || bytes.byteLength !== record.archiveBytes) {
    fail(409, "Saved archive bytes no longer match the backup library record.")
  }
  let verified
  try {
    verified = await verifyArchive(bytes)
  } catch {
    fail(422, "The saved archive failed its integrity check.")
  }
  const files = verified.files.map(file => ({ path: file.path, bytes: file.bytes, sha256: file.sha256 }))
  const counts = { files: files.length, totalBytes: files.reduce((sum, file) => sum + file.bytes, 0) }
  return { bytes, verified: { counts, files }, sha256 }
}

async function checkLibraryRecord(storage, record) {
  let archiveSha256 = null
  let files = null
  let totalBytes = null
  let error = null
  try {
    validateId(record.id)
    const archiveFilename = archivePath(storage, record.id)
    const bytes = await readRegularFile(archiveFilename, LIMITS.maxArchiveBytes)
    archiveSha256 = await hashArchive(bytes)
    try {
      await runCli(["verify", archiveFilename], "Saved archive failed its full verification.")
    } catch {
      error = "Saved archive failed its full verification."
    }
    let verified
    if (error === null) {
      try {
        verified = await verifyArchive(bytes)
      } catch {
        error = "Saved archive failed its full verification."
      }
    }
    if (verified) {
      files = verified.files.length
      totalBytes = verified.files.reduce((sum, file) => sum + file.bytes, 0)
      if (archiveSha256 !== record.sha256 || bytes.byteLength !== record.archiveBytes) {
        error = "Archive bytes do not match the saved library record."
      } else if (files !== record.files || totalBytes !== record.totalBytes) {
        error = "Verified contents do not match the saved library record."
      }
    }
  } catch {
    error = "Saved archive could not be read and checked safely."
  }
  return {
    id: record.id,
    label: record.label,
    status: error === null ? "passed" : "failed",
    recordedArchiveSha256: record.sha256,
    archiveSha256,
    files,
    totalBytes,
    error
  }
}

async function readReport(storage, record) {
  if (!record.reportIds.length) fail(404, "No comparison report is saved for this backup yet.")
  const reportId = record.reportIds[record.reportIds.length - 1]
  if (!ID_PATTERN.test(reportId)) fail(404, "No comparison report is saved for this backup yet.")
  const bytes = await readRegularFile(reportPath(storage, record.id, reportId), 1024 * 1024)
  let report
  try {
    report = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes))
  } catch {
    fail(409, "The saved comparison report could not be read.")
  }
  if (!isRecord(report)
    || report.format !== "archive-desk-compare"
    || report.version !== 1
    || report.baselineArchiveSha256 !== record.sha256
    || !isRecord(report.counts)
    || !Array.isArray(report.rows)) {
    fail(409, "The saved comparison report failed its integrity check.")
  }
  return { bytes, report }
}

async function createArchive(storage, sourceAbsolute, id) {
  validateId(id)
  const output = archivePath(storage, id)
  await runCli(["backup", sourceAbsolute, "--out", output], "Backup could not be created. Check the selected folder and supported file limits.")
  const bytes = await readRegularFile(output, LIMITS.maxArchiveBytes)
  let verified
  try {
    verified = await verifyArchive(bytes)
  } catch {
    fail(422, "The new archive failed its readback integrity check.")
  }
  const totalBytes = verified.files.reduce((sum, file) => sum + file.bytes, 0)
  const createdAt = verified.manifest.createdAt
  return {
    id,
    createdAt,
    verifiedAt: isoNow(),
    files: verified.files.length,
    totalBytes,
    archiveBytes: bytes.byteLength,
    sha256: await hashArchive(bytes),
    verified
  }
}

function createRecord({ id, label, source, demo, archive }) {
  return {
    id,
    label,
    source,
    createdAt: archive.createdAt,
    files: archive.files,
    totalBytes: archive.totalBytes,
    archiveBytes: archive.archiveBytes,
    sha256: archive.sha256,
    verifiedAt: archive.verifiedAt,
    demo,
    reportIds: []
  }
}

function addRecord(state, record) {
  state.backups.unshift(record)
}

function sourcePreviewPayload(source, scan) {
  return {
    source,
    files: scan.files,
    skippedPaths: scan.skippedPaths,
    totalBytes: scan.totalBytes,
    count: scan.count,
    notice: EXCLUSION_NOTICE
  }
}

function sourceScansMatch(first, second) {
  return first.totalBytes === second.totalBytes
    && JSON.stringify(first.files) === JSON.stringify(second.files)
    && JSON.stringify(first.skippedPaths) === JSON.stringify(second.skippedPaths)
}

function sourceInventoriesMatch(first, second) {
  return first.source === second.source
    && first.totalBytes === second.totalBytes
    && JSON.stringify(first.files) === JSON.stringify(second.files)
    && JSON.stringify(first.skippedPaths) === JSON.stringify(second.skippedPaths)
}

async function inspectBackupSetSource(workspaceRoot, sourceValue) {
  const resolved = await assertWorkspaceSource(workspaceRoot, sourceValue)
  const firstScan = await scanWorkspace(resolved.absolute)
  if (!firstScan.count) fail(422, "The selected source folder contains no eligible files.")
  const files = []
  for (const item of firstScan.files) {
    const absolute = path.join(resolved.absolute, ...item.path.split("/"))
    const bytes = await readRegularFile(absolute, LIMITS.maxFileBytes)
    if (bytes.byteLength !== item.bytes) fail(409, "The selected source changed while its files were hashed.")
    files.push({
      path: item.path,
      bytes: bytes.byteLength,
      sha256: createHash("sha256").update(bytes).digest("hex")
    })
  }
  const secondScan = await scanWorkspace(resolved.absolute)
  if (!sourceScansMatch(firstScan, secondScan)) fail(409, "The selected source changed while it was checked.")
  return {
    source: resolved.source,
    files,
    totalBytes: firstScan.totalBytes,
    skippedPaths: firstScan.skippedPaths
  }
}

function safeBackupSetError(error) {
  const message = typeof (error && error.message) === "string" && error.message.trim()
    ? error.message.trim()
    : "The source could not be checked or archived safely."
  if (/[A-Za-z]:[\\/]|\\\\[^\\]+\\|(?:^|[\s(])\/(?:[A-Za-z~])/u.test(message)) {
    return "The source could not be checked or archived safely."
  }
  return message.slice(0, 300)
}

function pruneBackupSetPlans(plans, now = Date.now()) {
  for (const [planId, entry] of plans) {
    if (entry.expiresAtMs <= now) plans.delete(planId)
  }
}

function rememberBackupSetPlan(plans, entry) {
  plans.set(entry.plan.planId, entry)
  while (plans.size > BACKUP_SET_PLAN_CACHE_SIZE) {
    const oldest = plans.keys().next().value
    if (oldest === undefined) break
    plans.delete(oldest)
  }
}

function nextUpdatedAt(previous) {
  const current = Date.now()
  const prior = Date.parse(previous)
  return new Date(Math.max(current, prior + 1)).toISOString()
}

function backupLabelForSet(setLabel, sourceLabel) {
  const combined = setLabel + " - " + sourceLabel
  let clipped = ""
  for (const character of combined) {
    if (clipped.length + character.length > 80) break
    clipped += character
  }
  return clipped.trim() || sourceLabel
}

async function archiveArtifactExists(storage, id) {
  try {
    await lstat(archivePath(storage, id))
    return true
  } catch (error) {
    return !(error && error.code === "ENOENT")
  }
}

async function parseRequestBody(request, expectedOrigin) {
  if (request.headers.origin !== expectedOrigin) fail(403, "This write request did not come from the local Workbench page.")
  if (request.headers["x-workbench"] !== "1") fail(403, "This write request is missing its local Workbench marker.")
  const contentType = request.headers["content-type"] || ""
  if (contentType.split(";", 1)[0].trim().toLowerCase() !== "application/json") {
    fail(415, "Write requests must use application/json.")
  }
  const declaredLength = request.headers["content-length"]
  if (declaredLength !== undefined) {
    const length = Number(declaredLength)
    if (!Number.isSafeInteger(length) || length < 0) fail(400, "Request body length is invalid.")
    if (length > MAX_BODY_BYTES) {
      request.resume()
      fail(413, "Request body exceeds the 16 KiB limit.")
    }
  }
  const chunks = []
  let total = 0
  let tooLarge = false
  try {
    for await (const chunk of request) {
      total += chunk.byteLength
      if (total > MAX_BODY_BYTES) {
        tooLarge = true
        continue
      }
      chunks.push(chunk)
    }
  } catch {
    fail(400, "Request body could not be read.")
  }
  if (tooLarge) fail(413, "Request body exceeds the 16 KiB limit.")
  if (!total) fail(400, "Write request must include a JSON body.")
  let body
  try {
    body = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(Buffer.concat(chunks)))
  } catch {
    fail(400, "Write request must contain valid UTF-8 JSON.")
  }
  if (!isRecord(body)) fail(400, "Write request must contain a JSON object.")
  return body
}

function importLabel(parsedUrl, preview) {
  const keys = Array.from(parsedUrl.searchParams.keys())
  if (preview) {
    if (keys.length) fail(400, "Import preview does not accept query parameters.")
    return null
  }
  if (keys.some(key => key !== "label") || parsedUrl.searchParams.getAll("label").length > 1) {
    fail(400, "Import accepts only one optional label query parameter.")
  }
  return parsedUrl.searchParams.has("label")
    ? normalizeLabel(parsedUrl.searchParams.get("label"), "Imported archive")
    : "Imported archive"
}

async function readImportRequest(request, expectedOrigin) {
  if (request.headers.origin !== expectedOrigin) fail(403, "This write request did not come from the local Workbench page.")
  if (request.headers["x-workbench"] !== "1") fail(403, "This write request is missing its local Workbench marker.")
  const contentType = (request.headers["content-type"] || "").trim().toLowerCase()
  if (contentType !== "application/zip" && contentType !== "application/octet-stream") {
    fail(415, "Import requests must use application/zip or application/octet-stream.")
  }
  const contentEncoding = request.headers["content-encoding"]
  if (contentEncoding !== undefined && contentEncoding.toLowerCase() !== "identity") {
    fail(415, "Compressed request bodies are not supported.")
  }
  const declaredLength = request.headers["content-length"]
  if (declaredLength !== undefined) {
    const length = Number(declaredLength)
    if (!Number.isSafeInteger(length) || length < 0) fail(400, "Request body length is invalid.")
    if (length > LIMITS.maxArchiveBytes) {
      request.resume()
      fail(413, "Import archive exceeds the 52 MiB limit.")
    }
  }
  const chunks = []
  let total = 0
  let tooLarge = false
  try {
    for await (const chunk of request) {
      if (tooLarge) continue
      total += chunk.byteLength
      if (total > LIMITS.maxArchiveBytes) {
        tooLarge = true
        chunks.length = 0
        continue
      }
      chunks.push(chunk)
    }
  } catch {
    fail(400, "Import archive could not be read.")
  }
  if (tooLarge) fail(413, "Import archive exceeds the 52 MiB limit.")
  if (!total) fail(400, "Import request must include an Archive Desk ZIP.")
  if (declaredLength !== undefined && Number(declaredLength) !== total) fail(400, "Request body length did not match its header.")
  return Buffer.concat(chunks, total)
}

async function inspectImportArchive(bytes) {
  let verified
  try {
    verified = await verifyArchive(bytes)
  } catch {
    fail(422, "The uploaded file is not a valid Archive Desk backup.")
  }
  const totalBytes = verified.files.reduce((sum, file) => sum + file.bytes, 0)
  return {
    verified,
    createdAt: verified.manifest.createdAt,
    archiveBytes: bytes.byteLength,
    archiveSha256: await hashArchive(bytes),
    counts: { files: verified.files.length, totalBytes },
    files: verified.files.map(file => ({ path: file.path, bytes: file.bytes, sha256: file.sha256 }))
  }
}

async function saveImportedArchive(storage, bytes, expectedSha256) {
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const id = randomId()
    const output = archivePath(storage, id)
    try {
      await writeFile(output, bytes, { flag: "wx" })
    } catch (error) {
      if (error && error.code === "EEXIST") continue
      try {
        const outputStat = await lstat(output)
        if (outputStat.isFile()) {
          fail(507, "The import write did not finish. An unregistered file remains at " + JSON.stringify(output) + ". Review it before retrying.")
        }
      } catch (inspectionError) {
        if (inspectionError instanceof HttpError) throw inspectionError
      }
      fail(500, "The uploaded archive could not be saved.")
    }
    let savedBytes
    try {
      savedBytes = await readRegularFile(output, LIMITS.maxArchiveBytes)
    } catch {
      fail(507, "The saved archive could not be reopened. An unregistered file remains at " + JSON.stringify(output) + ". Review it before retrying.")
    }
    const savedSha256 = await hashArchive(savedBytes)
    if (savedSha256 !== expectedSha256 || !savedBytes.equals(bytes)) {
      fail(507, "The saved archive did not match the uploaded bytes. An unregistered file remains at " + JSON.stringify(output) + ". Review it before retrying.")
    }
    let verified
    try {
      verified = await verifyArchive(savedBytes)
    } catch {
      fail(507, "The saved archive failed its readback check. An unregistered file remains at " + JSON.stringify(output) + ". Review it before retrying.")
    }
    return { id, verified, archiveBytes: savedBytes.byteLength, sha256: savedSha256 }
  }
  fail(500, "A new archive file could not be reserved without overwriting an existing file.")
}

function sendJson(response, status, body) {
  const bytes = Buffer.from(JSON.stringify(body), "utf8")
  response.writeHead(status, {
    ...SECURITY_HEADERS,
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": bytes.byteLength
  })
  response.end(bytes)
}

function sendBytes(response, status, bytes, contentType, filename) {
  response.writeHead(status, {
    ...SECURITY_HEADERS,
    "Content-Type": contentType,
    "Content-Length": bytes.byteLength,
    "Content-Disposition": "attachment; filename=\"" + filename + "\""
  })
  response.end(bytes)
}

function sendError(response, error) {
  const status = Number.isInteger(error && error.status) ? error.status : 500
  const message = status === 500
    ? "The local operation could not be completed."
    : error.message
  sendJson(response, status, { error: message })
}

async function serveStatic(response, pathname) {
  let filename
  let contentType
  if (pathname === "/") {
    filename = "index.html"
    contentType = "text/html; charset=utf-8"
  } else {
    const entry = STATIC_FILES.get(pathname)
    if (!entry) fail(404, "Page not found.")
    filename = entry[0]
    contentType = entry[1]
  }
  let bytes
  try {
    bytes = await readFile(path.join(PUBLIC_ROOT, filename))
  } catch (error) {
    if (error && error.code === "ENOENT") fail(503, "The local interface files are not ready yet.")
    fail(500, "The local interface file could not be read.")
  }
  response.writeHead(200, {
    ...SECURITY_HEADERS,
    "Content-Type": contentType,
    "Content-Length": bytes.byteLength
  })
  response.end(bytes)
}

function recordById(state, id) {
  validateId(id)
  const record = state.backups.find(item => item.id === id)
  if (!record) fail(404, "Backup was not found.")
  return record
}

function safeCompareReport(report) {
  if (!isRecord(report.counts) || !Array.isArray(report.rows)) fail(422, "The comparison report format is not supported.")
  const keys = ["added", "removed", "changed", "unchanged"]
  if (keys.some(key => !Number.isSafeInteger(report.counts[key]) || report.counts[key] < 0)) {
    fail(422, "The comparison report counts are not valid.")
  }
  for (const row of report.rows) {
    if (!isRecord(row) || typeof row.path !== "string" || !["added", "removed", "changed", "unchanged"].includes(row.status)) {
      fail(422, "The comparison report contains an invalid row.")
    }
  }
  return report
}

async function createWorkbench({ workspace, storage, port = 0 } = {}) {
  if (typeof workspace !== "string" || !workspace || typeof storage !== "string" || !storage) {
    throw new TypeError("Workspace and storage folders are required.")
  }
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new TypeError("Port must be an integer from 0 through 65535.")
  const workspaceCandidate = path.resolve(workspace)
  const storageCandidate = path.resolve(storage)
  if (isInsideOrSame(workspaceCandidate, storageCandidate) || isInsideOrSame(storageCandidate, workspaceCandidate)) {
    throw new WorkspaceError("Workspace and backup storage must be separate folders.", 400)
  }
  const workspaceRoot = await assertDirectoryTree(workspaceCandidate)
  const storageRoot = await assertDirectoryTree(storageCandidate, { create: true })
  if (isInsideOrSame(workspaceRoot, storageRoot) || isInsideOrSame(storageRoot, workspaceRoot)) {
    throw new WorkspaceError("Workspace and backup storage must be separate folders.", 400)
  }
  const storageDirectories = ["archives", "reports", "restores", "labs"]
  for (const child of storageDirectories) {
    await assertDirectoryTree(path.join(storageRoot, child), { create: true })
  }
  const runHistoryDirectory = await assertDirectoryTree(path.join(storageRoot, "set-runs"), { create: true })
  const stateFile = path.join(storageRoot, "state.json")
  const setsFile = path.join(storageRoot, "backup-sets.json")
  const setsMarkerFile = path.join(storageRoot, "backup-sets.initialized.json")
  const [state, savedSetsFile, savedSetsMarker] = await Promise.all([
    readStateFile(stateFile),
    readBackupSetsFile(setsFile),
    readBackupSetsMarker(setsMarkerFile)
  ])
  if (savedSetsFile.missing && !savedSetsMarker.missing) {
    fail(500, "The saved backup sets file is missing. It was not reset.")
  }
  if (await statePathIsNew(stateFile)) await persistState(stateFile, state)
  if (savedSetsFile.missing) await persistBackupSetsFile(setsFile, defaultBackupSets())
  if (savedSetsMarker.missing) await persistBackupSetsMarker(setsMarkerFile)
  let savedSets = savedSetsFile.state
  const workspaceLabel = path.basename(workspaceRoot) || "Workspace"
  const backupSetPlans = new Map()
  let busy = false
  let runHistoryWriteInProgress = false
  let url = ""

  const handle = async (request, response) => {
    for (const [name, value] of Object.entries(SECURITY_HEADERS)) response.setHeader(name, value)
    const expectedHost = "127.0.0.1:" + server.address().port
    if (request.headers.host !== expectedHost) {
      sendJson(response, 421, { error: "Use the exact local Workbench address shown by the server." })
      return
    }
    if (request.headers["sec-fetch-site"] === "cross-site") {
      sendJson(response, 403, { error: "Cross-site requests are not accepted." })
      return
    }

    let parsedUrl
    try {
      parsedUrl = new URL(request.url || "/", url)
    } catch {
      sendJson(response, 400, { error: "Request URL is invalid." })
      return
    }

    const pathname = parsedUrl.pathname
    if (request.method === "GET" && (pathname === "/" || STATIC_FILES.has(pathname))) {
      try {
        await serveStatic(response, pathname)
      } catch (error) {
        sendError(response, error)
      }
      return
    }
    if (request.method === "GET" && pathname === "/api/state") {
      sendJson(response, 200, {
        version: VERSION,
        workspaceLabel,
        workspacePath: workspaceRoot,
        storagePath: storageRoot,
        backups: state.backups.map(publicBackup),
        activity: state.activity,
        busy
      })
      return
    }
    if (request.method === "GET" && pathname === "/api/sets") {
      if (parsedUrl.search) {
        sendJson(response, 400, { error: "Backup set listing does not accept query parameters." })
        return
      }
      pruneBackupSetPlans(backupSetPlans)
      sendJson(response, 200, {
        format: "archive-desk-backup-sets",
        version: 1,
        sets: savedSets.sets.map(publicBackupSet),
        limits: BACKUP_SET_LIMITS
      })
      return
    }
    const runHistoryRoute = /^\/api\/set-runs(?:\/([^/]+)(\/download)?)?$/u.exec(pathname)
    if (request.method === "GET" && runHistoryRoute !== null) {
      if (parsedUrl.search) {
        sendJson(response, 400, { error: "Set-run history requests do not accept query parameters." })
        return
      }
      if (request.headers.origin !== undefined && request.headers.origin !== url) {
        sendJson(response, 403, { error: "This request did not come from the local Workbench page." })
        return
      }
      try {
        const id = runHistoryRoute[1]
        const download = runHistoryRoute[2] === "/download"
        if (id === undefined) {
          if (runHistoryWriteInProgress) {
            sendJson(response, 409, { error: "Set-run history is being saved. Try the listing again when the operation finishes." })
            return
          }
          sendJson(response, 200, await listRunHistory(runHistoryDirectory))
          return
        }
        const { report, bytes } = await readRunHistory(runHistoryDirectory, id)
        if (download) {
          sendBytes(response, 200, bytes, "application/json; charset=utf-8", "set-run-" + id + ".json")
        } else {
          sendJson(response, 200, { run: report })
        }
      } catch (error) {
        sendError(response, error)
      }
      return
    }
    if (request.method === "GET" && pathname === "/api/preview") {
      try {
        const keys = Array.from(parsedUrl.searchParams.keys())
        if (keys.some(key => key !== "source") || parsedUrl.searchParams.getAll("source").length > 1) {
          fail(400, "Preview accepts one relative source folder.")
        }
        const source = parsedUrl.searchParams.get("source") ?? "."
        const resolved = await assertWorkspaceSource(workspaceRoot, source)
        const scan = await scanWorkspace(resolved.absolute)
        sendJson(response, 200, sourcePreviewPayload(resolved.source, scan))
      } catch (error) {
        sendError(response, error)
      }
      return
    }

    const backupSetRoute = /^\/api\/sets(?:\/([^/]+)(?:\/(preview|run))?)?$/u.exec(pathname)
    const isBackupSetWrite = request.method === "POST" && backupSetRoute !== null
    if (isBackupSetWrite) {
      if (busy) {
        sendJson(response, 409, { error: "Another Workbench operation is in progress. Try again when it finishes." })
        return
      }
      busy = true
      try {
        if (parsedUrl.search) fail(400, "Backup set requests do not accept query parameters.")
        const body = await parseRequestBody(request, url)
        pruneBackupSetPlans(backupSetPlans)
        const routeId = backupSetRoute[1]
        const action = backupSetRoute[2] ?? (routeId === undefined ? "create" : "edit")

        if (action === "create") {
          const input = normalizeBackupSetInput(body)
          if (savedSets.sets.length >= BACKUP_SET_LIMITS.maxSets) fail(409, "The backup set limit of 12 has been reached.")
          let id = makeBackupSetId()
          while (savedSets.sets.some(record => record.id === id)) id = makeBackupSetId()
          const createdAt = isoNow()
          const record = { id, ...input, createdAt, updatedAt: createdAt }
          const next = { ...savedSets, sets: [record, ...savedSets.sets] }
          validateBackupSetsState(next)
          await persistBackupSetsFile(setsFile, next)
          savedSets = next
          sendJson(response, 201, { set: publicBackupSet(record) })
          return
        }

        if (action === "edit") {
          const id = validateId(routeId)
          const index = savedSets.sets.findIndex(record => record.id === id)
          if (index === -1) fail(404, "Backup set was not found.")
          const input = normalizeBackupSetInput(body)
          const existing = savedSets.sets[index]
          const record = { id, ...input, createdAt: existing.createdAt, updatedAt: nextUpdatedAt(existing.updatedAt) }
          const next = { ...savedSets, sets: savedSets.sets.map((item, itemIndex) => itemIndex === index ? record : item) }
          validateBackupSetsState(next)
          await persistBackupSetsFile(setsFile, next)
          savedSets = next
          sendJson(response, 200, { set: publicBackupSet(record) })
          return
        }

        const id = validateId(routeId)
        const setRecord = savedSets.sets.find(record => record.id === id)
        if (!setRecord) fail(404, "Backup set was not found.")

        if (action === "preview") {
          exactKeys(body, new Set(), "Backup set preview request")
          const plannedAtMs = Date.now()
          const plannedAt = new Date(plannedAtMs).toISOString()
          const expiresAtMs = plannedAtMs + BACKUP_SET_PLAN_TTL_MS
          const results = []
          for (const source of setRecord.sources) {
            try {
              const inventory = await inspectBackupSetSource(workspaceRoot, source.source)
              results.push({
                source: source.source,
                label: source.label,
                status: "ready",
                files: inventory.files,
                totalBytes: inventory.totalBytes,
                skippedPaths: inventory.skippedPaths
              })
            } catch (error) {
              results.push({
                source: source.source,
                label: source.label,
                status: "failed",
                files: [],
                totalBytes: 0,
                skippedPaths: [],
                error: safeBackupSetError(error)
              })
            }
          }
          const ready = results.filter(result => result.status === "ready")
          const planId = randomId()
          const plan = {
            format: "archive-desk-backup-set-plan",
            version: 1,
            planId,
            plannedAt,
            expiresAt: new Date(expiresAtMs).toISOString(),
            set: { id: setRecord.id, label: setRecord.label, updatedAt: setRecord.updatedAt },
            counts: {
              sources: results.length,
              ready: ready.length,
              failed: results.length - ready.length,
              files: ready.reduce((sum, result) => sum + result.files.length, 0),
              totalBytes: ready.reduce((sum, result) => sum + result.totalBytes, 0)
            },
            results,
            limitations: BACKUP_SET_PLAN_LIMITATIONS
          }
          rememberBackupSetPlan(backupSetPlans, {
            plan,
            expiresAtMs,
            setRevision: setRecord.updatedAt
          })
          sendJson(response, 200, plan)
          return
        }

        if (action === "run") {
          exactKeys(body, new Set(["planId"]), "Backup set run request")
          if (typeof body.planId !== "string" || !ID_PATTERN.test(body.planId)) fail(400, "Backup set plan ID is invalid.")
          const planEntry = backupSetPlans.get(body.planId)
          if (!planEntry || planEntry.expiresAtMs <= Date.now()) {
            backupSetPlans.delete(body.planId)
            fail(409, "This backup set preview is unknown or expired. Create a fresh preview.")
          }
          if (planEntry.plan.set.id !== id) fail(409, "This preview belongs to a different backup set.")
          const currentSet = savedSets.sets.find(record => record.id === id)
          if (!currentSet || currentSet.updatedAt !== planEntry.setRevision) {
            backupSetPlans.delete(body.planId)
            fail(409, "The backup set changed after preview. Create a fresh preview.")
          }

          backupSetPlans.delete(body.planId)
          const startedAt = isoNow()
          const results = []
          for (const planned of planEntry.plan.results) {
            if (planned.status !== "ready") {
              results.push({
                source: planned.source,
                label: planned.label,
                status: "skipped",
                error: "This source was not ready in the preview."
              })
              continue
            }

            const backupId = randomId()
            let archiveWriteAttempted = false
            try {
              const currentInventory = await inspectBackupSetSource(workspaceRoot, planned.source)
              if (!sourceInventoriesMatch(currentInventory, planned)) {
                fail(409, "The source file inventory changed after preview. Create a fresh preview.")
              }
              archiveWriteAttempted = true
              const archive = await createArchive(storageRoot, path.join(workspaceRoot, ...planned.source.split("/")), backupId)
              const archivedInventory = {
                source: planned.source,
                files: archive.verified.files
                  .map(file => ({ path: file.path, bytes: file.bytes, sha256: file.sha256 }))
                  .sort((left, right) => left.path < right.path ? -1 : left.path > right.path ? 1 : 0),
                totalBytes: archive.totalBytes,
                skippedPaths: planned.skippedPaths
              }
              if (!sourceInventoriesMatch(archivedInventory, planned)) {
                fail(409, "The created archive does not match the previewed source inventory.")
              }
              const label = backupLabelForSet(currentSet.label, planned.label)
              const record = createRecord({
                id: backupId,
                label,
                source: planned.source,
                demo: false,
                archive
              })
              try {
                await persistMutation(state, stateFile, () => {
                  addRecord(state, record)
                  addActivity(state, "Backup set source created", label + " · " + record.files + " files")
                })
              } catch {
                fail(507, "The archive was created but the backup library could not be updated.")
              }
              results.push({ source: planned.source, label: planned.label, status: "created", backup: publicBackup(record) })
            } catch (error) {
              let message = safeBackupSetError(error)
              if (archiveWriteAttempted && await archiveArtifactExists(storageRoot, backupId)) {
                message += " An archive artifact remains unregistered at archives/" + backupId + ".zip. Review it before retrying."
              }
              results.push({ source: planned.source, label: planned.label, status: "failed", error: message })
            }
          }
          const finishedAt = isoNow()
          const runId = randomId()
          let report = {
            format: "archive-desk-backup-set-run",
            version: 1,
            runId,
            startedAt,
            finishedAt,
            set: { id: currentSet.id, label: currentSet.label },
            counts: {
              sources: results.length,
              created: results.filter(result => result.status === "created").length,
              failed: results.filter(result => result.status === "failed").length,
              skipped: results.filter(result => result.status === "skipped").length
            },
            results,
            limitations: [...BACKUP_SET_PLAN_LIMITATIONS, ...RUN_HISTORY_LIMITATIONS],
            history: { id: runId, saved: true }
          }
          try {
            runHistoryWriteInProgress = true
            await persistRunHistory(runHistoryDirectory, report)
          } catch (error) {
            const historyError = error && error.status === 507 && typeof error.message === "string"
              ? error.message
              : "The set-run history report could not be saved safely."
            report = {
              ...report,
              history: { id: runId, saved: false, error: historyError },
              limitations: [...report.limitations, "The report could not be saved. Backups created by this run remain registered, and this response is the available record of the attempt."]
            }
          } finally {
            runHistoryWriteInProgress = false
          }
          sendJson(response, 200, report)
          return
        }
      } catch (error) {
        sendError(response, error)
      } finally {
        busy = false
      }
      return
    }

    const importAction = pathname === "/api/import/preview" ? "preview" : pathname === "/api/import" ? "import" : null
    const isImportWrite = request.method === "POST" && importAction !== null
    if (isImportWrite) {
      if (busy) {
        sendJson(response, 409, { error: "Another Workbench operation is in progress. Try again when it finishes." })
        return
      }
      busy = true
      try {
        const label = importLabel(parsedUrl, importAction === "preview")
        const bytes = await readImportRequest(request, url)
        const inspected = await inspectImportArchive(bytes)
        if (importAction === "preview") {
          sendJson(response, 200, {
            createdAt: inspected.createdAt,
            archiveBytes: inspected.archiveBytes,
            archiveSha256: inspected.archiveSha256,
            counts: inspected.counts,
            files: inspected.files
          })
          return
        }
        if (state.backups.some(record => record.sha256 === inspected.archiveSha256)) {
          fail(409, "This archive is already in the backup library.")
        }
        const saved = await saveImportedArchive(storageRoot, bytes, inspected.archiveSha256)
        const savedTotalBytes = saved.verified.files.reduce((sum, file) => sum + file.bytes, 0)
        const record = {
          id: saved.id,
          label,
          source: ".",
          createdAt: saved.verified.manifest.createdAt,
          files: saved.verified.files.length,
          totalBytes: savedTotalBytes,
          archiveBytes: saved.archiveBytes,
          sha256: saved.sha256,
          verifiedAt: isoNow(),
          demo: false,
          origin: "import",
          reportIds: []
        }
        try {
          await persistMutation(state, stateFile, () => {
            addRecord(state, record)
            addActivity(state, "Archive imported", label + " · " + record.files + " files")
          })
        } catch {
          fail(507, "The ZIP was saved and verified, but the backup library could not be updated. The archive remains unregistered at " + JSON.stringify(archivePath(storageRoot, record.id)) + ". Review it before retrying.")
        }
        sendJson(response, 201, { backup: publicBackup(record) })
      } catch (error) {
        sendError(response, error)
      } finally {
        busy = false
      }
      return
    }

    const backupRoute = /^\/api\/backups\/([^/]+)\/(verify|compare|restore-plan|restore|download|report|verification)$/u.exec(pathname)
    const isBackupWrite = request.method === "POST" && (pathname === "/api/backups" || pathname === "/api/demo" || pathname === "/api/library-check" || Boolean(backupRoute && ["verify", "compare", "restore-plan", "restore"].includes(backupRoute[2])))
    if (isBackupWrite) {
      if (busy) {
        sendJson(response, 409, { error: "Another Workbench operation is in progress. Try again when it finishes." })
        return
      }
      busy = true
      try {
        const body = await parseRequestBody(request, url)
        if (pathname === "/api/library-check") {
          exactKeys(body, new Set(), "Library check request")
          const results = []
          for (const record of state.backups) {
            results.push(await checkLibraryRecord(storageRoot, record))
          }
          const passed = results.filter(result => result.status === "passed").length
          sendJson(response, 200, {
            format: "archive-desk-library-check",
            version: 1,
            checkedAt: isoNow(),
            counts: { backups: results.length, passed, failed: results.length - passed },
            results,
            limits: LIBRARY_CHECK_LIMITS
          })
          return
        }
        if (pathname === "/api/backups") {
          exactKeys(body, new Set(["source", "label"]), "Backup request")
          const sourceValue = body.source === undefined ? "." : body.source
          const label = normalizeLabel(body.label)
          const resolved = await assertWorkspaceSource(workspaceRoot, sourceValue)
          const id = randomId()
          const archive = await createArchive(storageRoot, resolved.absolute, id)
          const record = createRecord({
            id,
            label,
            source: resolved.source,
            demo: false,
            archive
          })
          await persistMutation(state, stateFile, () => {
            addRecord(state, record)
            addActivity(state, "Backup created", label + " · " + record.files + " files")
          })
          sendJson(response, 201, { backup: publicBackup(record) })
          return
        }
        if (pathname === "/api/demo") {
          exactKeys(body, new Set(), "Sample workflow request")
          const result = await runDemo({ workspaceRoot, storageRoot, state, stateFile })
          sendJson(response, 200, result)
          return
        }
        if (!backupRoute) fail(404, "Page not found.")
        const id = validateId(backupRoute[1])
        const action = backupRoute[2]
        const record = recordById(state, id)
        if (action === "verify") {
          exactKeys(body, new Set(), "Verify request")
          const { verified, sha256 } = await readVerifiedArchive(storageRoot, record)
          await persistMutation(state, stateFile, () => {
            record.verifiedAt = isoNow()
            record.sha256 = sha256
            addActivity(state, "Backup verified", record.label + " · " + verified.files.length + " files")
          })
          sendJson(response, 200, {
            backup: publicBackup(record),
            files: verified.files.map(file => ({ path: file.path, bytes: file.bytes, sha256: file.sha256 })),
            message: "Every saved file matched its archive manifest."
          })
          return
        }
        if (action === "compare") {
          exactKeys(body, new Set(["source"]), "Compare request")
          if (record.origin === "import" && body.source === undefined) {
            fail(400, "Choose a configured workspace folder to compare with this imported archive.")
          }
          const sourceValue = body.source === undefined ? record.demo ? "." : record.source : body.source
          const requestedSource = validateRelativeDirectory(sourceValue)
          const suppliedSource = record.demo ? null : await assertWorkspaceSource(workspaceRoot, requestedSource)
          const selectedRoot = currentSourcePath(workspaceRoot, storageRoot, record, suppliedSource)
          const { bytes } = await readVerifiedArchive(storageRoot, record)
          const reportId = randomId()
          const outputReport = reportPath(storageRoot, record.id, reportId)
          await runCli(["compare", archivePath(storageRoot, record.id), selectedRoot, "--report", outputReport], "Comparison could not be completed. Check the selected folder and saved archive.")
          const reportBytes = await readRegularFile(outputReport, 1024 * 1024)
          let report
          try {
            report = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(reportBytes))
          } catch {
            fail(422, "The comparison report could not be read back.")
          }
          if (!isRecord(report) || report.baselineArchiveSha256 !== await hashArchive(bytes)) {
            fail(422, "The comparison report does not match the saved baseline archive.")
          }
          safeCompareReport(report)
          await persistMutation(state, stateFile, () => {
            record.reportIds.push(reportId)
            addActivity(state, "Changes compared", report.counts.added + " added · " + report.counts.removed + " removed · " + report.counts.changed + " changed")
          })
          sendJson(response, 200, report)
          return
        }
        if (action === "restore-plan") {
          exactKeys(body, new Set(["name"]), "Restore plan request")
          const name = validateRestoreName(body.name)
          await assertNewDirectory(path.join(storageRoot, "restores"), name)
          const { verified, sha256 } = await readVerifiedArchive(storageRoot, record)
          sendJson(response, 200, {
            format: "archive-desk-restore-plan",
            version: 1,
            generatedAt: isoNow(),
            backupId: record.id,
            archiveSha256: sha256,
            name,
            destination: "restores/" + name,
            counts: verified.counts,
            files: verified.files,
            limitations: RESTORE_PLAN_LIMITATIONS
          })
          return
        }
        if (action === "restore") {
          exactKeys(body, new Set(["name", "archiveSha256"]), "Restore request")
          const name = validateRestoreName(body.name)
          const expectedSha256 = body.archiveSha256
          if (expectedSha256 !== undefined && (typeof expectedSha256 !== "string" || !HASH_PATTERN.test(expectedSha256))) {
            fail(400, "Archive SHA-256 must contain 64 lowercase hexadecimal characters.")
          }
          const destination = await assertNewDirectory(path.join(storageRoot, "restores"), name)
          const { verified, sha256 } = await readVerifiedArchive(storageRoot, record)
          if (expectedSha256 !== undefined && expectedSha256 !== sha256) {
            fail(409, "The verified archive SHA-256 does not match the requested value.")
          }
          await runCli(["restore", archivePath(storageRoot, record.id), "--out", destination], "Recovery could not be completed.", destination)
          await persistMutation(state, stateFile, () => {
            addActivity(state, "Recovery completed", name + " · " + verified.files.length + " files")
          })
          sendJson(response, 200, {
            destination,
            files: verified.files.length,
            totalBytes: verified.files.reduce((sum, file) => sum + file.bytes, 0),
            verified: true,
            message: verified.files.length + " files recovered and checked against the archive manifest."
          })
          return
        }
        fail(405, "This backup action requires GET.")
      } catch (error) {
        sendError(response, error)
      } finally {
        busy = false
      }
      return
    }

    if (request.method === "GET" && backupRoute) {
      try {
        const id = validateId(backupRoute[1])
        const action = backupRoute[2]
        const record = recordById(state, id)
        if (action === "download") {
          const { bytes } = await readVerifiedArchive(storageRoot, record)
          sendBytes(response, 200, bytes, "application/zip", "archive-" + record.id + ".zip")
          return
        }
        if (action === "report") {
          const { bytes } = await readReport(storageRoot, record)
          sendBytes(response, 200, bytes, "application/json; charset=utf-8", "comparison-" + record.id + ".json")
          return
        }
        if (action === "verification") {
          const { bytes, verified, sha256 } = await readVerifiedArchive(storageRoot, record)
          const report = {
            format: "archive-desk-verification",
            version: 1,
            generatedAt: isoNow(),
            backupId: record.id,
            label: record.label,
            origin: record.origin ?? (record.demo ? "demo" : "workspace"),
            archiveSha256: sha256,
            archiveBytes: bytes.byteLength,
            counts: verified.counts,
            files: verified.files,
            limitations: VERIFICATION_LIMITATIONS
          }
          sendBytes(response, 200, Buffer.from(JSON.stringify(report), "utf8"), "application/json; charset=utf-8", "verification-" + record.id + ".json")
          return
        }
        fail(405, "This backup action requires POST.")
      } catch (error) {
        sendError(response, error)
      }
      return
    }

    if (request.method === "GET" && pathname.startsWith("/api/")) {
      sendJson(response, 404, { error: "Page not found." })
      return
    }
    sendJson(response, request.method === "GET" || request.method === "POST" ? 404 : 405, { error: "Page not found." })
  }

  const server = createServer((request, response) => {
    void handle(request, response).catch(error => {
      if (!response.headersSent) sendError(response, error)
      else response.destroy()
    })
  })
  server.requestTimeout = 30_000
  server.headersTimeout = 15_000
  server.keepAliveTimeout = 1_000
  server.maxHeadersCount = 100
  await new Promise((resolve, reject) => {
    server.once("error", reject)
    server.listen(port, "127.0.0.1", () => {
      server.removeListener("error", reject)
      resolve()
    })
  })
  url = "http://127.0.0.1:" + server.address().port
  return {
    server,
    url,
    async close() {
      await new Promise((resolve, reject) => {
        server.close(error => error ? reject(error) : resolve())
      })
    }
  }

  async function runDemo({ workspaceRoot: chosenWorkspace, storageRoot: chosenStorage, state: chosenState, stateFile: chosenStateFile }) {
    let id = randomId()
    let lab = path.join(chosenStorage, "labs", id)
    let archiveOutput = archivePath(chosenStorage, id)
    while (!(await statePathIsNew(lab)) || !(await statePathIsNew(archiveOutput))) {
      id = randomId()
      lab = path.join(chosenStorage, "labs", id)
      archiveOutput = archivePath(chosenStorage, id)
    }
    await createDirectoryExclusive(lab)
    const baseline = path.join(lab, "baseline")
    const current = path.join(lab, "current")
    await mkdir(baseline)
    await mkdir(current)
    const baselineFiles = [
      ["unchanged-a.txt", "First sample note\n"],
      ["unchanged-b.txt", "Second sample note\n"],
      ["changed.txt", "Original sample wording\n"],
      ["removed.txt", "This sample note stays in the baseline folder\n"],
      [".git/readme.txt", "Excluded sample metadata\n"]
    ]
    for (const [name, content] of baselineFiles) {
      const absolute = path.join(baseline, ...name.split("/"))
      await mkdir(path.dirname(absolute), { recursive: true })
      await writeFile(absolute, content, { flag: "wx" })
    }
    const currentFiles = [
      ["unchanged-a.txt", "First sample note\n"],
      ["unchanged-b.txt", "Second sample note\n"],
      ["changed.txt", "Updated sample wording\n"],
      ["added.txt", "New sample note\n"]
    ]
    for (const [name, content] of currentFiles) {
      const absolute = path.join(current, ...name.split("/"))
      await writeFile(absolute, content, { flag: "wx" })
    }
    const archive = await createArchive(chosenStorage, baseline, id)
    const record = createRecord({
      id,
      label: "Guided sample backup",
      source: "demo:" + id,
      demo: true,
      archive
    })
    await persistMutation(chosenState, chosenStateFile, () => {
      addRecord(chosenState, record)
      addActivity(chosenState, "Sample backup created", "4 eligible files in a new lab folder")
    })

    const reportId = randomId()
    const outputReport = reportPath(chosenStorage, id, reportId)
    await runCli(["compare", archivePath(chosenStorage, id), current, "--report", outputReport], "The sample comparison could not be completed.")
    const reportBytes = await readRegularFile(outputReport, 1024 * 1024)
    let comparison
    try {
      comparison = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(reportBytes))
    } catch {
      fail(422, "The sample comparison report could not be read back.")
    }
    safeCompareReport(comparison)
    if (comparison.baselineArchiveSha256 !== record.sha256
      || comparison.counts.added !== 1
      || comparison.counts.removed !== 1
      || comparison.counts.changed !== 1
      || comparison.counts.unchanged !== 2) {
      fail(422, "The sample comparison did not produce the expected file counts.")
    }
    record.reportIds.push(reportId)
    await persistMutation(chosenState, chosenStateFile, () => {})
    const recoveryName = "recovered-demo-" + id.slice(0, 8)
    const destination = await assertNewDirectory(path.join(chosenStorage, "restores"), recoveryName)
    await runCli(["restore", archivePath(chosenStorage, id), "--out", destination], "The sample recovery could not be completed.", destination)
    const restored = await readRegularFile(path.join(destination, "unchanged-a.txt"), LIMITS.maxFileBytes)
    if (restored.toString("utf8") !== "First sample note\n") fail(422, "A recovered sample file failed its readback check.")
    const restoreResult = {
      destination,
      files: archive.files,
      totalBytes: archive.totalBytes,
      verified: true,
      message: archive.files + " files recovered and checked against the archive manifest."
    }
    await persistMutation(chosenState, chosenStateFile, () => {
      addActivity(chosenState, "Sample workflow completed", "Backup, comparison and recovery all passed")
    })
    return {
      backup: publicBackup(record),
      comparison,
      restore: restoreResult,
      steps: [
        { title: "Create an isolated sample", detail: "Four included baseline files and one excluded sample metadata file were written under a new lab folder.", status: "pass" },
        { title: "Save and verify the ZIP", detail: archive.files + " files passed readback against the saved archive manifest.", status: "pass" },
        { title: "Compare the changed copy", detail: "1 added, 1 removed, 1 changed and 2 unchanged files.", status: "pass" },
        { title: "Recover into a new folder", detail: archive.files + " files were read back and checked. The configured workspace was not changed.", status: "pass" }
      ]
    }
  }
}

export { createWorkbench }

async function main(args) {
  const options = { workspace: path.resolve("demo"), storage: path.resolve("workbench-data"), port: 4330 }
  const seenFlags = new Set()
  for (let index = 0; index < args.length; index += 1) {
    const flag = args[index]
    const value = args[index + 1]
    if (!["--workspace", "--storage", "--port"].includes(flag) || value === undefined || value.startsWith("--")) {
      throw new Error("Use --workspace, --storage and --port with one value each.")
    }
    if (seenFlags.has(flag)) throw new Error("Each server option can be provided only once.")
    seenFlags.add(flag)
    if (flag === "--port") {
      if (!/^\d+$/u.test(value)) throw new Error("Port must be an integer from 0 through 65535.")
      options.port = Number(value)
    } else {
      options[flag.slice(2)] = path.resolve(value)
    }
    index += 1
  }
  const app = await createWorkbench(options)
  process.stdout.write("Archive Desk Workbench is running at " + app.url + "\n")
  const stop = async () => {
    try {
      await app.close()
    } catch {
      process.exitCode = 1
    }
  }
  process.once("SIGINT", () => { void stop() })
  process.once("SIGTERM", () => { void stop() })
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  main(process.argv.slice(2)).catch(() => {
    process.stderr.write("Archive Desk Workbench could not start. Check the configured folders and port.\n")
    process.exitCode = 1
  })
}
