import assert from "node:assert/strict"
import { mkdir, mkdtemp, readFile, readdir, rename, symlink, writeFile } from "node:fs/promises"
import http from "node:http"
import os from "node:os"
import path from "node:path"
import test from "node:test"
import { createWorkbench } from "./server.mjs"

async function makeFixture() {
  const root = await mkdtemp(path.join(os.tmpdir(), "archive-desk-run-history-"))
  const workspace = path.join(root, "workspace")
  const storage = path.join(root, "storage")
  await mkdir(workspace)
  await mkdir(storage)
  return { root, workspace, storage }
}

async function putFile(root, relative, value) {
  const absolute = path.join(root, ...relative.split("/"))
  await mkdir(path.dirname(absolute), { recursive: true })
  await writeFile(absolute, value)
  return absolute
}

async function startApp(t, fixture) {
  const app = await createWorkbench({ workspace: fixture.workspace, storage: fixture.storage, port: 0 })
  let running = true
  t.after(async () => {
    if (!running) return
    running = false
    await app.close()
  })
  return {
    app,
    async close() {
      if (!running) return
      running = false
      await app.close()
    }
  }
}

function headers(app, extra = {}) {
  return {
    Origin: app.url,
    "Content-Type": "application/json",
    "X-Workbench": "1",
    ...extra
  }
}

async function post(app, route, value) {
  return fetch(app.url + route, {
    method: "POST",
    headers: headers(app),
    body: JSON.stringify(value)
  })
}

async function responseJson(response) {
  const text = await response.text()
  try {
    return JSON.parse(text)
  } catch {
    assert.fail("Expected a JSON response, received: " + text.slice(0, 200))
  }
}

async function rawRequest(app, route, { method = "GET", requestHeaders = {} } = {}) {
  const address = new URL(route, app.url)
  return new Promise((resolve, reject) => {
    const chunks = []
    const request = http.request({
      hostname: address.hostname,
      port: Number(address.port),
      path: address.pathname + address.search,
      method,
      headers: requestHeaders,
      agent: false
    }, response => {
      response.on("data", chunk => chunks.push(chunk))
      response.on("end", () => resolve({
        status: response.statusCode,
        headers: response.headers,
        body: Buffer.concat(chunks)
      }))
    })
    request.once("error", reject)
    request.end()
  })
}

function sourceSet(label, sources) {
  return {
    label,
    sources: sources.map(([source, sourceLabel]) => ({ source, label: sourceLabel }))
  }
}

test("legacy empty history lists without changing storage and rejects unsafe routes", async t => {
  const fixture = await makeFixture()
  const { app } = await startApp(t, fixture)
  const stateBefore = await readFile(path.join(fixture.storage, "state.json"))
  const historyDirectory = path.join(fixture.storage, "set-runs")
  const namesBefore = await readdir(historyDirectory)

  const listed = await responseJson(await fetch(app.url + "/api/set-runs"))
  assert.deepEqual(listed, {
    format: "archive-desk-backup-set-runs",
    version: 1,
    runs: [],
    limitations: [
      "This is a saved snapshot of the set run, not a fresh verification of the current archives.",
      "History records are retained as local JSON files. They are not authentic signatures, and hashes show consistency rather than authenticity."
    ]
  })
  assert.deepEqual(await readdir(historyDirectory), namesBefore)
  assert.deepEqual(await readFile(path.join(fixture.storage, "state.json")), stateBefore)

  const historyModule = await fetch(app.url + "/history.mjs")
  assert.equal(historyModule.status, 200)
  assert.match(historyModule.headers.get("content-type"), /^text\/javascript/u)
  const historyStyles = await fetch(app.url + "/history.css")
  assert.equal(historyStyles.status, 200)
  assert.match(historyStyles.headers.get("content-type"), /^text\/css/u)

  const traversal = await rawRequest(app, "/api/set-runs/%2f..%2fstate.json")
  assert.equal(traversal.status, 400)
  const wrongOrigin = await rawRequest(app, "/api/set-runs", { requestHeaders: { Origin: "http://example.invalid" } })
  assert.equal(wrongOrigin.status, 403)
  const wrongHost = await rawRequest(app, "/api/set-runs", { requestHeaders: { Host: "localhost:4330" } })
  assert.equal(wrongHost.status, 421)
})

test("partial set runs persist exact reports across restart and download without mutation", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "project/value.txt", "synthetic source\n")
  const first = await startApp(t, fixture)
  const created = await responseJson(await post(first.app, "/api/sets", sourceSet("Mixed sources", [
    ["project", "Available project"],
    ["missing", "Missing project"]
  ])))
  const plan = await responseJson(await post(first.app, "/api/sets/" + created.set.id + "/preview", {}))
  assert.deepEqual(plan.counts, { sources: 2, ready: 1, failed: 1, files: 1, totalBytes: 17 })

  const run = await responseJson(await post(first.app, "/api/sets/" + created.set.id + "/run", { planId: plan.planId }))
  assert.equal(run.history.saved, true)
  assert.equal(run.history.id, run.runId)
  assert.deepEqual(run.counts, { sources: 2, created: 1, failed: 0, skipped: 1 })
  assert.equal(run.results[0].status, "created")
  assert.equal(run.results[1].status, "skipped")

  const historyFile = path.join(fixture.storage, "set-runs", run.runId + ".json")
  const exactBytes = await readFile(historyFile)
  assert.deepEqual(JSON.parse(exactBytes.toString("utf8")), run)
  const beforeRead = await readFile(historyFile)
  const listed = await responseJson(await fetch(first.app.url + "/api/set-runs"))
  assert.equal(listed.runs.length, 1)
  assert.deepEqual(listed.runs[0], {
    id: run.runId,
    runId: run.runId,
    startedAt: run.startedAt,
    finishedAt: run.finishedAt,
    set: run.set,
    counts: run.counts,
    history: { id: run.runId, saved: true }
  })
  const detail = await responseJson(await fetch(first.app.url + "/api/set-runs/" + run.runId))
  assert.deepEqual(detail, { run })
  const download = await rawRequest(first.app, "/api/set-runs/" + run.runId + "/download")
  assert.equal(download.status, 200)
  assert.equal(download.headers["content-type"], "application/json; charset=utf-8")
  assert.match(download.headers["content-disposition"], new RegExp("set-run-" + run.runId + "\\.json", "u"))
  assert.deepEqual(download.body, exactBytes)
  assert.deepEqual(await readFile(historyFile), beforeRead)

  await first.close()
  const restarted = await startApp(t, fixture)
  const afterRestart = await responseJson(await fetch(restarted.app.url + "/api/set-runs/" + run.runId))
  assert.deepEqual(afterRestart, { run })
  const downloadedAgain = await rawRequest(restarted.app, "/api/set-runs/" + run.runId + "/download")
  assert.deepEqual(downloadedAgain.body, exactBytes)
  assert.equal((await responseJson(await fetch(restarted.app.url + "/api/state"))).backups.length, 1)
})

test("corrupt and mismatched reports are listed without hiding or serving intact history", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "project/value.txt", "synthetic\n")
  const { app } = await startApp(t, fixture)
  const created = await responseJson(await post(app, "/api/sets", sourceSet("History fixture", [["project", "Project"]])))
  const plan = await responseJson(await post(app, "/api/sets/" + created.set.id + "/preview", {}))
  const validRun = await responseJson(await post(app, "/api/sets/" + created.set.id + "/run", { planId: plan.planId }))

  const mismatchedId = "a".repeat(24)
  const mismatchedReport = { ...validRun, runId: "b".repeat(24), history: { id: "b".repeat(24), saved: true } }
  await writeFile(path.join(fixture.storage, "set-runs", mismatchedId + ".json"), JSON.stringify(mismatchedReport))
  const invalidCountsId = "c".repeat(24)
  const invalidCountsReport = {
    ...validRun,
    runId: invalidCountsId,
    history: { id: invalidCountsId, saved: true },
    counts: { ...validRun.counts, created: validRun.counts.created + 1 }
  }
  await writeFile(path.join(fixture.storage, "set-runs", invalidCountsId + ".json"), JSON.stringify(invalidCountsReport))
  const absolutePathErrorId = "d".repeat(24)
  const absolutePathErrorReport = {
    ...validRun,
    runId: absolutePathErrorId,
    history: { id: absolutePathErrorId, saved: true },
    counts: { sources: 1, created: 0, failed: 1, skipped: 0 },
    results: [{ source: "project", label: "Project", status: "failed", error: "Could not read C:\\Users\\User\\private.txt" }]
  }
  await writeFile(path.join(fixture.storage, "set-runs", absolutePathErrorId + ".json"), JSON.stringify(absolutePathErrorReport))
  await writeFile(path.join(fixture.storage, "set-runs", "unsafe-name.json"), "{}")

  const listing = await responseJson(await fetch(app.url + "/api/set-runs"))
  assert.equal(listing.runs.filter(row => row.history?.saved === true).length, 1)
  assert.equal(listing.runs.filter(row => row.status === "corrupt").length, 4)
  assert.equal(listing.runs.some(row => row.id === null && row.status === "corrupt"), true)
  assert.equal(listing.runs.some(row => row.id === mismatchedId && row.status === "corrupt"), true)
  assert.equal(listing.runs.some(row => row.id === invalidCountsId && row.status === "corrupt"), true)
  assert.equal(listing.runs.some(row => row.id === absolutePathErrorId && row.status === "corrupt"), true)

  const detail = await rawRequest(app, "/api/set-runs/" + mismatchedId)
  assert.equal(detail.status, 409)
  assert.match(detail.body.toString("utf8"), /corrupt|invalid|match/u)
  const download = await rawRequest(app, "/api/set-runs/" + mismatchedId + "/download")
  assert.equal(download.status, 409)
  assert.equal((await rawRequest(app, "/api/set-runs/" + invalidCountsId)).status, 409)
  assert.equal((await rawRequest(app, "/api/set-runs/" + absolutePathErrorId)).status, 409)
  assert.equal((await rawRequest(app, "/api/set-runs/not-an-id")).status, 400)
})

test("history storage junctions are rejected at startup", async t => {
  const fixture = await makeFixture()
  const target = path.join(fixture.root, "history-target")
  await mkdir(target)
  await symlink(target, path.join(fixture.storage, "set-runs"), "junction")
  await assert.rejects(
    createWorkbench({ workspace: fixture.workspace, storage: fixture.storage, port: 0 }),
    /regular folders without links|could not be checked safely|not a regular folder/u
  )
})

test("history persistence failure is reported while created archives remain registered", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "project/value.txt", "preserve this backup\n")
  const { app } = await startApp(t, fixture)
  const created = await responseJson(await post(app, "/api/sets", sourceSet("Persistence failure", [["project", "Project"]])))
  const plan = await responseJson(await post(app, "/api/sets/" + created.set.id + "/preview", {}))

  const historyDirectory = path.join(fixture.storage, "set-runs")
  await rename(historyDirectory, path.join(fixture.storage, "set-runs-preserved"))
  await writeFile(historyDirectory, "sentinel")

  const report = await responseJson(await post(app, "/api/sets/" + created.set.id + "/run", { planId: plan.planId }))
  assert.equal(report.history.saved, false)
  assert.equal(report.history.id, report.runId)
  assert.match(report.history.error, /history report could not be saved safely/u)
  assert.equal(report.counts.created, 1)
  assert.equal(report.results[0].status, "created")
  assert.equal((await responseJson(await fetch(app.url + "/api/state"))).backups.length, 1)
  assert.equal((await readdir(path.join(fixture.storage, "archives"))).length, 1)
})
