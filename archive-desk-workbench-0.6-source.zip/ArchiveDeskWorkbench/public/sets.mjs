import { mountRunHistory } from './history.mjs'

const $ = id => document.getElementById(id)
const ID = /^[a-f0-9]{24}$/
function node(tag, className, text) {
  const el = document.createElement(tag)
  if (className) el.className = className
  if (text !== undefined) el.textContent = String(text)
  return el
}
function size(n) {
  if (!Number.isFinite(n)) return 'Unknown'
  return n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(1)} KiB` : `${(n / 1048576).toFixed(1)} MiB`
}
function when(value) {
  const d = new Date(value)
  return Number.isNaN(d.valueOf()) ? 'Unknown time' : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(d)
}
export function mountBackupSets({ request, operation, loadState, notify, selectBackup }) {
  const history = mountRunHistory({ request, operation, notify, selectBackup })
  let sets = []
  let selectedId = null
  let dirty = false
  let busy = false
  let plan = null
  let report = null
  let rowSerial = 0
  const selected = () => sets.find(item => item.id === selectedId)
  const rows = () => [...$('set-sources').children]
  const sourceValues = () => rows().map(row => ({ source: row.querySelector('[data-field="source"]').value.trim(), label: row.querySelector('[data-field="label"]').value.trim() }))
  function clearPlan() {
    plan = null
    $('set-plan').hidden = true
    $('set-plan-rows').replaceChildren()
    $('run-set').disabled = true
  }
  function clearReport() {
    report = null
    $('set-run-report').hidden = true
    $('set-run-rows').replaceChildren()
    $('download-set-report').disabled = true
    $('open-saved-set-report').disabled = true
    $('set-run-storage-note').textContent = ''
  }
  function controls() {
    $('new-set').disabled = busy || sets.length >= 12
    $('add-set-source').disabled = busy || rows().length >= 8
    $('save-set').disabled = busy
    $('preview-set').disabled = busy || !selected() || dirty
    $('run-set').disabled = busy || !plan || !plan.counts.ready || Date.parse(plan.expiresAt) <= Date.now()
    $('download-set-report').disabled = busy || !report
    $('open-saved-set-report').disabled = busy || report?.history?.saved !== true
    for (const field of $('set-form').querySelectorAll('input')) field.disabled = busy
    for (const button of $('set-list').querySelectorAll('button')) button.disabled = busy
    for (const button of $('set-sources').querySelectorAll('button')) button.disabled = busy || rows().length <= 1
    $('set-save-hint').textContent = dirty ? 'Folder list changed. Save it, then review a fresh plan.' : selected() ? 'Review checks the current files. It creates no archives.' : 'Save the folder list before reviewing it. Saving a set creates no backups.'
  }
  function edited() {
    dirty = true
    clearPlan()
    clearReport()
    controls()
  }
  function addRow(value = { source: '', label: '' }) {
    if (rows().length >= 8) return
    const row = node('fieldset', 'set-source-row')
    const serial = ++rowSerial
    row.append(node('legend', '', `Folder ${rows().length + 1}`))
    for (const [field, title, placeholder, max] of [['label', 'Project label', 'Website source', 80], ['source', 'Relative folder', 'website/src', 220]]) {
      const group = node('div', 'set-input-group')
      const label = node('label', '', title)
      const input = node('input')
      input.id = `set-source-${serial}-${field}`
      input.dataset.field = field
      input.value = value[field]
      input.required = true
      input.maxLength = max
      input.autocomplete = 'off'
      input.placeholder = placeholder
      if (field === 'source') input.spellcheck = false
      label.htmlFor = input.id
      input.addEventListener('input', edited)
      group.append(label, input)
      row.append(group)
    }
    const remove = node('button', 'button subtle remove-set-source', 'Remove folder')
    remove.type = 'button'
    remove.addEventListener('click', () => {
      if (busy || rows().length <= 1) return
      row.remove()
      rows().forEach((item, i) => { item.querySelector('legend').textContent = `Folder ${i + 1}` })
      edited()
    })
    row.append(remove)
    $('set-sources').append(row)
    controls()
  }
  function editor(item = null) {
    selectedId = item?.id || null
    dirty = false
    clearPlan()
    clearReport()
    $('set-label').value = item?.label || ''
    $('set-editor-title').textContent = item ? 'Edit this backup set' : 'Create a backup set'
    $('save-set').textContent = item ? 'Save changes' : 'Save set'
    $('set-sources').replaceChildren()
    for (const source of item?.sources || [{ source: '', label: '' }]) addRow(source)
    renderList()
    controls()
  }
  function renderList() {
    $('sets-count').textContent = `${sets.length} ${sets.length === 1 ? 'set' : 'sets'}`
    $('set-list').replaceChildren()
    if (!sets.length) $('set-list').append(node('p', 'muted', 'Group the folders you usually back up together.'))
    for (const item of sets) {
      const button = node('button', `set-item${selectedId === item.id ? ' selected' : ''}`)
      button.type = 'button'
      button.setAttribute('aria-pressed', String(selectedId === item.id))
      button.append(node('strong', '', item.label), node('span', 'muted', `${item.sources.length} ${item.sources.length === 1 ? 'folder' : 'folders'}`))
      button.addEventListener('click', () => { if (!busy) editor(item) })
      $('set-list').append(button)
    }
  }
  async function load() {
    clearPlan()
    clearReport()
    const result = await request('/api/sets')
    if (result.format !== 'archive-desk-backup-sets' || result.version !== 1 || !Array.isArray(result.sets) || result.sets.some(item => !ID.test(item.id) || !Array.isArray(item.sources))) throw new Error('The saved backup sets could not be read.')
    sets = result.sets
    if (selectedId && !selected()) editor()
    else if (!dirty && selected()) editor(selected())
    renderList()
    controls()
    await history.load()
  }
  function resultCard(result, kind) {
    const good = result.status === (kind === 'plan' ? 'ready' : 'created')
    const article = node('article', `set-result-card${good ? '' : ' set-result-failed'}`)
    const heading = node('div', 'set-result-heading')
    heading.append(node('strong', '', result.label), node('span', `set-status ${good ? 'ready' : 'failed'}`, result.status === 'ready' ? 'Ready to back up' : result.status === 'created' ? 'Saved and verified' : result.status === 'skipped' ? 'Skipped' : 'Failed'))
    article.append(heading, node('p', 'mono source-path', result.source))
    if (result.error) article.append(node('p', 'set-error', result.error))
    if (result.status === 'ready') {
      const detail = node('details', 'set-file-detail')
      detail.append(node('summary', '', `${result.files.length} included files, ${size(result.totalBytes)}`))
      const list = node('ul', 'set-file-inventory')
      for (const file of result.files) {
        const row = node('li')
        row.append(node('strong', 'mono', file.path), node('span', '', size(file.bytes)), node('code', '', file.sha256))
        list.append(row)
      }
      detail.append(list)
      article.append(detail)
      if (result.skippedPaths?.length) {
        const skipped = node('details', 'set-file-detail')
        const list = node('ul', 'set-skipped')
        skipped.append(node('summary', '', `${result.skippedPaths.length} excluded ${result.skippedPaths.length === 1 ? 'path' : 'paths'}`))
        for (const item of result.skippedPaths) list.append(node('li', 'mono', typeof item === 'string' ? item : `${item.path}: ${item.reason}`))
        skipped.append(list)
        article.append(skipped)
      }
    }
    if (result.status === 'created' && result.backup && ID.test(result.backup.id)) {
      article.append(node('p', '', `${result.backup.files} files, ${size(result.backup.totalBytes)} of source data.`), node('code', 'set-archive-hash', result.backup.sha256))
      const button = node('button', 'button secondary', 'Open saved backup')
      button.type = 'button'
      button.addEventListener('click', () => selectBackup(result.backup.id))
      article.append(button)
    }
    return article
  }
  $('set-label').addEventListener('input', edited)
  $('add-set-source').addEventListener('click', () => { addRow(); edited() })
  $('new-set').addEventListener('click', () => { if (!busy && sets.length < 12) { editor(); $('set-label').focus() } })
  $('set-form').addEventListener('submit', event => {
    event.preventDefault()
    operation('Saving the folder list. No backups are being created.', async () => {
      const payload = { label: $('set-label').value.trim(), sources: sourceValues() }
      const result = await request(selectedId ? `/api/sets/${selectedId}` : '/api/sets', payload)
      if (!result.set || !ID.test(result.set.id)) throw new Error('The local server did not return the saved backup set.')
      selectedId = result.set.id
      dirty = false
      await load()
      notify('Backup set saved. Review its current files before creating copies.')
    })
  })
  $('preview-set').addEventListener('click', () => {
    if (!selected() || dirty) return
    operation('Checking each folder and its included file hashes.', async () => {
      clearPlan()
      clearReport()
      const result = await request(`/api/sets/${selectedId}/preview`, {})
      if (result.format !== 'archive-desk-backup-set-plan' || result.version !== 1 || result.set?.id !== selectedId || !result.planId || !Array.isArray(result.results) || !result.counts || result.results.length !== result.counts.sources || !Number.isFinite(Date.parse(result.expiresAt))) throw new Error('The backup plan did not return a complete folder review.')
      plan = result
      $('set-plan-title').textContent = `Review ${result.set.label}`
      $('set-plan-summary').textContent = `${result.counts.ready} ready, ${result.counts.failed} failed. ${result.counts.files} included files, ${size(result.counts.totalBytes)} of source data. No archives created.`
      $('set-plan-rows').replaceChildren(...result.results.map(row => resultCard(row, 'plan')))
      $('set-plan-expiry').textContent = `Reviewed ${when(result.plannedAt)}. This plan expires ${when(result.expiresAt)}. Editing the set requires a new review.`
      $('set-plan').hidden = false
      $('set-plan').focus()
      notify(result.counts.failed ? 'Some folders failed review. Inspect every row before backing up the ready sources.' : 'All folders are ready for review. No archives have been created yet.', result.counts.failed ? 'error' : '')
    })
  })
  $('run-set').addEventListener('click', () => {
    if (!plan || busy || dirty || !plan.counts.ready) return
    const checked = plan
    if (Date.parse(checked.expiresAt) <= Date.now()) { clearPlan(); controls(); return notify('This plan expired. Review the set again before creating copies.', 'error') }
    clearPlan()
    operation('Creating and verifying each ready source copy. Each folder has a separate result.', async () => {
      const result = await request(`/api/sets/${checked.set.id}/run`, { planId: checked.planId })
      if (result.format !== 'archive-desk-backup-set-run' || result.version !== 1 || !result.counts || !Array.isArray(result.results) || result.results.length !== result.counts.sources) throw new Error('The run report is incomplete. Refresh the library and inspect saved copies before retrying.')
      await loadState()
      report = result
      $('set-run-title').textContent = `${result.set.label} result`
      $('set-run-summary').textContent = `${result.counts.created} saved and verified, ${result.counts.failed} failed, ${result.counts.skipped} skipped. Finished ${when(result.finishedAt)}.`
      $('set-run-rows').replaceChildren(...result.results.map(row => resultCard(row, 'run')))
      const stored = result.history?.saved === true
      $('set-run-storage-note').textContent = stored ? 'This dated report is saved in Run history and can be reopened after refresh or restart.' : 'The backups have their recorded outcomes above, but this run report could not be saved. Download this result now. Do not repeat the backup just to save a report. ' + (result.history?.error || '')
      $('set-run-storage-note').className = 'history-storage-note' + (stored ? '' : ' history-error')
      $('set-run-report').hidden = false
      $('set-run-report').focus()
      const outcomes = result.counts.failed || result.counts.skipped ? 'The set run is only partly complete. Review the failed and skipped folders before retrying.' : 'Every source in this set was saved and verified.'
      notify(outcomes + (stored ? ' The dated report is saved in Run history.' : ' The run report was not saved. Download the displayed result before refreshing.'), result.counts.failed || result.counts.skipped || !stored ? 'error' : '')
    })
  })
  $('download-set-report').addEventListener('click', () => {
    if (!report || busy) return
    if (report.history?.saved === true) return operation('Reading the saved run report for download.', () => history.download(report))
    const href = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2) + '\n'], { type: 'application/json' }))
    const link = node('a')
    link.href = href
    link.download = `archive-desk-set-run-${report.finishedAt.replace(/[^0-9]/g, '')}.json`
    document.body.append(link)
    link.click()
    link.remove()
    setTimeout(() => URL.revokeObjectURL(href), 1000)
    notify('The exact dated run report was prepared. This download does not rerun any backups.')
  })
  $('open-saved-set-report').addEventListener('click', () => {
    if (!report?.history?.saved || busy) return
    operation('Opening the saved report. No archives are being checked again.', () => history.open(report.history.id))
  })
  editor()
  return { load, setBusy(value) { busy = value; controls(); history.setBusy(value) } }
}
