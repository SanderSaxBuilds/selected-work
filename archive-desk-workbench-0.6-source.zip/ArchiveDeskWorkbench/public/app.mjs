import { mountBackupSets } from './sets.mjs'
const $ = id => document.getElementById(id)
const ID = /^[a-f0-9]{24}$/
let state = { backups: [], activity: [] }
let selectedId = null
let previewSource = null
let busy = false
let importPreviewFile = null
let restorePlan = null
let restoreBackupId = null
let libraryReport = null
let backupSets = null

function node(tag, className, text) {
  const element = document.createElement(tag)
  if (className) element.className = className
  if (text !== undefined) element.textContent = String(text)
  return element
}
function bytes(value) {
  if (!Number.isFinite(value)) return 'Unknown'
  if (value < 1024) return `${value} B`
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KiB`
  return `${(value / 1024 / 1024).toFixed(1)} MiB`
}
function date(value) {
  if (!value) return 'Not recorded'
  const parsed = new Date(value)
  return Number.isNaN(parsed.valueOf()) ? 'Not recorded' : new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(parsed)
}
function selected() { return state.backups.find(item => item.id === selectedId) }
function notify(text, mode = '') {
  $('message').textContent = text
  $('message').className = `message ${mode}`
  $('message').hidden = false
}
function setBusy(value) {
  busy = value
  for (const button of document.querySelectorAll('button')) button.disabled = value
  $('backup-button').disabled = value || previewSource === null || previewSource !== $('source').value.trim()
  $('import-file').disabled = value
  $('import-label').disabled = value
  $('import-preview-button').disabled = value || !$('import-file').files.length
  $('import-save-button').disabled = value || importPreviewFile === null || importPreviewFile !== $('import-file').files[0]
  $('restore-name').disabled = value
  $('confirm-restore').disabled = value || !currentRestorePlan()
  $('download-library-check').disabled = value || libraryReport === null
  backupSets?.setBusy(value)
  document.body.setAttribute('aria-busy', String(value))
}
async function request(route, data) {
  const options = data === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Workbench': '1' }, body: JSON.stringify(data) }
  const response = await fetch(route, options)
  let result
  try { result = await response.json() } catch { throw new Error('The local server returned an unreadable response. Check that it is still running.') }
  if (!response.ok) throw new Error(result.error || result.message || `Operation failed with status ${response.status}.`)
  return result
}
async function archiveRequest(route, file) {
  if (!file || file.size === 0 || file.size > 52 * 1024 * 1024) throw new Error('Choose a nonempty Archive Desk ZIP no larger than 52 MiB.')
  const response = await fetch(route, { method: 'POST', headers: { 'Content-Type': 'application/zip', 'X-Workbench': '1' }, body: file })
  let result
  try { result = await response.json() } catch { throw new Error('The archive response could not be read. Check that the local server is still running.') }
  if (!response.ok) throw new Error(result.error || `Archive operation failed with status ${response.status}.`)
  return result
}
function clearImportPreview() {
  importPreviewFile = null
  $('import-preview').hidden = true
  $('import-empty').hidden = false
  $('import-files').replaceChildren()
  $('import-sha').textContent = ''
  $('import-save-button').disabled = true
}
async function inspectArchive() {
  const file = $('import-file').files[0]
  clearImportPreview()
  const result = await archiveRequest('/api/import/preview', file)
  if ($('import-file').files[0] !== file) throw new Error('The selected file changed. Inspect the new selection before importing it.')
  if (!Array.isArray(result.files) || !result.counts || !/^[a-f0-9]{64}$/.test(result.archiveSha256)) throw new Error('The archive inspection did not return a valid file inventory.')
  importPreviewFile = file
  $('import-count').textContent = `${result.counts.files} verified files`
  $('import-size').textContent = `${bytes(result.counts.totalBytes)} of file data`
  $('import-created').textContent = `Archive created ${date(result.createdAt)}. ZIP size ${bytes(result.archiveBytes)}.`
  $('import-files').replaceChildren(fileRows(result.files))
  $('import-sha').textContent = result.archiveSha256
  $('import-empty').hidden = true
  $('import-preview').hidden = false
  notify(`Inspection passed for ${result.counts.files} files. Nothing has been added to the library yet.`)
}
async function operation(message, callback) {
  if (busy) return
  setBusy(true)
  $('result-section').hidden = true
  notify(message, 'busy')
  try { await callback() } catch (error) {
    notify(error.message || 'The operation could not be completed.', 'error')
    $('message').scrollIntoView({ behavior: 'smooth', block: 'center' })
  } finally { setBusy(false) }
}
function fileRows(files) {
  const fragment = document.createDocumentFragment()
  for (const file of files) {
    const row = node('div', 'file-row')
    const name = node('span', 'file-path')
    name.append(node('span', 'file-icon', '▤'), node('span', '', file.path))
    row.append(name, node('span', 'mono', bytes(file.bytes)))
    fragment.append(row)
  }
  return fragment
}
async function loadState() {
  clearLibraryReport()
  const result = await request('/api/state')
  if (!Array.isArray(result.backups)) throw new Error('The local backup library could not be read.')
  state = result
  state.backups = state.backups.filter(item => ID.test(item.id))
  if (selectedId && !selected()) selectedId = null
  $('workspace-name').textContent = result.workspaceLabel || 'Project workspace'
  $('workspace-path').textContent = result.workspacePath || 'Not recorded'
  $('storage-path').textContent = result.storagePath || 'Not recorded'
  $('version').textContent = result.version || '0.6.0-candidate.1'
  $('stat-backups').textContent = state.backups.length
  $('library-count').textContent = `${state.backups.length} ${state.backups.length === 1 ? 'backup' : 'backups'}`
  const latest = state.backups.filter(item => item.verifiedAt).sort((a, b) => b.verifiedAt.localeCompare(a.verifiedAt))[0]
  $('stat-check').textContent = latest ? 'Recorded' : 'Not yet'
  $('stat-check-detail').textContent = latest ? date(latest.verifiedAt) : 'Checks use saved archive bytes'
  $('connection').className = 'connection'
  $('connection').replaceChildren(node('span', 'status-dot'), document.createTextNode('Local connection'))
  renderLibrary()
  renderDetail()
  renderActivity()
  await backupSets?.load()
}
async function preview() {
  const source = $('source').value.trim()
  invalidatePreview()
  const result = await request(`/api/preview?source=${encodeURIComponent(source)}`)
  if (!Array.isArray(result.files)) throw new Error('The source inventory could not be read.')
  previewSource = source
  $('stat-files').textContent = result.files.length
  $('stat-source').textContent = source === '.' ? 'Workspace root selected' : source
  $('stat-size').textContent = bytes(result.totalBytes)
  $('preview-title').textContent = `${result.files.length} files included`
  $('preview-size').textContent = bytes(result.totalBytes)
  $('source-files').replaceChildren(fileRows(result.files))
  if (!result.files.length) $('source-files').append(node('div', 'empty small', 'This folder has no included files.'))
  const skipped = result.skippedPaths || []
  $('excluded-details').hidden = skipped.length === 0
  $('excluded-summary').textContent = `${skipped.length} excluded ${skipped.length === 1 ? 'path' : 'paths'}`
  $('excluded-list').replaceChildren(...skipped.map(item => node('li', 'mono', typeof item === 'string' ? item : item.path || String(item))))
  notify(`Source preview ready. ${result.files.length} files will be included. This preview does not create a backup.`)
}
function invalidatePreview() {
  previewSource = null
  $('backup-button').disabled = true
  $('stat-files').textContent = '—'
  $('stat-size').textContent = '—'
  $('stat-source').textContent = 'Preview the current folder'
  $('preview-title').textContent = 'Source preview required'
  $('preview-size').textContent = ''
  $('source-files').replaceChildren(node('div', 'empty small', 'Preview the current source folder to see which files will be included.'))
  $('excluded-details').hidden = true
}
function renderLibrary() {
  const query = $('backup-search').value.toLocaleLowerCase()
  const backups = state.backups.filter(item => `${item.label} ${item.source}`.toLocaleLowerCase().includes(query))
  const list = $('backup-list')
  list.replaceChildren()
  if (!backups.length) {
    const empty = node('div', 'empty')
    empty.append(node('span', 'empty-icon', '▱'), node('h3', '', query ? 'No matching backups' : 'Your first restore point starts here.'), node('p', '', query ? 'Try a different label or folder name.' : 'Create a backup or run the sample workflow.'))
    list.append(empty)
    return
  }
  for (const item of backups) {
    const button = node('button', `backup-item${item.id === selectedId ? ' selected' : ''}`)
    button.type = 'button'
    button.setAttribute('aria-pressed', String(item.id === selectedId))
    const row = node('span', 'row')
    const freshCheck = libraryReport?.results.find(result => result.id === item.id)
    row.append(node('strong', '', item.label || 'Project backup'), node('span', `check-label${freshCheck?.status === 'failed' ? ' audit-failed' : ''}`, freshCheck ? freshCheck.status === 'passed' ? 'Passed this check' : 'Check failed' : item.verifiedAt ? 'Previously checked' : 'Not checked'))
    button.append(row, node('p', '', `${date(item.createdAt)} · ${item.files} files · ${bytes(item.totalBytes)}`), node('div', 'source-path mono', item.demo ? 'Sample project' : item.origin === 'import' ? 'Imported archive' : item.source))
    button.addEventListener('click', () => { if (selectedId !== item.id) invalidateRestorePlan(); selectedId = item.id; renderLibrary(); renderDetail() })
    button.disabled = busy
    list.append(button)
  }
}
function action(label, callback, primary = false) {
  const button = node('button', `button ${primary ? 'primary' : 'secondary'}`, label)
  button.type = 'button'
  button.addEventListener('click', callback)
  button.disabled = busy
  return button
}
function renderDetail() {
  const item = selected()
  if (!item) return
  const detail = $('backup-detail')
  const heading = node('div', 'eyebrow', item.demo ? 'Sample project backup' : item.origin === 'import' ? 'Imported archive' : 'Saved project backup')
  const fingerprint = node('div', 'fingerprint')
  fingerprint.append(node('span', '', 'Archive SHA-256'), node('code', '', item.sha256))
  const actions = node('div', 'actions')
  actions.append(action('Verify files', verify), action('Compare changes', compare), action('Review recovery', showRestore, true), action('Download verification JSON', downloadVerification))
  const download = node('a', 'button secondary', 'Download ZIP')
  download.href = `/api/backups/${item.id}/download`
  download.download = `ArchiveDesk_${item.id}.zip`
  actions.append(download)
  detail.replaceChildren(heading, node('h3', '', item.label || 'Project backup'), node('p', 'detail-meta', `${item.files} files · ${bytes(item.totalBytes)} file data · ${bytes(item.archiveBytes)} archive`), node('p', 'detail-meta', `Archive created ${date(item.createdAt)}. Last verified ${date(item.verifiedAt)}.`), fingerprint, actions, node('p', 'detail-note', item.demo ? 'Comparison uses the sample project created by this workflow. Recovery always uses a new folder in the backup library.' : item.origin === 'import' ? 'This archive was imported without an original source folder. Compare changes uses the project folder currently entered above. Recovery uses a new folder in the backup library.' : 'Comparison uses the project folder currently entered above. Recovery always uses a new folder in the backup library.'))
}
function renderActivity() {
  const items = Array.isArray(state.activity) ? state.activity : []
  $('activity').replaceChildren()
  for (const item of items.slice(0, 8)) {
    const li = node('li', '')
    li.append(node('strong', '', item.title || item.action || item.type || 'Operation recorded'), node('span', '', item.message || item.detail || item.label || ''), node('br'), node('time', '', date(item.at || item.atUtc || item.createdAt || item.timestamp)))
    $('activity').append(li)
  }
  if (!items.length) $('activity').append(node('li', 'muted', 'No operations recorded yet.'))
}
function showResult(title, content) {
  $('result-title').textContent = title
  $('result-content').replaceChildren(...content)
  $('result-section').hidden = false
  $('result-section').focus({ preventScroll: true })
  $('result-section').scrollIntoView({ behavior: 'smooth', block: 'nearest' })
}
function table(headers, rows) {
  const wrap = node('div', 'result-table-wrap')
  const result = node('table', 'result-table')
  const head = node('thead')
  const tr = node('tr')
  for (const name of headers) tr.append(node('th', '', name))
  head.append(tr)
  const body = node('tbody')
  for (const values of rows) {
    const row = node('tr')
    for (const value of values) {
      const td = node('td')
      if (value instanceof Node) td.append(value)
      else td.textContent = value
      row.append(td)
    }
    body.append(row)
  }
  result.append(head, body)
  wrap.append(result)
  return wrap
}
function comparisonContent(result) {
  const stats = node('div', 'result-stats')
  for (const status of ['added', 'removed', 'changed', 'unchanged']) {
    const card = node('div', 'result-stat')
    card.append(node('strong', '', result.counts[status]), document.createTextNode(status[0].toUpperCase() + status.slice(1)))
    stats.append(card)
  }
  const rows = result.rows.map(row => [row.path, node('span', `change ${row.status}`, row.status), row.beforeBytes === null ? '—' : bytes(row.beforeBytes), row.afterBytes === null ? '—' : bytes(row.afterBytes)])
  return [node('p', 'result-summary', 'Comparison is against the saved baseline archive. The source and backup stay unchanged.'), stats, table(['File', 'Change', 'Backup', 'Current'], rows), node('p', 'footnote mono', `Baseline SHA-256: ${result.baselineArchiveSha256}`)]
}
async function verify() {
  const item = selected()
  if (!item) return
  await operation('Reading the saved ZIP and checking its file manifest.', async () => {
    const result = await request(`/api/backups/${item.id}/verify`, {})
    await loadState()
    showResult('Saved backup verified', [node('p', 'result-summary', result.message || 'Every saved file matched its manifest.'), table(['File', 'Size', 'SHA-256'], result.files.map(file => [file.path, bytes(file.bytes), node('code', '', file.sha256)]))])
    notify(`Verification passed for ${result.files.length} files.`)
  })
}
async function compare() {
  const item = selected()
  if (!item) return
  await operation('Comparing current file contents against the saved backup.', async () => {
    const result = await request(`/api/backups/${item.id}/compare`, { source: $('source').value.trim() })
    const content = comparisonContent(result)
    const report = node('a', 'button secondary', 'Download comparison report')
    report.href = `/api/backups/${item.id}/report`
    report.download = 'archive-desk-comparison.json'
    content.push(report)
    await loadState()
    showResult('What changed since this backup', content)
    notify(`Comparison complete. ${result.counts.changed} changed, ${result.counts.added} added and ${result.counts.removed} removed files.`)
  })
}
function showRestore() {
  const item = selected()
  if (!item || busy) return
  invalidateRestorePlan()
  restoreBackupId = item.id
  $('restore-name').value = `recovered-${item.id.slice(0, 8)}`
  $('restore-description').textContent = `Review the saved files from ${item.label} before recovering a copy. Building a plan does not create a folder or change your library.`
  $('restore-dialog').showModal()
}
function currentRestorePlan() {
  return restorePlan && restorePlan.backupId === selectedId && restorePlan.backupId === restoreBackupId && restorePlan.name === $('restore-name').value.trim()
}
function invalidateRestorePlan() {
  restorePlan = null
  $('restore-plan').hidden = true
  $('restore-plan').replaceChildren()
  $('restore-feedback').textContent = ''
  $('restore-feedback').hidden = true
  $('confirm-restore').disabled = true
}
async function restoreOperation(message, callback) {
  if (busy) return
  setBusy(true)
  $('restore-feedback').textContent = message
  $('restore-feedback').className = 'message busy'
  $('restore-feedback').hidden = false
  try { await callback() } catch (error) {
    invalidateRestorePlan()
    $('restore-feedback').textContent = error.message || 'Recovery could not be completed.'
    $('restore-feedback').className = 'message error'
    $('restore-feedback').hidden = false
  } finally { setBusy(false) }
}
async function planRestore() {
  const item = selected()
  if (!item || item.id !== restoreBackupId) return
  const name = $('restore-name').value.trim()
  invalidateRestorePlan()
  await restoreOperation('Checking the saved archive and recovery destination.', async () => {
    const plan = await request(`/api/backups/${item.id}/restore-plan`, { name })
    if (selectedId !== item.id || restoreBackupId !== item.id || $('restore-name').value.trim() !== name) throw new Error('The recovery selection changed. Review a new plan.')
    if (plan.backupId !== item.id || plan.name !== name || !/^[a-f0-9]{64}$/.test(plan.archiveSha256) || !Array.isArray(plan.files) || !plan.counts || plan.destination !== `restores/${name}`) throw new Error('The recovery plan was incomplete. No recovery was started.')
    restorePlan = plan
    const fingerprint = node('div', 'fingerprint')
    fingerprint.append(node('span', '', 'Checked archive SHA-256'), node('code', '', plan.archiveSha256))
    $('restore-plan').replaceChildren(node('h3', '', 'Review this recovery'), node('p', 'plan-count', `${plan.counts.files} files · ${bytes(plan.counts.totalBytes)} of file data`), node('div', 'destination', plan.destination), fingerprint, table(['File', 'Size', 'SHA-256'], plan.files.map(file => [file.path, bytes(file.bytes), node('code', '', file.sha256)])), node('p', 'footnote', 'This destination is inside your backup library. The plan is a snapshot. Recovery checks the archive again and refuses an existing folder. File contents and paths are restored, not original timestamps, permissions or empty folders.'))
    $('restore-plan').hidden = false
    $('restore-feedback').textContent = 'Plan ready. No folder or recovery files have been created.'
    $('restore-feedback').className = 'message'
  })
}
async function downloadVerification() {
  const item = selected()
  if (!item) return
  await operation('Rechecking saved bytes for the verification report.', async () => {
    const report = await request(`/api/backups/${item.id}/verification`)
    if (report.format !== 'archive-desk-verification' || report.backupId !== item.id || !Array.isArray(report.files) || !/^[a-f0-9]{64}$/.test(report.archiveSha256)) throw new Error('The server did not return a complete verification report.')
    const link = node('a')
    link.href = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2) + '\n'], { type: 'application/json' }))
    link.download = `ArchiveDesk_${item.id}_verification.json`
    document.body.append(link)
    link.click()
    link.remove()
    setTimeout(() => URL.revokeObjectURL(link.href), 1000)
    notify(`Fresh verification report prepared for ${report.files.length} files. Check your browser downloads. Your library is unchanged.`)
  })
}
function restoreContent(result) {
  return [node('p', 'result-summary', result.message || `${result.files} files recovered and verified. The original source was not changed.`), node('div', 'destination', result.destination), node('p', 'footnote', 'Open the destination above in your file manager. Paths and file contents were restored. Original timestamps, permissions and empty folders were not restored.')]
}
function clearLibraryReport() {
  libraryReport = null
  $('library-check-report').hidden = true
  $('library-check-rows').replaceChildren()
  $('library-check-empty').hidden = false
  $('download-library-check').disabled = true
}
function validLibraryReport(report) {
  if (report?.format !== 'archive-desk-library-check' || report.version !== 1 || !Array.isArray(report.results) || !Array.isArray(report.limits) || !report.counts || !Number.isFinite(Date.parse(report.checkedAt))) return false
  const { backups, passed, failed } = report.counts
  if (![backups, passed, failed].every(value => Number.isSafeInteger(value) && value >= 0) || backups !== report.results.length || passed + failed !== backups) return false
  const seen = new Set()
  for (const row of report.results) {
    if (!ID.test(row.id) || seen.has(row.id) || typeof row.label !== 'string' || !/^[a-f0-9]{64}$/.test(row.recordedArchiveSha256) || !['passed', 'failed'].includes(row.status)) return false
    seen.add(row.id)
    if (row.status === 'passed' && (row.archiveSha256 !== row.recordedArchiveSha256 || !Number.isSafeInteger(row.files) || row.files < 0 || !Number.isSafeInteger(row.totalBytes) || row.totalBytes < 0 || row.error !== null)) return false
    if (row.status === 'failed' && (typeof row.error !== 'string' || row.error.length === 0)) return false
  }
  return report.results.filter(row => row.status === 'passed').length === passed
}
async function checkLibrary() {
  await operation('Rereading every saved archive and checking its manifest. This may take a while.', async () => {
    clearLibraryReport()
    const report = await request('/api/library-check', {})
    if (!validLibraryReport(report)) throw new Error('The server did not return a complete library report. No passing result has been recorded.')
    libraryReport = report
    renderLibrary()
    const { backups, passed, failed } = report.counts
    $('library-check-summary').textContent = `${backups} checked, ${passed} passed, ${failed} failed. Checked ${date(report.checkedAt)}.`
    $('library-check-summary').className = `audit-summary${failed ? ' has-failures' : ''}`
    for (const row of report.results) {
      const article = node('article', `audit-row ${row.status}`)
      const heading = node('div', 'audit-row-heading')
      heading.append(node('h3', '', row.label), node('strong', `audit-status ${row.status}`, row.status === 'passed' ? 'Passed' : 'Failed'))
      article.append(heading)
      if (row.status === 'passed') article.append(node('p', 'detail-meta', `${row.files} files · ${bytes(row.totalBytes)} of file data`))
      else article.append(node('p', 'audit-error', row.error))
      const fingerprint = node('details', 'audit-fingerprint')
      fingerprint.append(node('summary', '', 'Archive fingerprints'), node('p', 'footnote', 'Recorded SHA-256'), node('code', '', row.recordedArchiveSha256))
      if (row.archiveSha256) fingerprint.append(node('p', 'footnote', 'Read during this check'), node('code', '', row.archiveSha256))
      article.append(fingerprint)
      $('library-check-rows').append(article)
    }
    if (!backups) $('library-check-rows').append(node('p', 'muted', 'The library has no saved backups. Nothing was verified.'))
    $('library-check-empty').hidden = true
    $('library-check-report').hidden = false
    $('library-check-report').focus({ preventScroll: true })
    notify(failed ? `Library check found ${failed} failed copies. Keep the originals and inspect the affected archives. No repair was attempted.` : backups ? `All ${backups} saved archives passed this check. Your library is unchanged.` : 'The library is empty. No archive was checked.')
  })
}
function downloadLibraryReport() {
  if (busy || !libraryReport) return
  const link = node('a')
  link.href = URL.createObjectURL(new Blob([JSON.stringify(libraryReport, null, 2) + '\n'], { type: 'application/json' }))
  link.download = 'ArchiveDesk_library_check.json'
  document.body.append(link)
  link.click()
  link.remove()
  setTimeout(() => URL.revokeObjectURL(link.href), 1000)
  notify(`Report from ${date(libraryReport.checkedAt)} prepared. Check your browser downloads. This is the same snapshot, not a new check.`)
}
$('check-library').addEventListener('click', checkLibrary)
$('download-library-check').addEventListener('click', downloadLibraryReport)
$('source-form').addEventListener('submit', event => { event.preventDefault(); operation('Reading the source inventory.', preview) })
$('source').addEventListener('input', invalidatePreview)
$('import-file').addEventListener('change', () => { clearImportPreview(); $('import-preview-button').disabled = busy || !$('import-file').files.length; notify('Inspect the selected archive before adding it to your library.') })
$('import-form').addEventListener('submit', event => { event.preventDefault(); operation('Reading the selected ZIP and checking its file manifest.', inspectArchive) })
$('import-save-button').addEventListener('click', () => {
  const file = $('import-file').files[0]
  if (!file || file !== importPreviewFile) return notify('Inspect the selected archive before adding it to your library.', 'error')
  const label = $('import-label').value.trim()
  operation('Copying the archive, then verifying the saved bytes.', async () => {
    const result = await archiveRequest(`/api/import${label ? `?label=${encodeURIComponent(label)}` : ''}`, file)
    selectedId = result.backup.id
    await loadState()
    clearImportPreview()
    $('import-file').value = ''
    notify(`Imported copy saved and verified. ${result.backup.files} files are ready for recovery. The selected ZIP is unchanged.`)
    $('library-section').scrollIntoView({ behavior: 'smooth', block: 'start' })
  })
})
$('backup-search').addEventListener('input', renderLibrary)
$('refresh').addEventListener('click', () => operation('Refreshing the local backup library.', async () => { await loadState(); notify('Backup library refreshed.') }))
$('backup-form').addEventListener('submit', event => {
  event.preventDefault()
  if (previewSource === null || previewSource !== $('source').value.trim()) return notify('Preview the current source folder before creating a backup.', 'error')
  operation('Creating the archive, then reopening and verifying its saved bytes.', async () => {
    const result = await request('/api/backups', { source: previewSource, label: $('backup-label').value.trim() })
    const backup = result.backup || result
    selectedId = backup.id
    await loadState()
    notify(`Backup saved and verified. ${backup.files} files, ${bytes(backup.totalBytes)} of source data.`)
    $('library-section').scrollIntoView({ behavior: 'smooth', block: 'start' })
  })
})
$('demo-button').addEventListener('click', () => operation('Running the sample backup, change comparison and verified recovery.', async () => {
  const result = await request('/api/demo', {})
  selectedId = result.backup.id
  await loadState()
  const steps = node('ol', 'step-list')
  for (const step of result.steps) {
    const li = node('li')
    li.append(node('strong', '', `✓ ${step.title}`), node('span', '', step.detail))
    steps.append(li)
  }
  showResult('Sample project recovered', [node('p', 'result-summary', 'The sample workflow used real local files, a saved ZIP and a separate recovery folder. Your configured project was not changed.'), steps, ...comparisonContent(result.comparison), ...restoreContent(result.restore)])
  notify('Sample workflow complete. Backup, comparison and recovery passed.')
}))
$('cancel-restore').addEventListener('click', () => $('restore-dialog').close())
$('restore-dialog').addEventListener('cancel', event => { if (busy) event.preventDefault() })
$('restore-dialog').addEventListener('close', () => { invalidateRestorePlan(); restoreBackupId = null })
$('restore-name').addEventListener('input', invalidateRestorePlan)
$('restore-form').addEventListener('submit', event => {
  event.preventDefault()
  planRestore()
})
$('confirm-restore').addEventListener('click', () => {
  const item = selected()
  if (!item || !currentRestorePlan()) return
  const plan = restorePlan
  restoreOperation('Restoring into a new folder and checking every recovered file.', async () => {
    const result = await request(`/api/backups/${item.id}/restore`, { name: plan.name, archiveSha256: plan.archiveSha256 })
    $('restore-dialog').close()
    await loadState()
    showResult('Recovery completed and verified', restoreContent(result))
    notify(`Recovery passed. ${result.files} files were checked against the saved manifest.`)
  })
})
$('close-result').addEventListener('click', () => { $('result-section').hidden = true })
backupSets = mountBackupSets({ request, operation, loadState, notify, selectBackup: id => {
  if (!ID.test(id) || !state.backups.some(item => item.id === id)) return false
  selectedId = id
  renderLibrary()
  renderDetail()
  $('library-section').scrollIntoView({ behavior: 'smooth', block: 'start' })
  return true
} })
await operation('Connecting to the local workspace.', async () => { await loadState(); await preview() })
