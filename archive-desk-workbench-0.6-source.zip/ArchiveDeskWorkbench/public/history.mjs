const $ = id => document.getElementById(id)
const ID = /^[a-f0-9]{24}$/

function node(tag, className, text) {
  const item = document.createElement(tag)
  if (className) item.className = className
  if (text !== undefined) item.textContent = String(text)
  return item
}

function when(value) {
  const date = new Date(value)
  return Number.isNaN(date.valueOf()) ? 'Unknown time' : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'medium' }).format(date)
}

function summary(counts) {
  return counts.created + ' created, ' + counts.failed + ' failed, ' + counts.skipped + ' skipped'
}

function isSaved(item) {
  return item && ID.test(item.id) && item.history?.saved === true && item.status !== 'corrupt'
}

function assertRun(run, id) {
  if (!run || run.format !== 'archive-desk-backup-set-run' || run.version !== 1 ||
      run.runId !== id || run.history?.id !== id || run.history.saved !== true ||
      !run.set?.label || !Number.isFinite(Date.parse(run.finishedAt)) ||
      !Array.isArray(run.results) || run.results.length !== run.counts?.sources) {
    throw new Error('The saved run report could not be read completely.')
  }
  return run
}

export function mountRunHistory({ request, operation, notify, selectBackup }) {
  let records = []
  let selectedId = null
  let selectedRun = null
  let busy = false
  let available = false

  function controls() {
    $('refresh-run-history').disabled = busy
    $('history-search').disabled = busy || !available
    $('download-history-report').disabled = busy || !selectedRun
    for (const button of $('history-list').querySelectorAll('button')) button.disabled = busy
    for (const button of $('history-result-rows').querySelectorAll('button')) button.disabled = busy
  }

  function status(text, failed = false) {
    $('history-status').textContent = text
    $('history-status').className = 'history-status' + (failed ? ' history-error' : '')
  }

  function clearDetail() {
    selectedRun = null
    $('history-detail').hidden = true
    $('history-empty').hidden = false
    $('history-result-rows').replaceChildren()
    controls()
  }

  function renderList() {
    const query = $('history-search').value.trim().toLocaleLowerCase()
    const saved = records.filter(isSaved)
    const damaged = records.length - saved.length
    $('history-count').textContent = saved.length + ' saved ' + (saved.length === 1 ? 'run' : 'runs')
    $('history-list').replaceChildren()
    let shown = 0
    for (const item of records) {
      const valid = isSaved(item)
      const label = valid ? item.set.label : 'Unreadable saved report'
      const detail = valid ? when(item.finishedAt) + '. ' + summary(item.counts) + '.' : item.error || 'The report failed validation and has been preserved.'
      if (query && !(label + ' ' + detail + ' ' + (item.id || '')).toLocaleLowerCase().includes(query)) continue
      shown += 1
      if (!valid) {
        const article = node('article', 'history-item history-corrupt')
        article.append(node('strong', '', label), node('p', '', detail))
        if (item.id) article.append(node('code', '', item.id))
        $('history-list').append(article)
        continue
      }
      const button = node('button', 'history-item' + (item.id === selectedId ? ' selected' : ''))
      button.type = 'button'
      button.setAttribute('aria-pressed', String(item.id === selectedId))
      button.append(node('strong', '', label), node('time', '', when(item.finishedAt)), node('span', '', summary(item.counts)))
      button.addEventListener('click', () => operation('Opening the saved run report. No archives are being checked again.', () => open(item.id)))
      $('history-list').append(button)
    }
    if (!shown) $('history-list').append(node('p', 'history-list-empty', query ? 'No saved reports match this search.' : 'No completed set runs have been saved in this library yet.'))
    if (damaged) status(damaged + ' unreadable ' + (damaged === 1 ? 'report is' : 'reports are') + ' preserved below. Intact reports can still be opened.', true)
    controls()
  }

  function resultCard(result) {
    const article = node('article', 'history-result' + (result.status === 'created' ? '' : ' history-result-failed'))
    const heading = node('div', 'history-result-heading')
    const words = result.status === 'created' ? 'Created during this run' : result.status === 'skipped' ? 'Skipped during this run' : 'Failed during this run'
    heading.append(node('strong', '', result.label), node('span', 'history-result-state', words))
    article.append(heading, node('p', 'mono history-source', result.source))
    if (result.error) article.append(node('p', 'history-error', result.error))
    if (result.status === 'created' && result.backup && ID.test(result.backup.id)) {
      article.append(node('p', '', result.backup.files + ' files. Recorded archive SHA-256:'), node('code', 'history-hash', result.backup.sha256))
      const button = node('button', 'button secondary', 'Open current library entry')
      button.type = 'button'
      button.addEventListener('click', () => {
        if (selectBackup(result.backup.id) === false) notify('This archive no longer has an entry in the current library. The historical report is unchanged.', 'error')
      })
      article.append(button)
    }
    return article
  }

  async function open(id, focus = true) {
    if (!ID.test(id)) throw new Error('Choose a valid saved run.')
    clearDetail()
    selectedId = id
    renderList()
    try {
      const result = await request('/api/set-runs/' + id)
      selectedRun = assertRun(result.run, id)
      $('history-detail-title').textContent = selectedRun.set.label
      $('history-detail-time').textContent = 'Finished ' + when(selectedRun.finishedAt) + '. Started ' + when(selectedRun.startedAt) + '.'
      $('history-detail-summary').textContent = summary(selectedRun.counts) + '. These are the results recorded at that time.'
      $('history-run-id').textContent = selectedRun.runId
      $('history-result-rows').replaceChildren(...selectedRun.results.map(resultCard))
      $('history-empty').hidden = true
      $('history-detail').hidden = false
      const unreadable = records.filter(item => !isSaved(item)).length
      status('Historical report opened. No archives were checked again.' + (unreadable ? ' ' + unreadable + ' unreadable ' + (unreadable === 1 ? 'record remains' : 'records remain') + ' preserved in the list.' : ''), unreadable > 0)
      controls()
      if (focus) {
        $('history-detail').focus()
        notify('Saved run report opened. No archives were checked again.')
      }
      return true
    } catch (error) {
      selectedId = null
      clearDetail()
      renderList()
      status(error.message || 'This report could not be read. It has not been changed.', true)
      throw error
    }
  }

  async function load() {
    const oldSelection = selectedId
    clearDetail()
    available = false
    records = []
    renderList()
    status('Reading saved report records.')
    try {
      const result = await request('/api/set-runs')
      if (result.format !== 'archive-desk-backup-set-runs' || result.version !== 1 || !Array.isArray(result.runs)) throw new Error('Run history returned an unreadable list.')
      records = result.runs
      available = true
      selectedId = oldSelection && records.some(item => isSaved(item) && item.id === oldSelection) ? oldSelection : null
      status(records.length ? 'Choose a dated report to review its recorded outcomes.' : 'A completed backup-set run will appear here automatically.')
      renderList()
      if (selectedId) {
        try { await open(selectedId, false) } catch {}
      }
      return true
    } catch (error) {
      selectedId = null
      status((error.message || 'Run history is unavailable.') + ' Existing backups have not been changed.', true)
      controls()
      return false
    }
  }

  async function download(run = selectedRun) {
    if (!run || !ID.test(run.runId) || run.history?.saved !== true) throw new Error('Open an intact saved report before downloading it.')
    const expected = JSON.stringify(run)
    const response = await fetch('/api/set-runs/' + run.runId + '/download')
    if (!response.ok) {
      let problem
      try { problem = await response.json() } catch {}
      throw new Error(problem?.error || 'The saved report could not be downloaded. Its file has not been changed.')
    }
    const bytes = await response.arrayBuffer()
    let downloaded
    try { downloaded = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)) } catch { throw new Error('The saved report download was not valid UTF-8 JSON.') }
    if (JSON.stringify(assertRun(downloaded, run.runId)) !== expected) throw new Error('The saved report changed after it was opened. Refresh run history and inspect the updated record before downloading.')
    const href = URL.createObjectURL(new Blob([bytes], { type: 'application/json' }))
    const link = node('a')
    link.href = href
    link.download = 'archive-desk-set-run-' + run.runId + '.json'
    document.body.append(link)
    link.click()
    link.remove()
    setTimeout(() => URL.revokeObjectURL(href), 1000)
    notify('The saved report bytes were prepared for download. This is the dated record, not a new integrity check.')
  }

  $('history-search').addEventListener('input', renderList)
  $('refresh-run-history').addEventListener('click', () => operation('Refreshing saved report records. No archives are being checked.', async () => {
    const loaded = await load()
    notify(loaded ? 'Run history refreshed. No archives were checked again.' : 'Run history could not be refreshed. Existing backups have not been changed.', loaded ? '' : 'error')
  }))
  $('download-history-report').addEventListener('click', () => operation('Reading the saved report for download.', () => download()))
  clearDetail()
  return { load, open, download, setBusy(value) { busy = value; controls() } }
}
