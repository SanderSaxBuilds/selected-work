# Daybreak planning concept

Independent calendar and focus concept. Not commissioned or endorsed by Daybreak. The sample schedule is fictional. Plans are stored in the browser for the current origin, with JSON backup and restore. There is no account or external calendar connection.
