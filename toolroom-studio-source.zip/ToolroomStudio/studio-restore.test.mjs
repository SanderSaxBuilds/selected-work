import assert from "node:assert/strict";
import { test } from "node:test";
import { buildRelease, createCatalog, generateStorefront, hashBytes, serializeCatalog } from "./studio-core.mjs";
import { restoreRelease } from "./studio-restore.mjs";

const encoder = new TextEncoder();
const decoder = new TextDecoder();

function readView(bytes) {
  return new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let index = 0; index < 256; index += 1) {
    let value = index;
    for (let bit = 0; bit < 8; bit += 1) {
      value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
    }
    table[index] = value >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc = CRC_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}
function locateMembers(bytes) {
  const view = readView(bytes);
  const eocd = bytes.byteLength - 22;
  const count = view.getUint16(eocd + 10, true);
  let cursor = view.getUint32(eocd + 16, true);
  const records = new Map();

  for (let index = 0; index < count; index += 1) {
    assert.equal(view.getUint32(cursor, true), 0x02014b50);
    const nameLength = view.getUint16(cursor + 28, true);
    const extraLength = view.getUint16(cursor + 30, true);
    const commentLength = view.getUint16(cursor + 32, true);
    const localOffset = view.getUint32(cursor + 42, true);
    const path = decoder.decode(bytes.subarray(cursor + 46, cursor + 46 + nameLength));
    const localNameLength = view.getUint16(localOffset + 26, true);
    const localExtraLength = view.getUint16(localOffset + 28, true);
    const size = view.getUint32(cursor + 24, true);
    const dataStart = localOffset + 30 + localNameLength + localExtraLength;
    records.set(path, { path, centralOffset: cursor, localOffset, dataStart, size, nameLength });
    cursor += 46 + nameLength + extraLength + commentLength;
  }
  return records;
}

function repairMemberCrc(bytes, path) {
  const record = locateMembers(bytes).get(path);
  assert.ok(record, "member exists");
  const view = readView(bytes);
  const checksum = crc32(bytes.subarray(record.dataStart, record.dataStart + record.size));
  view.setUint32(record.localOffset + 14, checksum, true);
  view.setUint32(record.centralOffset + 16, checksum, true);
}

function replaceMemberContent(bytes, path, newContent) {
  const record = locateMembers(bytes).get(path);
  assert.ok(record, "member exists");
  assert.equal(newContent.byteLength, record.size, "replacement preserves member size");
  bytes.set(newContent, record.dataStart);
  repairMemberCrc(bytes, path);
}

function renameMember(bytes, oldPath, newPath, { central = true, local = true } = {}) {
  const record = locateMembers(bytes).get(oldPath);
  assert.ok(record, "member exists");
  const oldName = encoder.encode(oldPath);
  const newName = encoder.encode(newPath);
  assert.equal(oldName.byteLength, newName.byteLength, "replacement path preserves header size");
  const view = readView(bytes);
  if (central) {
    bytes.set(newName, record.centralOffset + 46);
  }
  if (local) {
    bytes.set(newName, record.localOffset + 30);
  }
  assert.equal(view.getUint16(record.centralOffset + 28, true), newName.byteLength);
}

function storedZipForTest(entries) {
  const localParts = [];
  const centralParts = [];
  let offset = 0;
  for (const entry of entries) {
    const name = encoder.encode(entry.path);
    const data = entry.bytes;
    const checksum = crc32(data);
    const local = new Uint8Array(30);
    const localView = readView(local);
    localView.setUint32(0, 0x04034b50, true);
    localView.setUint16(4, 20, true);
    localView.setUint16(6, 0x0800, true);
    localView.setUint16(8, 0, true);
    localView.setUint16(10, 0, true);
    localView.setUint16(12, 0x0021, true);
    localView.setUint32(14, checksum, true);
    localView.setUint32(18, data.byteLength, true);
    localView.setUint32(22, data.byteLength, true);
    localView.setUint16(26, name.byteLength, true);
    localView.setUint16(28, 0, true);
    localParts.push(local, name, data);

    const central = new Uint8Array(46);
    const centralView = readView(central);
    centralView.setUint32(0, 0x02014b50, true);
    centralView.setUint16(4, 0x0314, true);
    centralView.setUint16(6, 20, true);
    centralView.setUint16(8, 0x0800, true);
    centralView.setUint16(10, 0, true);
    centralView.setUint16(12, 0, true);
    centralView.setUint16(14, 0x0021, true);
    centralView.setUint32(16, checksum, true);
    centralView.setUint32(20, data.byteLength, true);
    centralView.setUint32(24, data.byteLength, true);
    centralView.setUint16(28, name.byteLength, true);
    centralView.setUint16(30, 0, true);
    centralView.setUint16(32, 0, true);
    centralView.setUint16(34, 0, true);
    centralView.setUint16(36, 0, true);
    centralView.setUint32(38, 0, true);
    centralView.setUint32(42, offset, true);
    centralParts.push(central, name);
    offset += local.byteLength + name.byteLength + data.byteLength;
  }

  const centralSize = centralParts.reduce((sum, part) => sum + part.byteLength, 0);
  const end = new Uint8Array(22);
  const endView = readView(end);
  endView.setUint32(0, 0x06054b50, true);
  endView.setUint16(4, 0, true);
  endView.setUint16(6, 0, true);
  endView.setUint16(8, entries.length, true);
  endView.setUint16(10, entries.length, true);
  endView.setUint32(12, centralSize, true);
  endView.setUint32(16, offset, true);
  endView.setUint16(20, 0, true);

  const result = new Uint8Array(offset + centralSize + end.byteLength);
  let position = 0;
  for (const part of localParts) {
    result.set(part, position);
    position += part.byteLength;
  }
  for (const part of centralParts) {
    result.set(part, position);
    position += part.byteLength;
  }
  result.set(end, position);
  return result;
}

async function createCombinedLimitRelease() {
  const catalog = createCatalog();
  catalog.shop = { name: "Limit Shop", tagline: "", currency: "USD" };
  const downloadFiles = [];
  const fileSize = 9 * 1024 * 1024;
  for (const [index, id] of ["large-a", "large-b", "large-c"].entries()) {
    const bytes = new Uint8Array(fileSize);
    bytes.fill(index + 1);
    const fileName = id + ".bin";
    catalog.products.push({
      id,
      title: "Large " + id,
      category: "Files",
      description: "A bounded limit test asset.",
      priceCents: 0,
      version: "1",
      asset: { fileName, size: bytes.byteLength, sha256: await hashBytes(bytes) },
      rightsConfirmed: true,
      qaConfirmed: true,
    });
    downloadFiles.push({ path: "downloads/" + id + "/" + fileName, bytes });
  }

  const contentFiles = [
    { path: "index.html", bytes: encoder.encode(generateStorefront(catalog)) },
    { path: "catalog.json", bytes: encoder.encode(serializeCatalog(catalog)) },
    ...downloadFiles,
    {
      path: "README.txt",
      bytes: encoder.encode(
        "Toolroom Studio release\n" +
          "=======================\n\n" +
          "This ZIP contains a static catalog page and its listed download files.\n\n" +
          "Every download is a public file when hosted. Anyone who can reach the page URL may access the files. " +
          "This package does not provide payment processing, protected delivery, license enforcement, or customer acceptance.\n\n" +
          "Displayed prices are references only. Publish only files you are licensed to distribute and have reviewed.\n\n" +
          "RELEASE.json lists the SHA-256 hash and byte size for every other archive member. It omits its own hash because including that value would be self-referential.\n",
      ),
    },
  ];
  const members = [];
  for (const file of contentFiles) {
    members.push({
      path: file.path,
      size: file.bytes.byteLength,
      sha256: await hashBytes(file.bytes),
    });
  }
  const manifest = {
    schema: "toolroom-release",
    version: 1,
    shopName: catalog.shop.name,
    members,
  };
  contentFiles.push({ path: "RELEASE.json", bytes: encoder.encode(JSON.stringify(manifest, null, 2) + "\n") });
  return storedZipForTest(contentFiles);
}
async function createRelease({ binary = false } = {}) {
  const catalog = createCatalog();
  catalog.shop = { name: "Recovery Shop", tagline: "First line\nSecond line", currency: "EUR" };
  const firstBytes = binary ? new Uint8Array([0, 255, 17, 0, 128, 10]) : encoder.encode("first file");
  const secondBytes = binary ? new Uint8Array([255, 0, 42, 129, 4]) : encoder.encode("second file");
  const firstName = binary ? "資料-café.bin" : "notes.txt";
  const secondName = binary ? "資料-café.bin" : "other.txt";
  catalog.products = [
    {
      id: "field-notes",
      title: "Field Notes",
      category: "Templates",
      description: "A reusable planning file.",
      priceCents: 1250,
      version: "1.0",
      asset: { fileName: firstName, size: firstBytes.byteLength, sha256: await hashBytes(firstBytes) },
      rightsConfirmed: true,
      qaConfirmed: true,
    },
    {
      id: "field-notes-2",
      title: "Field Notes Two",
      category: "Templates",
      description: "A second reusable planning file.",
      priceCents: 0,
      version: "1.1",
      asset: { fileName: secondName, size: secondBytes.byteLength, sha256: await hashBytes(secondBytes) },
      rightsConfirmed: true,
      qaConfirmed: true,
    },
  ];
  const assets = new Map([
    [catalog.products[0].id, { fileName: firstName, bytes: firstBytes }],
    [catalog.products[1].id, { fileName: secondName, bytes: secondBytes }],
  ]);
  return { catalog, assets, release: await buildRelease(catalog, assets) };
}

test("restoreRelease round-trips a normal release and resets confirmations without mutating input", async () => {
  const { catalog, release } = await createRelease();
  const input = new Uint8Array(release.bytes);
  const original = new Uint8Array(input);
  const restored = await restoreRelease(input);

  assert.deepEqual(input, original);
  assert.deepEqual(restored.catalog.shop, catalog.shop);
  assert.equal(restored.catalog.products.length, catalog.products.length);
  for (let index = 0; index < catalog.products.length; index += 1) {
    const expected = { ...catalog.products[index], rightsConfirmed: false, qaConfirmed: false };
    assert.deepEqual(restored.catalog.products[index], expected);
    assert.deepEqual(restored.assets.get(expected.id), {
      fileName: expected.asset.fileName,
      bytes: new Uint8Array(
        index === 0 ? encoder.encode("first file") : encoder.encode("second file"),
      ),
    });
  }
  assert.deepEqual(restored.summary, {
    shopName: "Recovery Shop",
    products: 2,
    totalBytes: encoder.encode("first file").byteLength + encoder.encode("second file").byteLength,
    members: 6,
  });
  assert.equal(catalog.products.every((product) => product.rightsConfirmed && product.qaConfirmed), true);
});

test("restoreRelease supports Unicode filenames, binary downloads, and duplicate filenames across product ids", async () => {
  const { release } = await createRelease({ binary: true });
  const restored = await restoreRelease(release.bytes);
  assert.deepEqual(
    Array.from(restored.assets.keys()),
    ["field-notes", "field-notes-2"],
  );
  assert.equal(restored.assets.get("field-notes").fileName, "資料-café.bin");
  assert.equal(restored.assets.get("field-notes-2").fileName, "資料-café.bin");
  assert.deepEqual(restored.assets.get("field-notes").bytes, new Uint8Array([0, 255, 17, 0, 128, 10]));
  assert.deepEqual(restored.assets.get("field-notes-2").bytes, new Uint8Array([255, 0, 42, 129, 4]));
});

test("restoreRelease snapshots caller bytes before asynchronous hash verification", async () => {
  const { release } = await createRelease();
  const input = new Uint8Array(release.bytes);
  const pending = restoreRelease(input);
  input.fill(0);
  const restored = await pending;
  assert.equal(restored.summary.products, 2);
  assert.equal(restored.assets.get("field-notes").bytes.byteLength, encoder.encode("first file").byteLength);
});

test("restoreRelease rejects non-byte input, truncation, and archives over 32 MiB", async () => {
  await assert.rejects(() => restoreRelease("not bytes"), /Uint8Array/);
  const { release } = await createRelease();
  await assert.rejects(() => restoreRelease(release.bytes.slice(0, -1)), /end record|truncated/i);
  await assert.rejects(() => restoreRelease(new Uint8Array(32 * 1024 * 1024 + 1)), /32 MiB/);
});

test("restoreRelease enforces the 10 MiB per-file and 25 MiB combined download limits", async () => {
  const { release } = await createRelease();
  const perFile = new Uint8Array(release.bytes);
  const file = locateMembers(perFile).get("downloads/field-notes/notes.txt");
  const view = readView(perFile);
  view.setUint32(file.centralOffset + 20, 10 * 1024 * 1024 + 1, true);
  view.setUint32(file.centralOffset + 24, 10 * 1024 * 1024 + 1, true);
  await assert.rejects(() => restoreRelease(perFile), /10 MiB/);

  const combined = await createCombinedLimitRelease();
  assert.equal(combined.byteLength < 32 * 1024 * 1024, true);
  await assert.rejects(() => restoreRelease(combined), /25 MiB combined limit/);
});
test("restoreRelease rejects CRC corruption before returning any restored data", async () => {
  const { release } = await createRelease();
  const changed = new Uint8Array(release.bytes);
  const record = locateMembers(changed).get("downloads/field-notes/notes.txt");
  changed[record.dataStart] ^= 1;
  await assert.rejects(() => restoreRelease(changed), /CRC-32/);
});

test("restoreRelease rejects changed member bytes after CRC is repaired because the manifest hash is stale", async () => {
  const { release } = await createRelease();
  const changed = new Uint8Array(release.bytes);
  const record = locateMembers(changed).get("downloads/field-notes/notes.txt");
  changed[record.dataStart] ^= 1;
  repairMemberCrc(changed, record.path);
  await assert.rejects(() => restoreRelease(changed), /SHA-256 verification failed/);
});

test("restoreRelease rejects catalog asset hash mismatch even when the ZIP CRC and release manifest are repaired", async () => {
  const { release } = await createRelease();
  const changed = new Uint8Array(release.bytes);
  const downloadPath = "downloads/field-notes/notes.txt";
  const record = locateMembers(changed).get(downloadPath);
  changed[record.dataStart] ^= 1;
  repairMemberCrc(changed, downloadPath);

  const releaseRecord = locateMembers(changed).get("RELEASE.json");
  const manifestBytes = changed.slice(releaseRecord.dataStart, releaseRecord.dataStart + releaseRecord.size);
  const manifest = JSON.parse(decoder.decode(manifestBytes));
  const member = manifest.members.find((entry) => entry.path === downloadPath);
  member.sha256 = await hashBytes(changed.slice(record.dataStart, record.dataStart + record.size));
  replaceMemberContent(changed, "RELEASE.json", encoder.encode(JSON.stringify(manifest, null, 2) + "\n"));

  await assert.rejects(() => restoreRelease(changed), /download hash does not match catalog metadata/);
});

test("restoreRelease rejects duplicate JSON keys in the release manifest", async () => {
  const { release } = await createRelease();
  const changed = new Uint8Array(release.bytes);
  const record = locateMembers(changed).get("RELEASE.json");
  const originalText = decoder.decode(changed.slice(record.dataStart, record.dataStart + record.size));
  const duplicateText = originalText.replace('"version": 1', '"schema" : 1');
  assert.notEqual(duplicateText, originalText);
  assert.equal(encoder.encode(duplicateText).byteLength, record.size);
  replaceMemberContent(changed, "RELEASE.json", encoder.encode(duplicateText));
  await assert.rejects(() => restoreRelease(changed), /duplicate JSON object keys/);
});

test("restoreRelease rejects an unsafe traversal path", async () => {
  const { release } = await createRelease();
  const changed = new Uint8Array(release.bytes);
  renameMember(changed, "README.txt", "../bad.txt");
  await assert.rejects(() => restoreRelease(changed), /unsafe path/);
});

test("restoreRelease rejects duplicate and case-colliding member paths", async () => {
  const { release } = await createRelease();
  const duplicate = new Uint8Array(release.bytes);
  renameMember(duplicate, "README.txt", "index.html");
  await assert.rejects(() => restoreRelease(duplicate), /duplicate or case-colliding/);

  const caseCollision = new Uint8Array(release.bytes);
  renameMember(caseCollision, "README.txt", "INDEX.HTML");
  await assert.rejects(() => restoreRelease(caseCollision), /duplicate or case-colliding/);
});

test("restoreRelease rejects local and central header disagreement and unexpected members", async () => {
  const { release } = await createRelease();
  const inconsistent = new Uint8Array(release.bytes);
  renameMember(inconsistent, "README.txt", "readme.txt", { central: false, local: true });
  await assert.rejects(() => restoreRelease(inconsistent), /local filename does not match/);

  const unexpected = new Uint8Array(release.bytes);
  renameMember(unexpected, "README.txt", "NOTICE.txt");
  await assert.rejects(() => restoreRelease(unexpected), /missing a required|member set or order/);
});

test("restoreRelease validates the exact manifest schema", async () => {
  const { release } = await createRelease();
  const changed = new Uint8Array(release.bytes);
  const record = locateMembers(changed).get("RELEASE.json");
  const originalText = decoder.decode(changed.slice(record.dataStart, record.dataStart + record.size));
  const unknownFieldText = originalText.replace('"shopName"', '"xhopName"');
  assert.notEqual(unknownFieldText, originalText);
  replaceMemberContent(changed, "RELEASE.json", encoder.encode(unknownFieldText));
  await assert.rejects(() => restoreRelease(changed), /missing, extra, or dangerous fields/);
});
