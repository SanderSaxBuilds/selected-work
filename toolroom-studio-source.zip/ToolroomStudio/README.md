# Toolroom Studio 1.1.0

A seller workspace for preparing a portable digital download catalog. Edit listings, attach files, confirm their review and distribution rights, then export a static catalog ZIP. This is an independent app by SanderSaxBuilds.

## Run

Use Node.js 22 or newer. No dependencies, installation hooks, accounts or network services are needed.

```text
node server.mjs
```

Open http://127.0.0.1:4328. The preview binds only to this computer and serves an explicit allowlist of six browser files.

## Use

1. Add a product title, description, category, version and reference price.
2. Attach one file per product, up to 10 MB each. The combined release limit is 25 MB and 40 listings. ZIP multiple source files yourself before attaching them.
3. Check the exact attached file and confirm you may share it publicly.
4. Open Release checks. Resolve missing files or confirmations.
5. Confirm that hosting the exported catalog makes its downloads public, then export the ZIP.
6. Extract it and open index.html. It contains search, category filtering and ordinary links to the included downloads. It can also be served by a static host.

The worked example contains three free synthetic sample files. These demonstrate the flow and are not paid products or customer work.

## Save and restore

Listing details and file fingerprints save in local browser storage. Attached file bytes stay only in session memory. After reopening, restore a complete catalog ZIP or reattach the original files. Reattaching a file clears its review confirmations, so check them again for that exact file.

Download a listing backup before clearing browser storage or changing the hosted address. The JSON backup contains listing details and file fingerprints, not attachment bytes. Restore validates the whole backup and shows a replacement preview before changing listings. Your original files on disk are never changed.

To recover both the listings and files, open Backup and restore and choose the original catalog ZIP previously exported by Toolroom Studio. Releases from version 1.0.0 are supported. The app checks the ZIP structure, exact member list, CRC32 checksums, file sizes and SHA256 fingerprints before showing the catalog name and files. Confirm the replacement only after checking that preview. Canceling or choosing an invalid archive leaves the workspace unchanged.

ZIP recovery accepts original uncompressed Toolroom releases up to 32 MiB, with up to 40 products, 10 MiB per download and 25 MiB of downloads in total. Recompressed, encrypted, split, Zip64 and edited archives are rejected. The archive is read in memory, no files are written to disk and no included page is executed. A matching fingerprint detects changed bytes, it does not prove authorship, safety or distribution rights.

Recovered files are attached for the current session. Their quality and distribution-rights confirmations are cleared. Review the exact files and confirm both checks before exporting a new release. Keep your original release ZIP, because closing or reloading the workspace still clears attachment bytes from memory.

## Release contents

The release includes index.html, catalog.json, RELEASE.json, README.txt and the selected download files. File fingerprints are checked again at export. The stored ZIP uses CRC32 for archive integrity and SHA256 in its manifest. These checks detect changed bytes. They do not establish authorship, rights, safety, customer acceptance or a successful sale.

## Boundaries

This app does not process payments, grant licenses, send email, authenticate customers or protect downloads behind a purchase. Reference prices do not create a checkout or payment record. Everything in a hosted release is publicly retrievable. Use it for free resources, reviewed previews or other files you have chosen to share publicly. Do not include private data, credentials or unaccepted products.

No Etsy, Payhip or other storefront account is required or modified. Financial account and billing setup remain separate from this app.

## Checks

```text
node --test studio-core.test.mjs studio-restore.test.mjs
```

The source package includes the core tests. Browser and publication verification are recorded separately for the exact delivered revision. No customer or production compatibility is implied by the local preview.
