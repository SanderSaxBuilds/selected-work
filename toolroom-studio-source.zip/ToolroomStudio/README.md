# Toolroom Studio 1.0.0

A seller workspace for preparing a portable digital download catalog. Edit listings, attach files, confirm their review and distribution rights, then export a static catalog ZIP. This is an independent app by SanderSaxBuilds.

## Run

Use Node.js 22 or newer. No dependencies, installation hooks, accounts or network services are needed.

```text
node server.mjs
```

Open http://127.0.0.1:4328. The preview binds only to this computer and serves an explicit allowlist of five browser files.

## Use

1. Add a product title, description, category, version and reference price.
2. Attach one file per product, up to 10 MB each. The combined release limit is 25 MB and 40 listings. ZIP multiple source files yourself before attaching them.
3. Check the exact attached file and confirm you may share it publicly.
4. Open Release checks. Resolve missing files or confirmations.
5. Confirm that hosting the exported catalog makes its downloads public, then export the ZIP.
6. Extract it and open index.html. It contains search, category filtering and ordinary links to the included downloads. It can also be served by a static host.

The worked example contains three free synthetic sample files. These demonstrate the flow and are not paid products or customer work.

## Save and restore

Listing details and file fingerprints save in local browser storage. Attached file bytes stay only in session memory. Reopening the page requires reattaching the original files. Reattaching a file clears its review confirmations, so check them again for that exact file.

Download a listing backup before clearing browser storage or changing the hosted address. The JSON backup contains listing details and file fingerprints, not attachment bytes. Restore validates the whole backup and shows a replacement preview before changing listings. Your original files on disk are never changed.

## Release contents

The release includes index.html, catalog.json, RELEASE.json, README.txt and the selected download files. File fingerprints are checked again at export. The stored ZIP uses CRC32 for archive integrity and SHA256 in its manifest. These checks detect changed bytes. They do not establish authorship, rights, safety, customer acceptance or a successful sale.

## Boundaries

This app does not process payments, grant licenses, send email, authenticate customers or protect downloads behind a purchase. Reference prices do not create a checkout or payment record. Everything in a hosted release is publicly retrievable. Use it for free resources, reviewed previews or other files you have chosen to share publicly. Do not include private data, credentials or unaccepted products.

No Etsy, Payhip or other storefront account is required or modified. Financial account and billing setup remain separate from this app.

## Checks

```text
node --test studio-core.test.mjs
```

The source package includes the core tests. Browser and publication verification are recorded separately for the exact delivered revision. No customer or production compatibility is implied by the local preview.
