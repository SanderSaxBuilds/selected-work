import assert from "node:assert/strict";
import { test } from "node:test";
import {
  buildRelease,
  canonicalCatalog,
  createCatalog,
  generateStorefront,
  hashBytes,
  inspectRelease,
  parseCatalog,
  serializeCatalog,
} from "./studio-core.mjs";

const encoder = new TextEncoder();
const decoder = new TextDecoder();

function product(overrides = {}) {
  return {
    id: "field-notes",
    title: "Field Notes",
    category: "Templates",
    description: "A practical download for planning a small project.",
    priceCents: 0,
    version: "1.0",
    asset: { fileName: "notes.txt", size: 4, sha256: "a".repeat(64) },
    rightsConfirmed: true,
    qaConfirmed: true,
    ...overrides,
  };
}

function catalogWith(...products) {
  const catalog = createCatalog();
  catalog.shop = { name: "Good Goods", tagline: "Useful work, well made.", currency: "USD" };
  catalog.products = products;
  return catalog;
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function assertCatalogRejects(value, pattern) {
  assert.throws(() => canonicalCatalog(value), pattern);
}

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = crc & 1 ? 0xedb88320 ^ (crc >>> 1) : crc >>> 1;
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function parseStoredZip(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const signature = (position) => view.getUint32(position, true);
  let endOffset = -1;
  for (let position = bytes.byteLength - 22; position >= Math.max(0, bytes.byteLength - 65557); position -= 1) {
    if (signature(position) === 0x06054b50) {
      endOffset = position;
      break;
    }
  }
  assert.notEqual(endOffset, -1, "ZIP end record exists");

  const count = view.getUint16(endOffset + 10, true);
  const centralSize = view.getUint32(endOffset + 12, true);
  const centralOffset = view.getUint32(endOffset + 16, true);
  assert.equal(centralOffset + centralSize, endOffset);

  const files = new Map();
  let position = centralOffset;
  for (let entry = 0; entry < count; entry += 1) {
    assert.equal(signature(position), 0x02014b50, "central directory header signature");
    const flags = view.getUint16(position + 8, true);
    const method = view.getUint16(position + 10, true);
    const expectedCrc = view.getUint32(position + 16, true);
    const compressedSize = view.getUint32(position + 20, true);
    const uncompressedSize = view.getUint32(position + 24, true);
    const nameLength = view.getUint16(position + 28, true);
    const extraLength = view.getUint16(position + 30, true);
    const commentLength = view.getUint16(position + 32, true);
    const localOffset = view.getUint32(position + 42, true);
    assert.equal(flags & 0x0800, 0x0800, "UTF-8 flag is set");
    assert.equal(method, 0, "entry uses ZIP stored mode");
    assert.equal(compressedSize, uncompressedSize, "stored entry sizes match");

    const nameBytes = bytes.subarray(position + 46, position + 46 + nameLength);
    const path = decoder.decode(nameBytes);
    assert.equal(signature(localOffset), 0x04034b50, "local header signature");
    assert.equal(view.getUint16(localOffset + 6, true), flags, "local and central flags match");
    assert.equal(view.getUint16(localOffset + 8, true), method, "local and central compression match");
    assert.equal(view.getUint32(localOffset + 14, true), expectedCrc, "local and central CRC match");

    const localNameLength = view.getUint16(localOffset + 26, true);
    const localExtraLength = view.getUint16(localOffset + 28, true);
    const localName = decoder.decode(bytes.subarray(localOffset + 30, localOffset + 30 + localNameLength));
    assert.equal(localName, path, "local and central names match");
    assert.equal(localNameLength, nameLength, "local and central name sizes match");
    const dataStart = localOffset + 30 + localNameLength + localExtraLength;
    const data = bytes.slice(dataStart, dataStart + uncompressedSize);
    assert.equal(data.byteLength, uncompressedSize);
    assert.equal(crc32(data), expectedCrc, "payload CRC is correct");
    assert.equal(files.has(path), false, "archive member names are unique");
    files.set(path, { bytes: data, flags, method, crc: expectedCrc });

    position += 46 + nameLength + extraLength + commentLength;
  }
  assert.equal(position, centralOffset + centralSize);
  return files;
}

test("createCatalog returns the exact starter schema and canonicalCatalog clones data", () => {
  assert.deepEqual(createCatalog(), {
    schema: "toolroom-studio",
    version: 1,
    shop: { name: "My download catalog", tagline: "", currency: "USD" },
    products: [],
  });

  const source = catalogWith(product());
  const result = canonicalCatalog(source);
  assert.deepEqual(result, source);
  assert.notEqual(result, source);
  assert.notEqual(result.shop, source.shop);
  assert.notEqual(result.products, source.products);
  assert.notEqual(result.products[0], source.products[0]);
  assert.notEqual(result.products[0].asset, source.products[0].asset);

  result.shop.name = "Changed copy";
  result.products[0].asset.fileName = "changed.txt";
  assert.equal(source.shop.name, "Good Goods");
  assert.equal(source.products[0].asset.fileName, "notes.txt");
});

test("canonicalCatalog accepts zero price and exact integer money bounds", () => {
  const zero = catalogWith(product({ priceCents: 0 }));
  assert.equal(canonicalCatalog(zero).products[0].priceCents, 0);

  for (const priceCents of [-1, 1.25, 100000001, Number.MAX_SAFE_INTEGER, NaN, Infinity]) {
    assertCatalogRejects(catalogWith(product({ priceCents })), /priceCents/);
  }
  assert.equal(canonicalCatalog(catalogWith(product({ priceCents: 100000000 }))).products[0].priceCents, 100000000);
});

test("canonicalCatalog rejects schema drift, extra and dangerous fields, accessors, and malformed arrays", () => {
  assertCatalogRejects({ ...createCatalog(), extra: true }, /fields/);
  assertCatalogRejects({ ...createCatalog(), version: 2 }, /schema and version/);
  assertCatalogRejects({ ...createCatalog(), shop: { ...createCatalog().shop, extra: true } }, /fields/);
  assertCatalogRejects(Object.assign(Object.create(null), createCatalog()), /standard object prototype/);

  const dangerous = catalogWith(product());
  Object.defineProperty(dangerous, "__proto__", { value: { injected: true }, enumerable: true });
  assertCatalogRejects(dangerous, /fields/);

  const accessor = catalogWith(product());
  let getterCalled = false;
  Object.defineProperty(accessor.shop, "name", {
    enumerable: true,
    get() {
      getterCalled = true;
      return "unsafe";
    },
  });
  assertCatalogRejects(accessor, /data field/);
  assert.equal(getterCalled, false);

  const extraArrayProperty = catalogWith(product());
  extraArrayProperty.products.extra = "unexpected";
  assertCatalogRejects(extraArrayProperty, /extra array fields/);

  const sparse = catalogWith(product());
  sparse.products = new Array(1);
  assertCatalogRejects(sparse, /extra array fields|holes or accessors/);
});

test("canonicalCatalog enforces bounded strings, control-free text, and safe filenames", () => {
  for (const title of ["", "   ", "Bad\nTitle", "x".repeat(101), "\ud800"]) {
    assertCatalogRejects(catalogWith(product({ title })), /title/);
  }
  assertCatalogRejects(catalogWith(product({ category: "c".repeat(41) })), /category/);
  const multiline = "First" + String.fromCharCode(10) + "second" + String.fromCharCode(13, 10) + "third";
  assert.equal(canonicalCatalog(catalogWith(product({ description: multiline }))).products[0].description, multiline);
  assert.equal(
    canonicalCatalog({ ...catalogWith(), shop: { name: "Good Goods", tagline: multiline, currency: "USD" } }).shop.tagline,
    multiline,
  );
  assertCatalogRejects(
    catalogWith(product({ description: "Bad" + String.fromCharCode(13) + "carriage" })),
    /control characters/,
  );
  assertCatalogRejects(catalogWith(product({ description: "Bad" + String.fromCharCode(9) + "tab" })), /control characters/);
  assertCatalogRejects(catalogWith(product({ description: "d".repeat(1201) })), /description/);
  assertCatalogRejects(catalogWith(product({ version: "v".repeat(31) })), /version/);

  for (const fileName of ["../payload.txt", "folder\\payload.txt", "C:payload.txt", ".secret", "..", "CON.txt", "trailing."]) {
    assertCatalogRejects(
      catalogWith(product({ asset: { fileName, size: 4, sha256: "a".repeat(64) } })),
      /safe basename/,
    );
  }

  const unicodeName = "資料-café.txt";
  assert.equal(
    canonicalCatalog(catalogWith(product({ asset: { fileName: unicodeName, size: 4, sha256: "b".repeat(64) } })))
      .products[0].asset.fileName,
    unicodeName,
  );
});

test("canonicalCatalog rejects duplicate ids and invalid asset metadata", () => {
  assertCatalogRejects(catalogWith(product(), product()), /unique/);
  assertCatalogRejects(
    catalogWith(product({ asset: { fileName: "a.txt", size: 0, sha256: "a".repeat(64) } })),
    /size/,
  );
  assertCatalogRejects(
    catalogWith(product({ asset: { fileName: "a.txt", size: 1.5, sha256: "a".repeat(64) } })),
    /size/,
  );
  assertCatalogRejects(
    catalogWith(product({ asset: { fileName: "a.txt", size: 4, sha256: "A".repeat(64) } })),
    /sha256/,
  );
  assertCatalogRejects(
    catalogWith(product({ asset: { fileName: "a.txt", size: 4, sha256: "a".repeat(64), path: "extra" } })),
    /fields/,
  );
});

test("parseCatalog and serializeCatalog round-trip while rejecting malformed, duplicate, and oversized imports", () => {
  const source = catalogWith(product());
  const serialized = serializeCatalog(source);
  assert.equal(serialized.endsWith("\n"), true);
  assert.deepEqual(parseCatalog(serialized), canonicalCatalog(source));
  assert.throws(() => parseCatalog("{not-json"), SyntaxError);
  assert.throws(() => parseCatalog(serialized.replace('"version": 1,', '"version": 1, "version": 1,')), /duplicate/);
  assert.throws(
    () => parseCatalog(serialized.replace('"schema":', '"schema": "shadow", "\\u0073chema":')),
    /duplicate/,
  );
  assert.throws(() => parseCatalog(" ".repeat(256 * 1024 + 1)), /256 KiB/);

  const extra = clone(source);
  extra.unexpected = "field";
  assert.throws(() => serializeCatalog(extra), /fields/);
});

test("hashBytes returns a lowercase SHA-256 digest", async () => {
  assert.equal(
    await hashBytes(encoder.encode("abc")),
    "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
  );
  await assert.rejects(() => hashBytes([1, 2, 3]), /Uint8Array/);
});

test("inspectRelease reports missing attachments and requires rights and QA confirmation", () => {
  const current = catalogWith(product({ rightsConfirmed: false, qaConfirmed: false }));
  const bytes = encoder.encode("data");
  const assets = new Map([["field-notes", { fileName: "notes.txt", bytes }]]);
  const inspection = inspectRelease(current, assets);
  assert.equal(inspection.ready, false);
  assert.equal(inspection.totalBytes, 4);
  assert.equal(inspection.issues.some((issue) => issue.productId === "field-notes" && /rights/.test(issue.message)), true);
  assert.equal(inspection.issues.some((issue) => issue.productId === "field-notes" && /quality/.test(issue.message)), true);

  const missing = inspectRelease(catalogWith(product()), new Map());
  assert.equal(missing.ready, false);
  assert.equal(missing.issues.some((issue) => issue.productId === "field-notes" && /missing/.test(issue.message)), true);

  const noMetadata = inspectRelease(
    catalogWith(product({ asset: null })),
    new Map([["field-notes", { fileName: "notes.txt", bytes }]]),
  );
  assert.equal(noMetadata.ready, false);
  assert.equal(noMetadata.issues.some((issue) => issue.productId === "field-notes" && /metadata/.test(issue.message)), true);

  const mismatch = inspectRelease(
    catalogWith(product()),
    new Map([["field-notes", { fileName: "other.txt", bytes: encoder.encode("longer") }]]),
  );
  assert.equal(mismatch.ready, false);
  assert.equal(mismatch.issues.some((issue) => /filename/.test(issue.message)), true);
  assert.equal(mismatch.issues.some((issue) => /size/.test(issue.message)), true);
});

test("inspectRelease enforces the 25 MiB aggregate download limit", () => {
  const size = 9 * 1024 * 1024;
  const products = ["one", "two", "three"].map((id) =>
    product({
      id,
      title: id,
      asset: { fileName: id + ".bin", size, sha256: "c".repeat(64) },
    }),
  );
  const assets = new Map(products.map((item) => [item.id, { fileName: item.asset.fileName, bytes: new Uint8Array(size) }]));
  const inspection = inspectRelease(catalogWith(...products), assets);
  assert.equal(inspection.totalBytes, size * 3);
  assert.equal(inspection.ready, false);
  assert.equal(inspection.issues.some((issue) => /25 MiB/.test(issue.message)), true);
});

test("generateStorefront escapes user content and provides accessible local-only catalog controls", () => {
  const html = generateStorefront(
    catalogWith(
      product({
        title: '<img src=x onerror="alert(1)">',
        description: '</script><script>alert("x")</script> & more',
        category: "Design & tools",
        asset: { fileName: "café notes.txt", size: 4, sha256: "a".repeat(64) },
      }),
    ),
  );
  assert.equal(html.includes('<img src=x onerror="alert(1)">'), false);
  assert.equal(html.includes('</script><script>alert("x")</script>'), false);
  assert.equal(html.includes("&lt;img"), true);
  assert.equal(html.includes("&amp; more"), true);
  assert.equal(html.includes("name=\"catalog-search\""), false);
  assert.equal(html.includes('id="catalog-search"'), true);
  assert.equal(html.includes('id="category-filter"'), true);
  assert.equal(html.includes('aria-live="polite"'), true);
  assert.equal(html.includes("Reference price only"), true);
  assert.equal(html.includes("public files when hosted"), true);
  assert.equal(html.includes("https://"), false);
  assert.equal(html.includes("https://fonts."), false);
  assert.equal(html.includes("href=\"downloads/field-notes/caf%C3%A9%20notes.txt\""), true);
});

test("buildRelease creates a deterministic UTF-8 stored ZIP with verified members and a non-self-referential manifest", async () => {
  const fileName = "資料-café.txt";
  const bytes = encoder.encode("download payload\n");
  const sha256 = await hashBytes(bytes);
  const current = catalogWith(
    product({
      asset: { fileName, size: bytes.byteLength, sha256 },
      rightsConfirmed: true,
      qaConfirmed: true,
    }),
  );
  const assets = new Map([["field-notes", { fileName, bytes }]]);

  const result = await buildRelease(current, assets);
  const files = parseStoredZip(result.bytes);
  const downloadPath = "downloads/field-notes/" + fileName;
  assert.deepEqual(
    Array.from(files.keys()),
    ["index.html", "catalog.json", downloadPath, "README.txt", "RELEASE.json"],
  );
  assert.equal(decoder.decode(files.get(downloadPath).bytes), "download payload\n");
  assert.equal(decoder.decode(files.get("index.html").bytes).includes(encodeURIComponent("field-notes") + "/" + encodeURIComponent(fileName)), true);
  assert.equal(decoder.decode(files.get("README.txt").bytes).includes("public file when hosted"), true);

  const archiveManifest = JSON.parse(decoder.decode(files.get("RELEASE.json").bytes));
  assert.deepEqual(archiveManifest, result.manifest);
  assert.equal(archiveManifest.members.some((member) => member.path === "RELEASE.json"), false);
  assert.deepEqual(
    archiveManifest.members.map((member) => member.path),
    ["index.html", "catalog.json", downloadPath, "README.txt"],
  );
  for (const member of archiveManifest.members) {
    const archived = files.get(member.path);
    assert.equal(archived.bytes.byteLength, member.size);
    assert.equal(await hashBytes(archived.bytes), member.sha256);
  }

  const repeated = await buildRelease(current, assets);
  assert.deepEqual(repeated.bytes, result.bytes);
  assert.deepEqual(repeated.manifest, result.manifest);
});

test("buildRelease keeps overlapping ids and filenames in separate directories", async () => {
  const firstBytes = encoder.encode("one");
  const secondBytes = encoder.encode("two");
  const firstName = "b-c.txt";
  const secondName = "c.txt";
  const first = product({
    id: "a",
    title: "First",
    asset: { fileName: firstName, size: firstBytes.byteLength, sha256: await hashBytes(firstBytes) },
  });
  const second = product({
    id: "a-b",
    title: "Second",
    asset: { fileName: secondName, size: secondBytes.byteLength, sha256: await hashBytes(secondBytes) },
  });
  const current = catalogWith(first, second);
  const assets = new Map([
    ["a", { fileName: firstName, bytes: firstBytes }],
    ["a-b", { fileName: secondName, bytes: secondBytes }],
  ]);
  const result = await buildRelease(current, assets);
  const files = parseStoredZip(result.bytes);
  assert.equal(files.has("downloads/a/b-c.txt"), true);
  assert.equal(files.has("downloads/a-b/c.txt"), true);
  assert.equal(decoder.decode(files.get("downloads/a/b-c.txt").bytes), "one");
  assert.equal(decoder.decode(files.get("downloads/a-b/c.txt").bytes), "two");
});
test("buildRelease rejects tampered bytes even when filename and size still match", async () => {
  const original = encoder.encode("data");
  const sha256 = await hashBytes(original);
  const current = catalogWith(product({ asset: { fileName: "notes.txt", size: 4, sha256 } }));
  const tampered = encoder.encode("evil");
  await assert.rejects(
    () => buildRelease(current, new Map([["field-notes", { fileName: "notes.txt", bytes: tampered }]])),
    /SHA-256 mismatch/,
  );
});
