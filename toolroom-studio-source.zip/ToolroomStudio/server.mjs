import http from 'node:http'
import {readFile} from 'node:fs/promises'
import {fileURLToPath} from 'node:url'
import path from 'node:path'
const root=path.dirname(fileURLToPath(import.meta.url))
const allowed=new Map([['/','index.html'],['/index.html','index.html'],['/studio.css','studio.css'],['/studio-app.mjs','studio-app.mjs'],['/studio-core.mjs','studio-core.mjs']])
const types={'.html':'text/html; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'}
http.createServer(async(req,res)=>{try{if(!['GET','HEAD'].includes(req.method)){res.writeHead(405,{Allow:'GET, HEAD'});return res.end('Method not allowed')}const name=allowed.get(new URL(req.url,'http://localhost').pathname);if(!name){res.writeHead(404);return res.end('Not found')}const bytes=await readFile(path.join(root,name));res.writeHead(200,{'Content-Type':types[path.extname(name)],'Content-Length':bytes.length,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"});res.end(req.method==='HEAD'?undefined:bytes)}catch{res.writeHead(500);res.end('Preview unavailable')}}).listen(4328,'127.0.0.1',()=>process.stdout.write('Toolroom Studio: http://127.0.0.1:4328\n'))
