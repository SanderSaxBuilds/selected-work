# Field & Frame construction website concept

A responsive website for a fictional local builder, designed and built by Alexandr Khrustalev.

Field & Frame is fictional. This is not a past client project, and no construction services are offered.

## What it shows

- A calm builder home page with a clear quote path: kinds of job, project sheets, a rough estimate, a four-step process and common questions
- Project sheets that switch each floor plan between before and after the work
- A rough estimate that splits a fictional price range by trade and can be attached to the brief
- A mobile menu that traps focus while open and closes with Escape, an outside click or a wider window
- A project brief planner with validation that builds a text file on the visitor's device and sends nothing
- Plain HTML, CSS and JavaScript with no build step, checked at widths from 320 to 2560 pixels

## Files

- `index.html`, `style.css` and `app.js` are the site
- `house.jpg` is the licensed hero photo
- `ATTRIBUTION.txt` credits the hero photo

## Source image

Photo by vcmxnajg1, licensed under CC BY 2.0, via Wikimedia Commons. Resized and cropped for display.

- Source: https://commons.wikimedia.org/wiki/File:Modern-home-dusk_(Creative_Commons).jpg
- License: https://creativecommons.org/licenses/by/2.0/
