# Field & Frame construction site concept

Independent fictional construction website. No construction services are offered. The local project brief builder validates entered information and prepares a downloadable text file. It does not submit an enquiry.

## Photograph

Modern-home-dusk by vcmxnajg1, licensed under Creative Commons Attribution 2.0. The image is resized and cropped for display.

Source: https://commons.wikimedia.org/wiki/File:Modern-home-dusk_(Creative_Commons).jpg

License: https://creativecommons.org/licenses/by/2.0/
