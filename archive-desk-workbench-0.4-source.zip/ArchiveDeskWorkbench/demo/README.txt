Synthetic starter workspace for Archive Desk Workbench.

This folder contains public example text only.
