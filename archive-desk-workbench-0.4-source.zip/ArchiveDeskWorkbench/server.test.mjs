import assert from "node:assert/strict"
import { spawn } from "node:child_process"
import { createHash } from "node:crypto"
import { lstat, mkdir, mkdtemp, readFile, readdir, symlink, writeFile } from "node:fs/promises"
import http from "node:http"
import os from "node:os"
import path from "node:path"
import { once } from "node:events"
import test from "node:test"
import { fileURLToPath } from "node:url"
import { createWorkbench } from "./server.mjs"

const SOURCE_ROOT = path.dirname(fileURLToPath(import.meta.url))
const SERVER_FILE = path.join(SOURCE_ROOT, "server.mjs")
const BODY_LIMIT = 16 * 1024

async function makeFixture() {
  const root = await mkdtemp(path.join(os.tmpdir(), "archive-desk-workbench-"))
  const workspace = path.join(root, "workspace")
  const storage = path.join(root, "storage")
  await mkdir(workspace)
  await mkdir(storage)
  return { root, workspace, storage }
}

async function putFile(root, relative, data) {
  const absolute = path.join(root, ...relative.split("/"))
  await mkdir(path.dirname(absolute), { recursive: true })
  await writeFile(absolute, data)
  return absolute
}

async function sourceFixture() {
  const fixture = await makeFixture()
  const baseline = path.join(fixture.workspace, "project")
  const current = path.join(fixture.workspace, "current")
  await putFile(baseline, "same.txt", "same sample bytes\n")
  await putFile(baseline, "changed.bin", Buffer.from([1, 2, 3, 4, 5]))
  await putFile(baseline, "removed.txt", "kept in the saved baseline\n")
  await putFile(baseline, "nested/資料/café.txt", "unchanged Unicode sample\n")
  await putFile(baseline, ".env", "synthetic excluded text\n")
  await putFile(current, "same.txt", "same sample bytes\n")
  await putFile(current, "changed.bin", Buffer.from([1, 2, 3, 4, 6]))
  await putFile(current, "added.txt", "new sample bytes\n")
  await putFile(current, "nested/資料/café.txt", "unchanged Unicode sample\n")
  await putFile(current, ".env.local", "synthetic excluded current text\n")
  return { ...fixture, baseline, current }
}

async function startApp(t, fixture) {
  const app = await createWorkbench({ workspace: fixture.workspace, storage: fixture.storage, port: 0 })
  let running = true
  t.after(async () => {
    if (!running) return
    running = false
    await app.close()
  })
  return {
    app,
    async close() {
      if (!running) return
      running = false
      await app.close()
    }
  }
}

function requestHeaders(app, extra = {}) {
  return {
    Origin: app.url,
    "Content-Type": "application/json",
    "X-Workbench": "1",
    ...extra
  }
}

async function post(app, route, value, extraHeaders = {}) {
  return fetch(app.url + route, {
    method: "POST",
    headers: requestHeaders(app, extraHeaders),
    body: JSON.stringify(value)
  })
}

async function responseJson(response) {
  const text = await response.text()
  try {
    return JSON.parse(text)
  } catch {
    assert.fail("Expected a JSON response, received: " + text.slice(0, 200))
  }
}

async function rawRequest(app, route, { method = "GET", headers = {}, body = null } = {}) {
  const address = new URL(route, app.url)
  return new Promise((resolve, reject) => {
    let settled = false
    let result = null
    const finish = () => {
      if (settled || !result) return
      settled = true
      resolve({
        status: result.statusCode,
        headers: result.headers,
        body: Buffer.concat(responseChunks).toString("utf8")
      })
    }
    let responseChunks = []
    const request = http.request({
      hostname: address.hostname,
      port: Number(address.port),
      path: address.pathname + address.search,
      method,
      headers,
      agent: false
    }, response => {
      result = response
      response.on("data", chunk => responseChunks.push(chunk))
      response.on("end", finish)
      response.on("aborted", finish)
      response.on("error", finish)
    })
    request.once("error", error => {
      if (result) finish()
      else if (!settled) {
        settled = true
        reject(error)
      }
    })
    request.end(body)
  })
}

async function postArchive(app, route, bytes, headers = {}) {
  const requestHeaders = {
    Origin: app.url,
    "X-Workbench": "1",
    "Content-Type": "application/zip",
    "Content-Length": bytes.byteLength,
    ...headers
  }
  for (const [name, value] of Object.entries(requestHeaders)) {
    if (value === undefined) delete requestHeaders[name]
  }
  return rawRequest(app, route, {
    method: "POST",
    headers: requestHeaders,
    body: bytes
  })
}

function zipCrc32(bytes) {
  let crc = 0xffffffff
  for (const byte of bytes) {
    crc ^= byte
    for (let bit = 0; bit < 8; bit += 1) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0)
  }
  return (crc ^ 0xffffffff) >>> 0
}

function makeStoredZip(entries) {
  const localParts = []
  const centralParts = []
  let localOffset = 0
  const dateBits = ((2026 - 1980) << 9) | (10 << 5) | 18
  for (const entry of entries) {
    const name = Buffer.from(entry.name, "utf8")
    const data = Buffer.from(entry.data)
    const crc = zipCrc32(data)
    const local = Buffer.alloc(30)
    local.writeUInt32LE(0x04034b50, 0)
    local.writeUInt16LE(20, 4)
    local.writeUInt16LE(0x0800, 6)
    local.writeUInt16LE(0, 8)
    local.writeUInt16LE(0, 10)
    local.writeUInt16LE(dateBits, 12)
    local.writeUInt32LE(crc, 14)
    local.writeUInt32LE(data.length, 18)
    local.writeUInt32LE(data.length, 22)
    local.writeUInt16LE(name.length, 26)
    local.writeUInt16LE(0, 28)
    localParts.push(local, name, data)

    const central = Buffer.alloc(46)
    central.writeUInt32LE(0x02014b50, 0)
    central.writeUInt16LE(20, 4)
    central.writeUInt16LE(20, 6)
    central.writeUInt16LE(0x0800, 8)
    central.writeUInt16LE(0, 10)
    central.writeUInt16LE(0, 12)
    central.writeUInt16LE(dateBits, 14)
    central.writeUInt32LE(crc, 16)
    central.writeUInt32LE(data.length, 20)
    central.writeUInt32LE(data.length, 24)
    central.writeUInt16LE(name.length, 28)
    central.writeUInt16LE(0, 30)
    central.writeUInt16LE(0, 32)
    central.writeUInt16LE(0, 34)
    central.writeUInt16LE(0, 36)
    central.writeUInt32LE(0, 38)
    central.writeUInt32LE(localOffset, 42)
    centralParts.push(central, name)
    localOffset += local.length + name.length + data.length
  }
  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0)
  const end = Buffer.alloc(22)
  end.writeUInt32LE(0x06054b50, 0)
  end.writeUInt16LE(0, 4)
  end.writeUInt16LE(0, 6)
  end.writeUInt16LE(entries.length, 8)
  end.writeUInt16LE(entries.length, 10)
  end.writeUInt32LE(centralSize, 12)
  end.writeUInt32LE(localOffset, 16)
  end.writeUInt16LE(0, 20)
  return Buffer.concat([...localParts, ...centralParts, end])
}

async function treeHashes(root) {
  const result = []
  async function visit(directory, prefix = "") {
    const names = (await readdir(directory)).sort()
    for (const name of names) {
      const relative = prefix ? prefix + "/" + name : name
      const absolute = path.join(directory, name)
      const stat = await lstat(absolute)
      assert.equal(stat.isSymbolicLink(), false, "test fixture unexpectedly contains a link")
      if (stat.isDirectory()) {
        await visit(absolute, relative)
      } else {
        const bytes = await readFile(absolute)
        result.push({
          path: relative,
          bytes: bytes.byteLength,
          sha256: createHash("sha256").update(bytes).digest("hex")
        })
      }
    }
  }
  await visit(root)
  return result
}

async function treeSnapshot(root) {
  const result = []
  async function visit(directory, prefix = "") {
    const entries = await readdir(directory, { withFileTypes: true })
    entries.sort((left, right) => left.name < right.name ? -1 : left.name > right.name ? 1 : 0)
    for (const entry of entries) {
      const relative = prefix ? prefix + "/" + entry.name : entry.name
      const absolute = path.join(directory, entry.name)
      if (entry.isSymbolicLink()) {
        result.push({ path: relative, kind: "symlink" })
      } else if (entry.isDirectory()) {
        result.push({ path: relative, kind: "directory" })
        await visit(absolute, relative)
      } else if (entry.isFile()) {
        const bytes = await readFile(absolute)
        result.push({
          path: relative,
          kind: "file",
          bytes: bytes.byteLength,
          sha256: createHash("sha256").update(bytes).digest("hex")
        })
      } else {
        result.push({ path: relative, kind: "other" })
      }
    }
  }
  await visit(root)
  return result
}

test("HTTP backup, verification, comparison, report download, restore and restart preserve source bytes", async t => {
  const fixture = await sourceFixture()
  let current = await startApp(t, fixture)
  const before = await treeHashes(fixture.baseline)

  const home = await fetch(current.app.url)
  assert.equal(home.status, 200)
  assert.match(await home.text(), /Archive Desk Workbench/u)
  assert.equal(home.headers.get("access-control-allow-origin"), null)

  const initial = await responseJson(await fetch(current.app.url + "/api/state"))
  assert.equal(initial.version, "0.4.0-candidate.1")
  assert.equal(initial.backups.length, 0)
  assert.equal(initial.busy, false)

  const previewResponse = await fetch(current.app.url + "/api/preview?source=project")
  assert.equal(previewResponse.status, 200)
  const preview = await responseJson(previewResponse)
  assert.deepEqual(preview.files.map(file => file.path), [
    "changed.bin",
    "nested/資料/café.txt",
    "removed.txt",
    "same.txt"
  ])
  assert.equal(preview.count, 4)
  assert.equal(preview.skippedPaths[0].path, ".env")
  assert.equal(JSON.stringify(preview).includes("synthetic excluded text"), false)
  assert.equal(Object.hasOwn(preview.files[0], "data"), false)

  const backupResponse = await post(current.app, "/api/backups", { source: "project", label: "Before sample edit" })
  assert.equal(backupResponse.status, 201)
  const backupPayload = await responseJson(backupResponse)
  const backup = backupPayload.backup
  assert.match(backup.id, /^[a-f0-9]{24}$/u)
  assert.equal(backup.label, "Before sample edit")
  assert.equal(backup.source, "project")
  assert.equal(backup.files, 4)
  assert.equal(backup.demo, false)
  assert.match(backup.sha256, /^[a-f0-9]{64}$/u)

  const verifyResponse = await post(current.app, "/api/backups/" + backup.id + "/verify", {})
  assert.equal(verifyResponse.status, 200)
  const verification = await responseJson(verifyResponse)
  assert.equal(verification.files.length, 4)
  assert.equal(verification.backup.id, backup.id)
  assert.ok(verification.files.every(file => /^[a-f0-9]{64}$/u.test(file.sha256)))

  const compareResponse = await post(current.app, "/api/backups/" + backup.id + "/compare", { source: "current" })
  assert.equal(compareResponse.status, 200)
  const comparison = await responseJson(compareResponse)
  assert.deepEqual(comparison.counts, { added: 1, removed: 1, changed: 1, unchanged: 2 })
  assert.equal(comparison.rows.length, 5)
  assert.equal(comparison.baselineArchiveSha256, backup.sha256)

  const reportResponse = await fetch(current.app.url + "/api/backups/" + backup.id + "/report")
  assert.equal(reportResponse.status, 200)
  assert.match(reportResponse.headers.get("content-disposition"), /comparison-[a-f0-9]{24}\.json/u)
  assert.deepEqual(JSON.parse(await reportResponse.text()).counts, comparison.counts)

  const archiveResponse = await fetch(current.app.url + "/api/backups/" + backup.id + "/download")
  assert.equal(archiveResponse.status, 200)
  assert.match(archiveResponse.headers.get("content-disposition"), /archive-[a-f0-9]{24}\.zip/u)
  assert.equal(archiveResponse.headers.get("content-type"), "application/zip")
  const downloadedArchive = Buffer.from(await archiveResponse.arrayBuffer())
  assert.equal(createHash("sha256").update(downloadedArchive).digest("hex"), backup.sha256)

  const restoreResponse = await post(current.app, "/api/backups/" + backup.id + "/restore", { name: "recovered-one" })
  assert.equal(restoreResponse.status, 200)
  const restore = await responseJson(restoreResponse)
  assert.equal(restore.verified, true)
  assert.equal(restore.files, 4)
  assert.equal(restore.totalBytes, backup.totalBytes)
  const actualRestorePath = path.resolve(restore.destination)
  const expectedRestorePath = path.resolve(path.join(fixture.storage, "restores", "recovered-one"))
  assert.equal(
    process.platform === "win32" ? actualRestorePath.toLowerCase() : actualRestorePath,
    process.platform === "win32" ? expectedRestorePath.toLowerCase() : expectedRestorePath
  )
  assert.deepEqual(await treeHashes(restore.destination), before.filter(file => file.path !== ".env"))
  assert.deepEqual(await treeHashes(fixture.baseline), before)

  const existingBefore = await treeHashes(restore.destination)
  const existingResponse = await post(current.app, "/api/backups/" + backup.id + "/restore", { name: "recovered-one" })
  assert.equal(existingResponse.status, 409)
  assert.deepEqual(await treeHashes(restore.destination), existingBefore)

  const persistedState = await responseJson(await fetch(current.app.url + "/api/state"))
  assert.equal(persistedState.backups.length, 1)
  assert.equal(persistedState.activity[0].title, "Recovery completed")

  await current.close()
  current = await startApp(t, fixture)
  const restartedState = await responseJson(await fetch(current.app.url + "/api/state"))
  assert.equal(restartedState.backups.length, 1)
  assert.equal(restartedState.backups[0].id, backup.id)
  assert.equal(restartedState.backups[0].sha256, backup.sha256)
  assert.equal(restartedState.activity.length, persistedState.activity.length)
  const persistedReport = await fetch(current.app.url + "/api/backups/" + backup.id + "/report")
  assert.equal(persistedReport.status, 200)
  assert.deepEqual(JSON.parse(await persistedReport.text()).counts, comparison.counts)
  const persistedArchive = await fetch(current.app.url + "/api/backups/" + backup.id + "/download")
  assert.equal(Buffer.from(await persistedArchive.arrayBuffer()).equals(downloadedArchive), true)
})

test("sample workflow uses only a new lab tree and retains its comparison report", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "owner-source.txt", "keep this configured workspace file\n")
  const workspaceBefore = await treeHashes(fixture.workspace)
  const { app } = await startApp(t, fixture)

  const demoResponse = await post(app, "/api/demo", {})
  assert.equal(demoResponse.status, 200)
  const demo = await responseJson(demoResponse)
  assert.equal(demo.backup.demo, true)
  assert.equal(demo.backup.source, "demo:" + demo.backup.id)
  assert.equal(demo.backup.files, 4)
  assert.deepEqual(demo.comparison.counts, { added: 1, removed: 1, changed: 1, unchanged: 2 })
  assert.equal(demo.steps.length, 4)
  assert.ok(demo.steps.every(step => step.status === "pass"))
  assert.equal(demo.restore.verified, true)
  assert.deepEqual(await treeHashes(fixture.workspace), workspaceBefore)

  const baseline = path.join(fixture.storage, "labs", demo.backup.id, "baseline")
  const current = path.join(fixture.storage, "labs", demo.backup.id, "current")
  await lstat(path.join(baseline, "removed.txt"))
  await lstat(path.join(baseline, ".git", "readme.txt"))
  await lstat(path.join(current, "added.txt"))
  const compareResponse = await post(app, "/api/backups/" + demo.backup.id + "/compare", { source: "missing-current-folder" })
  assert.equal(compareResponse.status, 200)
  assert.deepEqual((await responseJson(compareResponse)).counts, demo.comparison.counts)
  const reportResponse = await fetch(app.url + "/api/backups/" + demo.backup.id + "/report")
  assert.equal(reportResponse.status, 200)
  assert.deepEqual(JSON.parse(await reportResponse.text()).counts, demo.comparison.counts)
  const state = await responseJson(await fetch(app.url + "/api/state"))
  assert.equal(state.backups.length, 1)
  assert.equal(state.backups[0].demo, true)
  assert.deepEqual(await treeHashes(fixture.workspace), workspaceBefore)
})

test("request boundaries reject bad host, cross-site writes, missing origin, bad media type, large bodies and unsafe paths", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "note.txt", "synthetic content that must not be returned\n")
  const { app } = await startApp(t, fixture)

  const badHost = await rawRequest(app, "/api/state", { headers: { Host: "example.test" } })
  assert.equal(badHost.status, 421)

  const crossSite = await fetch(app.url + "/api/state", { headers: { "Sec-Fetch-Site": "cross-site" } })
  assert.equal(crossSite.status, 403)

  const foreignOriginRead = await fetch(app.url, { headers: { Origin: "https://elsewhere.example" } })
  assert.equal(foreignOriginRead.status, 200)
  assert.equal(foreignOriginRead.headers.get("access-control-allow-origin"), null)

  const missingOrigin = await fetch(app.url + "/api/backups", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Workbench": "1" },
    body: JSON.stringify({ source: ".", label: "Denied" })
  })
  assert.equal(missingOrigin.status, 403)

  const badOrigin = await post(app, "/api/backups", { source: ".", label: "Denied" }, { Origin: "https://elsewhere.example" })
  assert.equal(badOrigin.status, 403)
  const missingMarker = await post(app, "/api/backups", { source: ".", label: "Denied" }, { "X-Workbench": "0" })
  assert.equal(missingMarker.status, 403)
  const badType = await post(app, "/api/backups", { source: ".", label: "Denied" }, { "Content-Type": "text/plain" })
  assert.equal(badType.status, 415)

  const oversized = await fetch(app.url + "/api/backups", {
    method: "POST",
    headers: requestHeaders(app),
    body: " ".repeat(BODY_LIMIT + 1)
  })
  assert.equal(oversized.status, 413)

  const traversal = await fetch(app.url + "/api/preview?source=..")
  assert.equal(traversal.status, 400)
  const absolute = await fetch(app.url + "/api/preview?source=C%3A%5CUsers")
  assert.equal(absolute.status, 400)
  const duplicate = await fetch(app.url + "/api/preview?source=.&source=.")
  assert.equal(duplicate.status, 400)

  const invalidId = await post(app, "/api/backups/not-an-id/verify", {})
  assert.equal(invalidId.status, 400)
  const badPlanOrigin = await post(app, "/api/backups/" + "a".repeat(24) + "/restore-plan", { name: "denied" }, { Origin: "https://elsewhere.example" })
  assert.equal(badPlanOrigin.status, 403)
  const privatePath = await fetch(app.url + "/server.mjs")
  assert.equal(privatePath.status, 404)
  const vendorPath = await fetch(app.url + "/vendor/cli.mjs")
  assert.equal(vendorPath.status, 404)
  const corsPreflight = await fetch(app.url + "/api/state", {
    method: "OPTIONS",
    headers: { Origin: "https://elsewhere.example", "Access-Control-Request-Method": "POST" }
  })
  assert.equal(corsPreflight.headers.get("access-control-allow-origin"), null)

  const state = await responseJson(await fetch(app.url + "/api/state"))
  assert.equal(state.backups.length, 0)
  assert.equal(state.busy, false)
})

test("mutations are serialized and a concurrent write receives 409", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "note.txt", "synthetic bytes\n")
  const { app } = await startApp(t, fixture)
  const existingResponse = await post(app, "/api/backups", { source: ".", label: "Existing backup" })
  assert.equal(existingResponse.status, 201)
  const existingBackup = (await responseJson(existingResponse)).backup
  const body = Buffer.from(JSON.stringify({ source: ".", label: "Serialized write" }))
  const firstResponse = new Promise((resolve, reject) => {
    const request = http.request(new URL("/api/backups", app.url), {
      method: "POST",
      headers: {
        Host: new URL(app.url).host,
        Origin: app.url,
        "Content-Type": "application/json",
        "X-Workbench": "1",
        "Content-Length": body.byteLength
      }
    }, response => {
      const chunks = []
      response.on("data", chunk => chunks.push(chunk))
      response.on("end", () => resolve({
        status: response.statusCode,
        body: Buffer.concat(chunks).toString("utf8")
      }))
    })
    request.once("error", reject)
    request.write(body.subarray(0, 4))
    setTimeout(() => request.end(body.subarray(4)), 60)
  })
  await new Promise(resolve => setTimeout(resolve, 20))
  const state = await responseJson(await fetch(app.url + "/api/state"))
  assert.equal(state.busy, true)
  const libraryCheck = await post(app, "/api/library-check", {})
  assert.equal(libraryCheck.status, 409)
  const second = await post(app, "/api/backups/" + existingBackup.id + "/restore-plan", { name: "while-busy" })
  assert.equal(second.status, 409)
  const first = await firstResponse
  assert.equal(first.status, 201)
})

test("corrupt saved archive bytes are rejected without changing the configured source", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "project/not-secret.txt", "synthetic marker bytes\n")
  const { app } = await startApp(t, fixture)
  const sourceBefore = await treeHashes(path.join(fixture.workspace, "project"))
  const backupResponse = await post(app, "/api/backups", { source: "project", label: "Corruption fixture" })
  assert.equal(backupResponse.status, 201)
  const backup = (await responseJson(backupResponse)).backup
  const archive = path.join(fixture.storage, "archives", backup.id + ".zip")
  const bytes = Buffer.from(await readFile(archive))
  const marker = Buffer.from("synthetic marker bytes\n")
  const offset = bytes.indexOf(marker)
  assert.ok(offset >= 0)
  bytes[offset] ^= 0xff
  await writeFile(archive, bytes)

  const verifyResponse = await post(app, "/api/backups/" + backup.id + "/verify", {})
  assert.equal(verifyResponse.status, 409)
  assert.match((await responseJson(verifyResponse)).error, /archive bytes/u)
  assert.deepEqual(await treeHashes(path.join(fixture.workspace, "project")), sourceBefore)
})

test("workspace and storage must be separate and symlinked source or storage paths are refused", async t => {
  const fixture = await makeFixture()
  const nestedStorage = path.join(fixture.workspace, "nested-storage")
  await assert.rejects(
    createWorkbench({ workspace: fixture.workspace, storage: nestedStorage, port: 0 }),
    /separate folders/u
  )
  await assert.rejects(lstat(nestedStorage), error => error.code === "ENOENT")

  const outside = path.join(fixture.root, "outside")
  const linkedSource = path.join(fixture.workspace, "linked-source")
  await mkdir(outside)
  await putFile(outside, "outside.txt", "synthetic outside file\n")
  try {
    await symlink(outside, linkedSource, "junction")
  } catch (error) {
    if (["EPERM", "EACCES", "UNKNOWN"].includes(error && error.code)) {
      t.skip("This Windows environment did not permit creating a test junction.")
      return
    }
    throw error
  }

  const { app } = await startApp(t, fixture)
  const linkedPreview = await fetch(app.url + "/api/preview?source=linked-source")
  assert.equal(linkedPreview.status, 400)
  assert.match((await responseJson(linkedPreview)).error, /symbolic link or junction/u)

  const linkedStorage = path.join(fixture.root, "linked-storage")
  await symlink(fixture.storage, linkedStorage, "junction")
  const secondWorkspace = path.join(fixture.root, "second-workspace")
  await mkdir(secondWorkspace)
  await assert.rejects(
    createWorkbench({ workspace: secondWorkspace, storage: linkedStorage, port: 0 }),
    /without links/u
  )
})

test("server command starts with explicit options and exposes only the loopback address", async t => {
  const fixture = await makeFixture()
  const child = spawn(process.execPath, [
    SERVER_FILE,
    "--workspace", fixture.workspace,
    "--storage", fixture.storage,
    "--port", "0"
  ], {
    cwd: SOURCE_ROOT,
    env: process.platform === "win32" ? { SystemRoot: process.env.SystemRoot || process.env.SYSTEMROOT } : {},
    shell: false,
    windowsHide: true,
    stdio: ["ignore", "pipe", "pipe"]
  })
  let stdout = ""
  let stderr = ""
  child.stdout.setEncoding("utf8")
  child.stderr.setEncoding("utf8")
  child.stdout.on("data", chunk => { stdout += chunk })
  child.stderr.on("data", chunk => { stderr += chunk })
  let stopped = false
  t.after(async () => {
    if (stopped) return
    stopped = true
    child.kill("SIGTERM")
    await once(child, "exit")
  })
  const deadline = Date.now() + 10_000
  while (!stdout.includes("\n") && Date.now() < deadline && child.exitCode === null) {
    await new Promise(resolve => setTimeout(resolve, 20))
  }
  assert.equal(child.exitCode, null, stderr)
  assert.match(stdout, /Archive Desk Workbench is running at http:\/\/127\.0\.0\.1:\d+/u)
  assert.equal(stdout.includes(fixture.workspace), false)
  assert.equal(stdout.includes(fixture.storage), false)
  const address = stdout.trim().split(" ").at(-1)
  const state = await responseJson(await fetch(address + "/api/state"))
  assert.equal(state.backups.length, 0)
  assert.equal(new URL(address).hostname, "127.0.0.1")
  child.kill("SIGTERM")
  await once(child, "exit")
  stopped = true
})

test("import preview is read only and a CLI archive imports exactly, verifies, restores, compares explicitly and survives restart", async t => {
  const originFixture = await sourceFixture()
  const originApp = await startApp(t, originFixture)
  const originalSource = await treeHashes(originFixture.baseline)
  const backupResponse = await post(originApp.app, "/api/backups", { source: "project", label: "Import source fixture" })
  assert.equal(backupResponse.status, 201)
  const originalBackup = (await responseJson(backupResponse)).backup
  const downloadedSource = await fetch(originApp.app.url + "/api/backups/" + originalBackup.id + "/download")
  assert.equal(downloadedSource.status, 200)
  const archiveBytes = Buffer.from(await downloadedSource.arrayBuffer())

  const destinationFixture = await makeFixture()
  await putFile(destinationFixture.workspace, "project/current.txt", "explicit comparison sample\n")
  let importedApp = await startApp(t, destinationFixture)
  const stateBefore = await readFile(path.join(destinationFixture.storage, "state.json"))
  const archivesBefore = await readdir(path.join(destinationFixture.storage, "archives"))
  assert.deepEqual(archivesBefore, [])

  const previewResponse = await postArchive(importedApp.app, "/api/import/preview", archiveBytes)
  assert.equal(previewResponse.status, 200, previewResponse.body)
  const preview = JSON.parse(previewResponse.body)
  assert.equal(preview.createdAt, originalBackup.createdAt)
  assert.equal(preview.archiveBytes, archiveBytes.byteLength)
  assert.equal(preview.archiveSha256, createHash("sha256").update(archiveBytes).digest("hex"))
  assert.deepEqual(preview.counts, { files: originalBackup.files, totalBytes: originalBackup.totalBytes })
  assert.equal(preview.files.length, originalBackup.files)
  assert.ok(preview.files.every(file => /^[a-f0-9]{64}$/u.test(file.sha256)))
  assert.deepEqual(await readdir(path.join(destinationFixture.storage, "archives")), archivesBefore)
  assert.deepEqual(await readFile(path.join(destinationFixture.storage, "state.json")), stateBefore)

  const importResponse = await postArchive(importedApp.app, "/api/import?label=Restored%20project%20archive", archiveBytes)
  assert.equal(importResponse.status, 201, importResponse.body)
  const imported = JSON.parse(importResponse.body).backup
  assert.match(imported.id, /^[a-f0-9]{24}$/u)
  assert.equal(imported.label, "Restored project archive")
  assert.equal(imported.source, ".")
  assert.equal(imported.origin, "import")
  assert.equal(imported.demo, false)
  assert.equal(imported.sha256, preview.archiveSha256)
  assert.equal(imported.createdAt, preview.createdAt)

  const library = await responseJson(await fetch(importedApp.app.url + "/api/state"))
  assert.equal(library.backups.length, 1)
  assert.equal(library.backups[0].origin, "import")
  const savedDownload = await fetch(importedApp.app.url + "/api/backups/" + imported.id + "/download")
  assert.equal(savedDownload.status, 200)
  assert.deepEqual(Buffer.from(await savedDownload.arrayBuffer()), archiveBytes)

  const verifyResponse = await post(importedApp.app, "/api/backups/" + imported.id + "/verify", {})
  assert.equal(verifyResponse.status, 200)
  assert.equal((await responseJson(verifyResponse)).files.length, preview.counts.files)
  const noImplicitCompare = await post(importedApp.app, "/api/backups/" + imported.id + "/compare", {})
  assert.equal(noImplicitCompare.status, 400)
  const compareResponse = await post(importedApp.app, "/api/backups/" + imported.id + "/compare", { source: "project" })
  assert.equal(compareResponse.status, 200)
  assert.equal((await responseJson(compareResponse)).baselineArchiveSha256, imported.sha256)

  const restoreResponse = await post(importedApp.app, "/api/backups/" + imported.id + "/restore", { name: "imported-recovery" })
  assert.equal(restoreResponse.status, 200)
  const restore = await responseJson(restoreResponse)
  assert.equal(restore.verified, true)
  assert.deepEqual(await treeHashes(restore.destination), originalSource.filter(file => file.path !== ".env"))
  assert.deepEqual(await treeHashes(originFixture.baseline), originalSource)

  await importedApp.close()
  importedApp = await startApp(t, destinationFixture)
  const restarted = await responseJson(await fetch(importedApp.app.url + "/api/state"))
  assert.equal(restarted.backups.length, 1)
  assert.equal(restarted.backups[0].origin, "import")
  assert.equal(restarted.backups[0].sha256, imported.sha256)
  const restartedDownload = await fetch(importedApp.app.url + "/api/backups/" + imported.id + "/download")
  assert.deepEqual(Buffer.from(await restartedDownload.arrayBuffer()), archiveBytes)
})

test("import rejects missing origin, wrong media type, extra query values, malformed, tampered and traversal archives without writes", async t => {
  const originFixture = await sourceFixture()
  const originApp = await startApp(t, originFixture)
  const backupResponse = await post(originApp.app, "/api/backups", { source: "project" })
  const backup = (await responseJson(backupResponse)).backup
  const download = await fetch(originApp.app.url + "/api/backups/" + backup.id + "/download")
  const archiveBytes = Buffer.from(await download.arrayBuffer())

  const destinationFixture = await makeFixture()
  const destinationApp = await startApp(t, destinationFixture)
  const missingOrigin = await postArchive(destinationApp.app, "/api/import/preview", archiveBytes, { Origin: undefined })
  assert.equal(missingOrigin.status, 403)
  const wrongType = await postArchive(destinationApp.app, "/api/import/preview", archiveBytes, { "Content-Type": "application/json" })
  assert.equal(wrongType.status, 415)
  const extraPreviewQuery = await postArchive(destinationApp.app, "/api/import/preview?source=.", archiveBytes)
  assert.equal(extraPreviewQuery.status, 400)
  const extraImportQuery = await postArchive(destinationApp.app, "/api/import?label=one&label=two", archiveBytes)
  assert.equal(extraImportQuery.status, 400)

  const malformed = await postArchive(destinationApp.app, "/api/import/preview", Buffer.from("not a ZIP archive"))
  assert.equal(malformed.status, 422)
  const tamperedBytes = Buffer.from(archiveBytes)
  tamperedBytes[tamperedBytes.length - 5] ^= 0xff
  const tampered = await postArchive(destinationApp.app, "/api/import/preview", tamperedBytes)
  assert.equal(tampered.status, 422)

  const unsafeCreatedAt = "2026-10-18T12:00:00.000Z"
  const unsafeData = Buffer.from("synthetic traversal sample")
  const unsafeManifest = Buffer.from(JSON.stringify({
    format: "archive-desk",
    version: 1,
    createdAt: unsafeCreatedAt,
    files: [{
      path: "../escape.txt",
      bytes: unsafeData.byteLength,
      sha256: createHash("sha256").update(unsafeData).digest("hex"),
      modifiedAt: Date.parse(unsafeCreatedAt)
    }]
  }))
  const unsafeArchive = makeStoredZip([
    { name: "ArchiveDesk/manifest.json", data: unsafeManifest },
    { name: "files/../escape.txt", data: unsafeData }
  ])
  const traversal = await postArchive(destinationApp.app, "/api/import/preview", unsafeArchive)
  assert.equal(traversal.status, 422)
  assert.deepEqual(await readdir(path.join(destinationFixture.storage, "archives")), [])
  assert.equal((await responseJson(await fetch(destinationApp.app.url + "/api/state"))).backups.length, 0)
})

test("import accepts octet-stream, rejects duplicate archive bytes and enforces the streaming size limit", async t => {
  const sourceFixtureData = await sourceFixture()
  const sourceApp = await startApp(t, sourceFixtureData)
  const backupResponse = await post(sourceApp.app, "/api/backups", { source: "project" })
  const backup = (await responseJson(backupResponse)).backup
  const download = await fetch(sourceApp.app.url + "/api/backups/" + backup.id + "/download")
  const archiveBytes = Buffer.from(await download.arrayBuffer())

  const destinationFixture = await makeFixture()
  const destinationApp = await startApp(t, destinationFixture)
  const imported = await postArchive(destinationApp.app, "/api/import", archiveBytes, { "Content-Type": "application/octet-stream" })
  assert.equal(imported.status, 201, imported.body)
  const duplicate = await postArchive(destinationApp.app, "/api/import", archiveBytes)
  assert.equal(duplicate.status, 409)
  assert.deepEqual(await readdir(path.join(destinationFixture.storage, "archives")), [JSON.parse(imported.body).backup.id + ".zip"])

  const tooLargeBytes = Buffer.alloc(52 * 1024 * 1024 + 1, 0x5a)
  const tooLarge = await postArchive(destinationApp.app, "/api/import/preview", tooLargeBytes, {
    "Content-Length": undefined,
    "Transfer-Encoding": "chunked"
  })
  assert.equal(tooLarge.status, 413)
  assert.equal((await responseJson(await fetch(destinationApp.app.url + "/api/state"))).backups.length, 1)
  assert.deepEqual(await readdir(path.join(destinationFixture.storage, "archives")), [JSON.parse(imported.body).backup.id + ".zip"])
})

test("restore plan rechecks the archive and destination without changing state or creating folders", async t => {
  const fixture = await makeFixture()
  const fileBytes = Buffer.from("plan sample bytes\n", "utf8")
  await putFile(fixture.workspace, "project/nested/sample.txt", fileBytes)
  const retainedFile = await putFile(fixture.storage, "restores/already-used/keep.txt", "keep this folder\n")
  const { app } = await startApp(t, fixture)
  const backupResponse = await post(app, "/api/backups", { source: "project", label: "Plan fixture" })
  assert.equal(backupResponse.status, 201)
  const backup = (await responseJson(backupResponse)).backup
  const statePath = path.join(fixture.storage, "state.json")
  const stateBefore = await readFile(statePath)
  const archivesBefore = await readdir(path.join(fixture.storage, "archives"))
  const restoresBefore = await readdir(path.join(fixture.storage, "restores"))
  const retainedBefore = await readFile(retainedFile)

  const response = await post(app, "/api/backups/" + backup.id + "/restore-plan", { name: "planned-recovery" })
  assert.equal(response.status, 200)
  const plan = await responseJson(response)
  assert.deepEqual(Object.keys(plan).sort(), [
    "archiveSha256", "backupId", "counts", "destination", "files", "format", "generatedAt", "limitations", "name", "version"
  ].sort())
  assert.equal(plan.format, "archive-desk-restore-plan")
  assert.equal(plan.version, 1)
  assert.ok(Number.isFinite(Date.parse(plan.generatedAt)))
  assert.equal(plan.backupId, backup.id)
  assert.equal(plan.archiveSha256, backup.sha256)
  assert.equal(plan.name, "planned-recovery")
  assert.equal(plan.destination, "restores/planned-recovery")
  assert.deepEqual(plan.counts, { files: 1, totalBytes: fileBytes.byteLength })
  assert.deepEqual(plan.files, [{
    path: "nested/sample.txt",
    bytes: fileBytes.byteLength,
    sha256: createHash("sha256").update(fileBytes).digest("hex")
  }])
  assert.equal(Object.hasOwn(plan.files[0], "data"), false)
  assert.match(plan.limitations.join(" "), /not an atomic authorization or security token/u)
  const serializedPlan = JSON.stringify(plan)
  for (const absolutePath of [fixture.root, fixture.workspace, fixture.storage]) {
    assert.equal(serializedPlan.includes(JSON.stringify(absolutePath).slice(1, -1)), false)
  }

  const badName = await post(app, "/api/backups/" + backup.id + "/restore-plan", { name: "../escape" })
  assert.equal(badName.status, 400)
  const collision = await post(app, "/api/backups/" + backup.id + "/restore-plan", { name: "already-used" })
  assert.equal(collision.status, 409)
  assert.equal((await readFile(retainedFile)).equals(retainedBefore), true)
  assert.equal((await readFile(statePath)).equals(stateBefore), true)
  assert.deepEqual(await readdir(path.join(fixture.storage, "archives")), archivesBefore)
  assert.deepEqual(await readdir(path.join(fixture.storage, "restores")), restoresBefore)
})

test("GET verification downloads fresh relative metadata and hashes for Unicode, binary and empty files", async t => {
  const fixture = await makeFixture()
  const sourceFiles = [
    { path: "資料/café.txt", data: Buffer.from("雪 and café\n", "utf8") },
    { path: "payload.bin", data: Buffer.from([0, 1, 127, 128, 255]) },
    { path: "empty.dat", data: Buffer.alloc(0) }
  ]
  for (const file of sourceFiles) await putFile(fixture.workspace, "project/" + file.path, file.data)
  const { app } = await startApp(t, fixture)
  const backupResponse = await post(app, "/api/backups", { source: "project", label: "Verification fixture" })
  assert.equal(backupResponse.status, 201)
  const backup = (await responseJson(backupResponse)).backup
  const archiveResponse = await fetch(app.url + "/api/backups/" + backup.id + "/download")
  assert.equal(archiveResponse.status, 200)
  const archiveBytes = Buffer.from(await archiveResponse.arrayBuffer())
  const statePath = path.join(fixture.storage, "state.json")
  const stateBefore = await readFile(statePath)
  const archivesBefore = await readdir(path.join(fixture.storage, "archives"))
  const restoresBefore = await readdir(path.join(fixture.storage, "restores"))

  const response = await fetch(app.url + "/api/backups/" + backup.id + "/verification")
  assert.equal(response.status, 200)
  assert.equal(response.headers.get("content-type"), "application/json; charset=utf-8")
  assert.equal(response.headers.get("content-disposition"), "attachment; filename=\"verification-" + backup.id + ".json\"")
  assert.equal(response.headers.get("cache-control"), "no-store")
  const serialized = await response.text()
  const report = JSON.parse(serialized)
  assert.deepEqual(Object.keys(report).sort(), [
    "archiveBytes", "archiveSha256", "backupId", "counts", "files", "format", "generatedAt", "label", "limitations", "origin", "version"
  ].sort())
  assert.equal(report.format, "archive-desk-verification")
  assert.equal(report.version, 1)
  assert.ok(Number.isFinite(Date.parse(report.generatedAt)))
  assert.equal(report.backupId, backup.id)
  assert.equal(report.label, "Verification fixture")
  assert.equal(report.origin, "workspace")
  assert.equal(report.archiveSha256, backup.sha256)
  assert.equal(report.archiveSha256, createHash("sha256").update(archiveBytes).digest("hex"))
  assert.equal(report.archiveBytes, archiveBytes.byteLength)
  assert.deepEqual(report.counts, {
    files: sourceFiles.length,
    totalBytes: sourceFiles.reduce((sum, file) => sum + file.data.byteLength, 0)
  })
  const expectedFiles = sourceFiles.map(file => ({
    path: file.path,
    bytes: file.data.byteLength,
    sha256: createHash("sha256").update(file.data).digest("hex")
  })).sort((left, right) => left.path < right.path ? -1 : left.path > right.path ? 1 : 0)
  assert.deepEqual(report.files, expectedFiles)
  assert.ok(report.files.every(file => /^[a-f0-9]{64}$/u.test(file.sha256) && !Object.hasOwn(file, "data")))
  for (const absolutePath of [fixture.root, fixture.workspace, fixture.storage]) {
    assert.equal(serialized.includes(JSON.stringify(absolutePath).slice(1, -1)), false)
  }
  assert.equal((await readFile(statePath)).equals(stateBefore), true)
  assert.deepEqual(await readdir(path.join(fixture.storage, "archives")), archivesBefore)
  assert.deepEqual(await readdir(path.join(fixture.storage, "restores")), restoresBefore)
})

test("GET verification returns errors without a pass report for tampered or missing archive bytes", async t => {
  const fixture = await makeFixture()
  await putFile(fixture.workspace, "project/sample.txt", "verification integrity fixture\n")
  const { app } = await startApp(t, fixture)
  const backupResponse = await post(app, "/api/backups", { source: "project", label: "Tamper fixture" })
  assert.equal(backupResponse.status, 201)
  const backup = (await responseJson(backupResponse)).backup
  const statePath = path.join(fixture.storage, "state.json")
  const stateBefore = await readFile(statePath)
  const archivePath = path.join(fixture.storage, "archives", backup.id + ".zip")
  const tamperedBytes = Buffer.from(await readFile(archivePath))
  tamperedBytes[0] ^= 0xff
  await writeFile(archivePath, tamperedBytes)

  const tampered = await fetch(app.url + "/api/backups/" + backup.id + "/verification")
  assert.equal(tampered.status, 409)
  assert.equal(tampered.headers.get("content-disposition"), null)
  const tamperedBody = await responseJson(tampered)
  assert.deepEqual(Object.keys(tamperedBody), ["error"])
  assert.match(tamperedBody.error, /archive bytes/u)
  assert.equal((await readFile(statePath)).equals(stateBefore), true)

  const missingFixture = await makeFixture()
  const missingId = "e".repeat(24)
  const createdAt = new Date().toISOString()
  await writeFile(path.join(missingFixture.storage, "state.json"), JSON.stringify({
    format: "archive-desk-workbench",
    version: 1,
    backups: [{
      id: missingId,
      label: "Missing archive fixture",
      source: "project",
      createdAt,
      files: 1,
      totalBytes: 8,
      archiveBytes: 128,
      sha256: "e".repeat(64),
      verifiedAt: createdAt,
      demo: false,
      reportIds: [],
      origin: "workspace"
    }],
    activity: []
  }))
  const missingApp = await startApp(t, missingFixture)
  const missingStatePath = path.join(missingFixture.storage, "state.json")
  const missingStateBefore = await readFile(missingStatePath)
  const missing = await fetch(missingApp.app.url + "/api/backups/" + missingId + "/verification")
  assert.equal(missing.status, 404)
  assert.equal(missing.headers.get("content-disposition"), null)
  const missingBody = await responseJson(missing)
  assert.deepEqual(Object.keys(missingBody), ["error"])
  assert.equal(Object.hasOwn(missingBody, "format"), false)
  assert.equal((await readFile(missingStatePath)).equals(missingStateBefore), true)
})

test("library check validates an empty library, applies standard request guards and leaves storage unchanged", async t => {
  const fixture = await makeFixture()
  const { app } = await startApp(t, fixture)
  const statePath = path.join(fixture.storage, "state.json")
  const stateBefore = await readFile(statePath)
  const storageBefore = await treeSnapshot(fixture.storage)

  const badOrigin = await post(app, "/api/library-check", {}, { Origin: "https://elsewhere.example" })
  assert.equal(badOrigin.status, 403)
  const missingMarker = await post(app, "/api/library-check", {}, { "X-Workbench": "0" })
  assert.equal(missingMarker.status, 403)
  const badType = await post(app, "/api/library-check", {}, { "Content-Type": "text/plain" })
  assert.equal(badType.status, 415)
  const extraField = await post(app, "/api/library-check", { unexpected: true })
  assert.equal(extraField.status, 400)
  const missingBody = await rawRequest(app, "/api/library-check", {
    method: "POST",
    headers: {
      Host: new URL(app.url).host,
      Origin: app.url,
      "Content-Type": "application/json",
      "X-Workbench": "1",
      "Content-Length": "0"
    },
    body: Buffer.alloc(0)
  })
  assert.equal(missingBody.status, 400)

  const response = await post(app, "/api/library-check", {})
  assert.equal(response.status, 200)
  assert.equal(response.headers.get("content-type"), "application/json; charset=utf-8")
  const serialized = await response.text()
  const report = JSON.parse(serialized)
  assert.deepEqual(Object.keys(report).sort(), ["checkedAt", "counts", "format", "limits", "results", "version"].sort())
  assert.equal(report.format, "archive-desk-library-check")
  assert.equal(report.version, 1)
  assert.ok(Number.isFinite(Date.parse(report.checkedAt)))
  assert.deepEqual(report.counts, { backups: 0, passed: 0, failed: 0 })
  assert.deepEqual(report.results, [])
  assert.ok(report.limits.length >= 2)
  assert.equal((await responseJson(await fetch(app.url + "/api/state"))).version, "0.4.0-candidate.1")
  assert.equal((await readFile(statePath)).equals(stateBefore), true)
  assert.deepEqual(await treeSnapshot(fixture.storage), storageBefore)
})

test("library check reports healthy, tampered and missing archives independently without writes", async t => {
  const fixture = await makeFixture()
  const sample = path.join(fixture.workspace, "project", "content.txt")
  await putFile(fixture.workspace, "project/content.txt", "first private fixture content\n")
  const initial = await startApp(t, fixture)
  const createBackup = async label => {
    const response = await post(initial.app, "/api/backups", { source: "project", label })
    assert.equal(response.status, 201)
    return (await responseJson(response)).backup
  }
  const firstHealthy = await createBackup("Healthy before damage")
  await writeFile(sample, "tampered archive fixture content\n")
  const damaged = await createBackup("Damaged archive fixture")
  await writeFile(sample, "healthy archive after damage\n")
  const lastHealthy = await createBackup("Healthy after damage")
  await initial.close()

  const statePath = path.join(fixture.storage, "state.json")
  const savedState = JSON.parse(await readFile(statePath, "utf8"))
  const byId = new Map(savedState.backups.map(record => [record.id, record]))
  const missingId = "f".repeat(24)
  const createdAt = new Date().toISOString()
  const missing = {
    id: missingId,
    label: "Missing archive fixture",
    source: "project",
    createdAt,
    files: 1,
    totalBytes: 8,
    archiveBytes: 128,
    sha256: "f".repeat(64),
    verifiedAt: createdAt,
    demo: false,
    reportIds: [],
    origin: "workspace"
  }
  savedState.backups = [byId.get(firstHealthy.id), missing, byId.get(damaged.id), byId.get(lastHealthy.id)]
  await writeFile(statePath, Buffer.from(JSON.stringify(savedState, null, 2) + "\n", "utf8"))
  const damagedPath = path.join(fixture.storage, "archives", damaged.id + ".zip")
  const damagedBytes = Buffer.from(await readFile(damagedPath))
  damagedBytes[0] ^= 0xff
  await writeFile(damagedPath, damagedBytes)

  const checkedApp = await startApp(t, fixture)
  const storageBefore = await treeSnapshot(fixture.storage)
  const stateBefore = await readFile(statePath)
  const response = await post(checkedApp.app, "/api/library-check", {})
  assert.equal(response.status, 200)
  const serialized = await response.text()
  const report = JSON.parse(serialized)
  assert.equal(report.format, "archive-desk-library-check")
  assert.deepEqual(report.counts, { backups: 4, passed: 2, failed: 2 })
  assert.deepEqual(report.results.map(result => result.id), [firstHealthy.id, missingId, damaged.id, lastHealthy.id])
  for (const result of report.results) {
    assert.deepEqual(Object.keys(result).sort(), [
      "archiveSha256", "error", "files", "id", "label", "recordedArchiveSha256", "status", "totalBytes"
    ].sort())
  }
  const firstResult = report.results[0]
  assert.equal(firstResult.status, "passed")
  assert.equal(firstResult.archiveSha256, firstResult.recordedArchiveSha256)
  assert.equal(firstResult.error, null)
  assert.equal(firstResult.files, 1)
  const missingResult = report.results[1]
  assert.equal(missingResult.status, "failed")
  assert.equal(missingResult.archiveSha256, null)
  assert.equal(missingResult.files, null)
  assert.equal(missingResult.totalBytes, null)
  assert.ok(missingResult.error)
  const damagedResult = report.results[2]
  assert.equal(damagedResult.status, "failed")
  assert.notEqual(damagedResult.archiveSha256, damagedResult.recordedArchiveSha256)
  assert.ok(damagedResult.error)
  const lastResult = report.results[3]
  assert.equal(lastResult.status, "passed")
  assert.equal(lastResult.archiveSha256, lastResult.recordedArchiveSha256)
  assert.equal(lastResult.error, null)
  for (const absolutePath of [fixture.root, fixture.workspace, fixture.storage]) {
    assert.equal(serialized.includes(absolutePath), false)
  }
  assert.equal(serialized.includes("first private fixture content"), false)
  assert.equal(serialized.includes("tampered archive fixture content"), false)
  assert.equal((await readFile(statePath)).equals(stateBefore), true)
  assert.deepEqual(await treeSnapshot(fixture.storage), storageBefore)
  assert.deepEqual(JSON.parse(await readFile(statePath, "utf8")).activity, savedState.activity)
})

test("library startup refuses a corrupt saved library without replacing it", async () => {
  const fixture = await makeFixture()
  const statePath = path.join(fixture.storage, "state.json")
  const corruptState = Buffer.from('{"format":"unknown-library","version":1,"backups":[],"activity":[]}\n', "utf8")
  await writeFile(statePath, corruptState)

  await assert.rejects(
    createWorkbench({ workspace: fixture.workspace, storage: fixture.storage, port: 0 }),
    /saved backup library format is not recognized/u
  )
  assert.equal((await readFile(statePath)).equals(corruptState), true)
})

test("restore accepts a matching optional archive SHA and preserves name-only requests", async t => {
  const fixture = await makeFixture()
  const fileBytes = Buffer.from("restore hash fixture\n", "utf8")
  await putFile(fixture.workspace, "project/recovered.txt", fileBytes)
  const { app } = await startApp(t, fixture)
  const backupResponse = await post(app, "/api/backups", { source: "project", label: "Restore hash fixture" })
  assert.equal(backupResponse.status, 201)
  const backup = (await responseJson(backupResponse)).backup
  const statePath = path.join(fixture.storage, "state.json")
  const stateBefore = await readFile(statePath)
  const wrongHash = (backup.sha256[0] === "0" ? "1" : "0") + backup.sha256.slice(1)

  const invalidHash = await post(app, "/api/backups/" + backup.id + "/restore", { name: "invalid-hash", archiveSha256: "z".repeat(64) })
  assert.equal(invalidHash.status, 400)
  const mismatch = await post(app, "/api/backups/" + backup.id + "/restore", { name: "hash-mismatch", archiveSha256: wrongHash })
  assert.equal(mismatch.status, 409)
  assert.match((await responseJson(mismatch)).error, /SHA-256/u)
  assert.equal((await readFile(statePath)).equals(stateBefore), true)
  assert.deepEqual(await readdir(path.join(fixture.storage, "restores")), [])

  const checkedRestore = await post(app, "/api/backups/" + backup.id + "/restore", { name: "checked-restore", archiveSha256: backup.sha256 })
  assert.equal(checkedRestore.status, 200)
  const checked = await responseJson(checkedRestore)
  assert.equal(checked.verified, true)
  assert.deepEqual(await treeHashes(checked.destination), [{
    path: "recovered.txt",
    bytes: fileBytes.byteLength,
    sha256: createHash("sha256").update(fileBytes).digest("hex")
  }])

  const legacyRestore = await post(app, "/api/backups/" + backup.id + "/restore", { name: "legacy-restore" })
  assert.equal(legacyRestore.status, 200)
  assert.equal((await responseJson(legacyRestore)).verified, true)
})

test("legacy version-one records load with workspace and demo origin defaults", async t => {
  const fixture = await makeFixture()
  const workspaceId = "a".repeat(24)
  const demoId = "b".repeat(24)
  const createdAt = new Date().toISOString()
  const makeLegacyRecord = (id, source, demo) => ({
    id,
    label: demo ? "Old sample" : "Old workspace archive",
    source,
    createdAt,
    files: 1,
    totalBytes: 0,
    archiveBytes: 128,
    sha256: (demo ? "b" : "a").repeat(64),
    verifiedAt: createdAt,
    demo,
    reportIds: []
  })
  await writeFile(path.join(fixture.storage, "state.json"), JSON.stringify({
    format: "archive-desk-workbench",
    version: 1,
    backups: [
      makeLegacyRecord(workspaceId, "project", false),
      makeLegacyRecord(demoId, "demo:" + demoId, true)
    ],
    activity: []
  }))
  const app = await startApp(t, fixture)
  const state = await responseJson(await fetch(app.app.url + "/api/state"))
  assert.equal(state.version, "0.4.0-candidate.1")
  assert.equal(state.backups[0].origin, "workspace")
  assert.equal(state.backups[1].origin, "demo")
})
