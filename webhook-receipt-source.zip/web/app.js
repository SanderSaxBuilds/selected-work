const byId = id => document.getElementById(id);
let attempts = 0;
let busy = false;
let hasFirst = false;
const labels = {first:'First delivery',repeat:'Same event, same body',conflict:'Same event, changed body',invalid:'Invalid signature',older:'Older event'};
function updateButtons(){document.querySelectorAll('button[data-case]').forEach(button=>{button.disabled=busy||(!hasFirst&&['repeat','conflict','older'].includes(button.dataset.case));});}
async function refresh(){
  const response = await fetch('/state');
  if(!response.ok) throw new Error('Could not read stored state.');
  const state = await response.json();
  byId('count').textContent=String(state.event_count);
  const shipment=state.shipments.find(item=>item.shipment==='DEMO_1042');
  byId('shipment').textContent=shipment?shipment.status.replaceAll('_',' '):'Not recorded';
  hasFirst=state.events.some(event=>event.event_id==='evt_demo_001');
  byId('events').replaceChildren();
  for(const event of state.events){const row=document.createElement('tr');for(const value of [event.event_id,event.shipment,event.status,new Date(event.event_at*1000).toISOString().replace('.000Z','Z')]){const cell=document.createElement('td');cell.textContent=value;row.append(cell);}byId('events').append(row);}
  byId('state-note').textContent=state.event_count?'The records survive a page reload and service restart when the same database is retained. The response journal shows this browser session only.':'No event has been recorded. Send the first fictional delivery to start.';
  updateButtons();
}
async function runCase(name){
  if(busy)return;
  busy=true;updateButtons();
  try{
    const response=await fetch('/demo/'+name,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
    const result=await response.json();attempts++;
    const card=document.createElement('article');card.className='entry'+(response.ok?'':' error');
    const head=document.createElement('div');head.className='entry-head';
    const title=document.createElement('span');title.textContent=labels[name];
    const badge=document.createElement('span');badge.className='badge';badge.textContent=String(response.status);
    head.append(title,badge);const code=document.createElement('pre');code.textContent=JSON.stringify(result,null,2);card.append(head,code);
    if(attempts===1)byId('journal').replaceChildren();byId('journal').prepend(card);
    byId('attempts').textContent=attempts+' session attempt'+(attempts===1?'':'s');
    byId('last').textContent=response.status+' '+(result.result||'rejected');
    await refresh();
  }catch(error){byId('state-note').textContent=error.message;}finally{busy=false;updateButtons();}
}
document.querySelectorAll('button[data-case]').forEach(button=>button.addEventListener('click',()=>runCase(button.dataset.case)));
refresh().catch(error=>{byId('state-note').textContent=error.message;document.querySelectorAll('button[data-case]').forEach(button=>button.disabled=true);});
