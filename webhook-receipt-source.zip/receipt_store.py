"""Fictional shipment callback receipt study. Standard library only."""
import hashlib
import hmac
import json
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

MAX_BODY = 65536
IDENTIFIER = re.compile(r"[A-Za-z0-9_-]{1,64}\Z")
STATUSES = {"created", "in_transit", "delivered"}


class ReceiptError(ValueError):
    def __init__(self, status, code):
        self.status = status
        self.code = code
        super().__init__(code)


def signature(secret, timestamp, body):
    return hmac.new(secret, str(timestamp).encode() + b"." + body, hashlib.sha256).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate key")
        result[key] = value
    return result


def decode_event(body):
    if len(body) > MAX_BODY:
        raise ReceiptError(413, "body_too_large")
    try:
        event = json.loads(body.decode("utf-8"), object_pairs_hook=unique_object,
                           parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
        if not isinstance(event, dict) or set(event) != {"event_id", "shipment", "status", "event_time"}:
            raise ValueError("schema")
        for key in ("event_id", "shipment"):
            if not isinstance(event[key], str) or not IDENTIFIER.fullmatch(event[key]):
                raise ValueError("identifier")
        if not isinstance(event["status"], str) or event["status"] not in STATUSES:
            raise ValueError("status")
        if not isinstance(event["event_time"], str) or not re.fullmatch(
                r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", event["event_time"]):
            raise ValueError("time")
        event_at = int(datetime.strptime(event["event_time"], "%Y-%m-%dT%H:%M:%SZ")
                       .replace(tzinfo=timezone.utc).timestamp())
        canonical = json.dumps(event, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
        return event, event_at, hashlib.sha256(canonical).hexdigest()
    except (ValueError, UnicodeError, TypeError, OverflowError, RecursionError) as error:
        raise ReceiptError(422, "invalid_event") from error


class ReceiptStore:
    def __init__(self, path):
        self.path = str(path)
        with self.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS events (
                    event_id TEXT PRIMARY KEY, digest TEXT NOT NULL,
                    shipment TEXT NOT NULL, status TEXT NOT NULL,
                    event_at INTEGER NOT NULL, accepted_at INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS shipments (
                    shipment TEXT PRIMARY KEY, status TEXT NOT NULL,
                    latest_event_at INTEGER NOT NULL, latest_event_id TEXT NOT NULL
                );
            """)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def receive(self, body, timestamp_header, supplied_signature, secret, now):
        if len(body) > MAX_BODY:
            raise ReceiptError(413, "body_too_large")
        if not isinstance(timestamp_header, str) or not re.fullmatch(r"\d{1,12}", timestamp_header):
            raise ReceiptError(401, "invalid_timestamp")
        timestamp = int(timestamp_header)
        if abs(now - timestamp) > 300:
            raise ReceiptError(401, "expired_signature")
        if not isinstance(supplied_signature, str) or not re.fullmatch(r"[a-f0-9]{64}", supplied_signature):
            raise ReceiptError(401, "invalid_signature")
        if not hmac.compare_digest(signature(secret, timestamp_header, body), supplied_signature):
            raise ReceiptError(401, "invalid_signature")
        event, event_at, digest = decode_event(body)
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            previous = db.execute("SELECT digest FROM events WHERE event_id = ?", (event["event_id"],)).fetchone()
            if previous:
                if previous["digest"] != digest:
                    raise ReceiptError(409, "event_id_conflict")
                return {"result": "duplicate", "event_id": event["event_id"], "projection_changed": False}
            db.execute("INSERT INTO events VALUES (?, ?, ?, ?, ?, ?)",
                       (event["event_id"], digest, event["shipment"], event["status"], event_at, now))
            current = db.execute("SELECT latest_event_at FROM shipments WHERE shipment = ?", (event["shipment"],)).fetchone()
            changed = current is None or event_at > current["latest_event_at"]
            if changed:
                db.execute("""INSERT INTO shipments VALUES (?, ?, ?, ?)
                    ON CONFLICT(shipment) DO UPDATE SET status=excluded.status,
                    latest_event_at=excluded.latest_event_at, latest_event_id=excluded.latest_event_id""",
                    (event["shipment"], event["status"], event_at, event["event_id"]))
            return {"result": "recorded", "event_id": event["event_id"], "projection_changed": changed}

    def state(self):
        with self.connect() as db:
            events = [dict(row) for row in db.execute(
                "SELECT event_id, shipment, status, event_at FROM events ORDER BY rowid DESC LIMIT 30")]
            shipments = [dict(row) for row in db.execute(
                "SELECT * FROM shipments ORDER BY shipment LIMIT 30")]
            count = db.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            return {"event_count": count, "events": events, "shipments": shipments}
