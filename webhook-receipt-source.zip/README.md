# Webhook receipt study

A small independent Python demonstration for duplicate callback repairs. It uses fictional shipment events, a local HTTP service and SQLite. It does not contact a shipping provider or perform an external action.

Run with Python 3.10 or newer, using the standard library only:

```text
python -m unittest test_receipts -v
python server.py --db runs/study.sqlite --port 8962
```

Open `http://127.0.0.1:8962`. Send the first event, replay it, then try a conflicting body, bad signature and older event. The page reads actual stored records after every request. Reloading the page clears its response journal but preserves the database. Restarting the service with the same database preserves the receipt and projected state.

The store verifies an HMAC over the delivery timestamp and exact body, accepts a five-minute delivery window, validates a fixed JSON schema and compares a canonical digest for event ID reuse. A SQLite transaction records the event and updates its projection together. Identical retries return a duplicate acknowledgment. Changed content under the same ID is rejected. Older and equal-time events are retained without replacing the latest projection.

This proves only the behavior exercised by the accompanying tests and browser review. It is not an exactly-once guarantee for external effects. The demo has one event namespace and one local database, no provider integration, user accounts, background processing, cloud deployment or production observability. The five-minute window and event ordering policy are study choices that need agreement for a real integration. The service uses a fresh ephemeral key on each launch and offers only fixed local demonstration cases. Do not use it with production data or credentials.

No database reset or file deletion is provided. Test databases are retained in uniquely named temporary folders. Client work would need its own event contract, permissions, delivery retry rules, storage and operational review.
