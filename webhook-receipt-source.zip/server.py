"""Local test harness, bound to loopback. No external provider connection."""
import argparse
import json
import secrets
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from receipt_store import MAX_BODY, ReceiptError, ReceiptStore, signature

ASSETS = Path(__file__).parent / "web"
FIXTURE = {"event_id": "evt_demo_001", "shipment": "DEMO_1042", "status": "in_transit",
           "event_time": "2026-10-18T00:00:00Z"}


def make_server(store, port=8962):
    secret = secrets.token_bytes(32)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def reply(self, status, content, mime="application/json"):
            data = json.dumps(content, ensure_ascii=False).encode() if mime == "application/json" else content
            self.send_response(status)
            self.send_header("Content-Type", mime + "; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; frame-ancestors 'none'; base-uri 'none'")
            self.end_headers()
            self.wfile.write(data)

        def local_request(self):
            port = self.server.server_port
            allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
            allowed_origins = {f"http://{host}" for host in allowed_hosts}
            if self.headers.get("Host") not in allowed_hosts:
                self.reply(403, {"error": "local_host_required"})
                return False
            origin = self.headers.get("Origin")
            if origin is not None and origin not in allowed_origins:
                self.reply(403, {"error": "same_origin_required"})
                return False
            return True

        def do_GET(self):
            if not self.local_request():
                return
            if self.path == "/state":
                self.reply(200, store.state())
                return
            assets = {"/": ("index.html", "text/html"), "/app.js": ("app.js", "text/javascript"),
                      "/style.css": ("style.css", "text/css")}
            if self.path not in assets:
                self.reply(404, {"error": "not_found"})
                return
            name, mime = assets[self.path]
            self.reply(200, (ASSETS / name).read_bytes(), mime)

        def do_POST(self):
            if not self.local_request():
                self.close_connection = True
                return
            try:
                length = int(self.headers.get("Content-Length", "-1"))
                if length < 0:
                    raise ReceiptError(411, "content_length_required")
                if length > MAX_BODY:
                    self.close_connection = True
                    raise ReceiptError(413, "body_too_large")
                body = self.rfile.read(length)
                if self.path.startswith("/demo/"):
                    case = self.path.removeprefix("/demo/")
                    if case not in {"first", "repeat", "conflict", "invalid", "older"}:
                        raise ReceiptError(404, "not_found")
                    event = dict(FIXTURE)
                    if case == "conflict":
                        event["status"] = "delivered"
                    if case == "older":
                        event.update(event_id="evt_demo_older", status="created", event_time="2026-10-17T23:00:00Z")
                    body = json.dumps(event).encode()
                    timestamp = str(int(time.time()))
                    digest = signature(secret, timestamp, body)
                    if case == "invalid":
                        digest = "0" * 64
                elif self.path == "/webhook":
                    if self.headers.get_content_type() != "application/json":
                        raise ReceiptError(415, "json_required")
                    timestamp = self.headers.get("X-Delivery-Timestamp")
                    digest = self.headers.get("X-Delivery-Signature")
                else:
                    raise ReceiptError(404, "not_found")
                result = store.receive(body, timestamp, digest, secret, int(time.time()))
                self.reply(200, result)
            except ReceiptError as error:
                self.reply(error.status, {"error": error.code})
            except ValueError:
                self.reply(400, {"error": "invalid_content_length"})
            except Exception:
                self.reply(500, {"error": "internal_error"})

    return ThreadingHTTPServer(("127.0.0.1", port), Handler)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", required=True, help="An explicit new study database path")
    parser.add_argument("--port", type=int, default=8962)
    args = parser.parse_args()
    db_path = Path(args.db)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    server = make_server(ReceiptStore(db_path), args.port)
    print(f"Fictional local study on http://127.0.0.1:{args.port}, database {db_path}", flush=True)
    server.serve_forever()
