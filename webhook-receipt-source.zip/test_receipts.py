import concurrent.futures
import http.client
import json
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from receipt_store import MAX_BODY, ReceiptError, ReceiptStore, signature
from server import FIXTURE, make_server

NOW = 1802822400
KEY = b"fictional-unit-test-key-not-a-provider-credential"


class Receipts(unittest.TestCase):
    def setUp(self):
        self.folder = Path(tempfile.mkdtemp(prefix="webhook-study-qa-"))
        self.store = ReceiptStore(self.folder / "test.sqlite")

    def send(self, event=None, body=None, timestamp=None, supplied=None):
        body = body if body is not None else json.dumps(event or FIXTURE).encode()
        timestamp = str(NOW) if timestamp is None else timestamp
        supplied = signature(KEY, timestamp, body) if supplied is None else supplied
        return self.store.receive(body, timestamp, supplied, KEY, NOW)

    def reject(self, code, **kwargs):
        before = self.store.state()
        with self.assertRaises(ReceiptError) as caught:
            self.send(**kwargs)
        self.assertEqual(caught.exception.code, code)
        self.assertEqual(self.store.state(), before)

    def test_first_records_one_event_and_projection(self):
        self.assertTrue(self.send()["projection_changed"])
        self.assertEqual(self.store.state()["event_count"], 1)
        self.assertEqual(self.store.state()["shipments"][0]["status"], "in_transit")

    def test_duplicate_is_acknowledged_without_second_event(self):
        self.send()
        self.assertEqual(self.send()["result"], "duplicate")
        self.assertEqual(self.store.state()["event_count"], 1)

    def test_whitespace_and_key_order_are_semantically_duplicate(self):
        self.send()
        body = json.dumps(dict(reversed(list(FIXTURE.items()))), indent=4).encode()
        self.assertEqual(self.send(body=body)["result"], "duplicate")

    def test_conflicting_event_id_has_no_effect(self):
        self.send()
        self.reject("event_id_conflict", event={**FIXTURE, "status": "delivered"})

    def test_old_distinct_event_is_retained_without_regressing_projection(self):
        self.send()
        result = self.send(event={**FIXTURE, "event_id": "old", "status": "created", "event_time": "2026-10-17T22:00:00Z"})
        self.assertFalse(result["projection_changed"])
        self.assertEqual(self.store.state()["event_count"], 2)
        self.assertEqual(self.store.state()["shipments"][0]["status"], "in_transit")

    def test_newer_event_updates_projection(self):
        self.send()
        self.send(event={**FIXTURE, "event_id": "new", "status": "delivered", "event_time": "2026-10-18T02:00:00Z"})
        self.assertEqual(self.store.state()["shipments"][0]["status"], "delivered")

    def test_equal_event_time_preserves_first_projection(self):
        self.send()
        result = self.send(event={**FIXTURE, "event_id": "tied", "status": "created"})
        self.assertFalse(result["projection_changed"])

    def test_restart_retains_duplicate_receipt(self):
        self.send()
        reopened = ReceiptStore(self.store.path)
        body = json.dumps(FIXTURE).encode()
        self.assertEqual(reopened.receive(body, str(NOW), signature(KEY, NOW, body), KEY, NOW)["result"], "duplicate")

    def test_concurrent_replays_record_exactly_once(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
            results = list(pool.map(lambda _: self.send()["result"], range(24)))
        self.assertEqual(results.count("recorded"), 1)
        self.assertEqual(results.count("duplicate"), 23)
        self.assertEqual(self.store.state()["event_count"], 1)

    def test_bad_signature_has_no_effect(self):
        self.reject("invalid_signature", supplied="0" * 64)

    def test_missing_signature_has_no_effect(self):
        self.reject("invalid_signature", supplied="")

    def test_changed_body_invalidates_original_signature(self):
        original = json.dumps(FIXTURE).encode()
        self.reject("invalid_signature", body=original+b" ", supplied=signature(KEY, NOW, original))

    def test_expired_signature_has_no_effect(self):
        self.reject("expired_signature", timestamp=str(NOW-301))

    def test_future_signature_outside_window_has_no_effect(self):
        self.reject("expired_signature", timestamp=str(NOW+301))

    def test_exact_timestamp_boundary_is_accepted(self):
        self.assertEqual(self.send(timestamp=str(NOW-300))["result"], "recorded")

    def test_timestamp_must_be_bounded_decimal(self):
        for value in ("", "-1", "1.5", "9" * 13):
            with self.subTest(value=value):
                self.reject("invalid_timestamp", timestamp=value)

    def test_unknown_fields_are_rejected(self):
        self.reject("invalid_event", event={**FIXTURE, "extra": "no"})

    def test_missing_field_is_rejected(self):
        self.reject("invalid_event", event={key: value for key, value in FIXTURE.items() if key != "status"})

    def test_invalid_status_is_rejected(self):
        self.reject("invalid_event", event={**FIXTURE, "status": "unknown"})

    def test_invalid_identifiers_are_rejected(self):
        for value in ("", "x" * 65, "<script>", 13):
            with self.subTest(value=value):
                self.reject("invalid_event", event={**FIXTURE, "event_id": value})

    def test_invalid_dates_are_rejected(self):
        for value in ("2026-02-30T00:00:00Z", "2026-10-18", "2026-10-18T00:00:00+00:00"):
            with self.subTest(value=value):
                self.reject("invalid_event", event={**FIXTURE, "event_time": value})

    def test_duplicate_json_keys_are_rejected(self):
        body = json.dumps(FIXTURE).encode()[:-1] + b', "status":"created"}'
        self.reject("invalid_event", body=body)

    def test_non_json_non_finite_and_invalid_utf8_are_rejected(self):
        for body in (b"not-json", b"[]", b"NaN", b"\xff"):
            with self.subTest(body=body):
                self.reject("invalid_event", body=body)

    def test_deeply_nested_signed_json_is_invalid_without_storage(self):
        self.reject("invalid_event", body=b"[" * 2000 + b"0" + b"]" * 2000)

    def test_oversized_body_is_rejected_before_storage(self):
        self.reject("body_too_large", body=b"x" * (MAX_BODY+1))


class HttpHarness(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder = Path(tempfile.mkdtemp(prefix="webhook-http-qa-"))
        cls.store = ReceiptStore(cls.folder / "test.sqlite")
        with patch("server.secrets.token_bytes", return_value=KEY):
            cls.server = make_server(cls.store, 0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def request(self, method, path, body=None, headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=10)
        connection.request(method, path, body=body, headers=headers or {})
        result = connection.getresponse()
        data, status, response_headers = result.read(), result.status, dict(result.getheaders())
        connection.close()
        return status, data, response_headers

    def test_browser_assets_and_content_security_policy(self):
        for path in ("/", "/style.css", "/app.js"):
            status, data, headers = self.request("GET", path)
            self.assertEqual(status, 200)
            self.assertGreater(len(data), 100)
            self.assertIn("default-src 'self'", headers["Content-Security-Policy"])

    def test_demo_sequence_returns_actual_receipt_states(self):
        for case, expected_status, expected_value in (
            ("first", 200, "recorded"), ("repeat", 200, "duplicate"),
            ("conflict", 409, "event_id_conflict"), ("invalid", 401, "invalid_signature"),
            ("older", 200, "recorded")):
            with self.subTest(case=case):
                status, data, _ = self.request("POST", "/demo/"+case, b"{}")
                self.assertEqual(status, expected_status)
                result = json.loads(data)
                self.assertEqual(result.get("result", result.get("error")), expected_value)
        self.assertEqual(self.store.state()["event_count"], 2)

    def test_signed_deep_nesting_returns_422_and_preserves_state(self):
        import time
        before = self.store.state()
        body = b"[" * 2000 + b"0" + b"]" * 2000
        timestamp = str(int(time.time()))
        status, data, _ = self.request("POST", "/webhook", body, {
            "Content-Type": "application/json", "X-Delivery-Timestamp": timestamp,
            "X-Delivery-Signature": signature(KEY, timestamp, body)})
        self.assertEqual(status, 422)
        self.assertEqual(json.loads(data), {"error": "invalid_event"})
        self.assertEqual(self.store.state(), before)

    def test_unknown_path_does_not_serve_arbitrary_files(self):
        self.assertEqual(self.request("GET", "/../receipt_store.py")[0], 404)
        self.assertEqual(self.request("POST", "/demo/unknown", b"{}")[0], 404)

    def test_webhook_requires_json_and_signature(self):
        self.assertEqual(self.request("POST", "/webhook", b"{}", {"Content-Type": "text/plain"})[0], 415)
        self.assertEqual(self.request("POST", "/webhook", b"{}", {"Content-Type": "application/json"})[0], 401)

    def test_cross_origin_demo_request_has_no_effect(self):
        before = self.store.state()
        self.assertEqual(self.request("POST", "/demo/first", b"{}", {"Origin": "https://unrelated.example"})[0], 403)
        self.assertEqual(self.store.state(), before)

    def test_unexpected_host_is_rejected(self):
        self.assertEqual(self.request("GET", "/state", headers={"Host": "unrelated.example"})[0], 403)


if __name__ == "__main__":
    unittest.main(verbosity=2)
